def ABflux(sed,filter,madau='yes'):
    """
    Calculates a AB file like the ones used by bpz
    It will set to zero all fluxes
    which are ab_clip times smaller than the maximum flux.
    This eliminates residual flux which gives absurd
    colors at very high-z
    """
    
    print 'manda huevos!'
    pause()
    ccd='yes'
    units='nu'
    madau=madau
    z_ab=arange(0.,zmax_ab,dz_ab) #zmax_ab and dz_ab are def. in bpz_tools
    
    #Figure out the correct names
    if sed[-4:]<>'.sed':sed=sed+'.sed'
    sed=sed_dir+sed
    if filter[-4:]<>'.res':filter=filter+'.res'
    filter=fil_dir+filter
    
    #Get the data
    x_sed,y_sed=get_data(sed,range(2))
    nsed=len(x_sed)
    x_res,y_res=get_data(filter,range(2))
    nres=len(x_res)
    
    if not ascend(x_sed):
        print
        print 'Warning!!!'
        print 'The wavelenghts in %s are not properly ordered' % sed
        print 'They should start with the shortest lambda and end with the longest'        
        print 'This will probably crash the program'
    
    if not ascend(x_res):
        print
        print 'Warning!!!'
        print 'The wavelenghts in %s are not properly ordered' % filter
        print 'They should start with the shortest lambda and end with the longest'
        print 'This will probably crash the program'
    
    if x_sed[-1]<x_res[-1]: #The SED does not cover the whole filter interval
        print 'Extrapolating the spectrum'
        #Linear extrapolation of the flux using the last 4 points
        #slope=mean(y_sed[-4:]/x_sed[-4:])
        d_extrap=(x_sed[-1]-x_sed[0])/len(x_sed)
        x_extrap=arange(x_sed[-1]+d_extrap,x_res[-1]+d_extrap,d_extrap)
        extrap=lsq(x_sed[-5:],y_sed[-5:])
        y_extrap=extrap.fit(x_extrap)
        y_extrap=clip(y_extrap,0.,max(y_sed[-5:]))
        x_sed=concatenate((x_sed,x_extrap))
        y_sed=concatenate((y_sed,y_extrap))
        #connect(x_sed,y_sed)
        #connect(x_res,y_res)
    
    #Wavelenght range of interest as a function of z_ab
    wl_1=x_res[0]/(1.+z_ab)
    wl_2=x_res[-1]/(1.+z_ab)
    n1=clip(searchsorted(x_sed,wl_1)-1,0,100000)
    n2=clip(searchsorted(x_sed,wl_2)+1,0,nsed-1)
    
    #Typical delta lambda
    delta_sed=(x_sed[-1]-x_sed[0])/len(x_sed)
    delta_res=(x_res[-1]-x_res[0])/len(x_res)
    
    
    #Change resolution of filter
    if delta_res>delta_sed:
        x_r=arange(x_res[0],x_res[-1]+delta_sed,delta_sed)
        print 'Changing filter resolution from %.2f AA to %.2f' % (delta_res,delta_sed)
        r=match_resol(x_res,y_res,x_r)
        r=where(less(r,0.),0.,r) #Transmission must be >=0
    else:
        x_r,r=x_res,y_res
    
    #Operations necessary for normalization and ccd effects
    if ccd=='yes': r=r*x_r
    norm_r=trapz(r,x_r)
    if units=='nu': const=norm_r/trapz(r/x_r/x_r,x_r)/clight_AHz
    else: const=1.
    
    const=const/norm_r
    
    nz_ab=len(z_ab)
    f=zeros(nz_ab)*1.
    for i in range(nz_ab):
        i1,i2=n1[i],n2[i]
	if (x_sed[i1] > max(x_r/(1.+z_ab[i]))) or (x_sed[i2] < min(x_r/(1.+z_ab[i]))):
	    print 'bpz_tools.ABflux:'
	    print "YOUR FILTER RANGE DOESN'T OVERLAP AT ALL WITH THE REDSHIFTED TEMPLATE"
	    print "THIS REDSHIFT IS OFF LIMITS TO YOU:"
	    print 'z = ', z_ab[i]
	    print i1, i2
	    print x_sed[i1], x_sed[i2]
	    print y_sed[i1], y_sed[i2]
	    print min(x_r/(1.+z_ab[i])), max(x_r/(1.+z_ab[i]))
	    # NOTE: x_sed[i1:i2] NEEDS TO COVER x_r(1.+z_ab[i])
	    # IF THEY DON'T OVERLAP AT ALL, THE PROGRAM WILL CRASH
	    #sys.exit(1)
	    xxx[9] = 3
	else:
	    ys_z=match_resol(x_sed[i1:i2],y_sed[i1:i2],x_r/(1.+z_ab[i]))
	    if madau<>'no': ys_z=etau_madau(x_r,z_ab[i])*ys_z
	    f[i]=trapz(ys_z*r,x_r)*const        
    
    ABoutput=ab_dir+split(sed,'/')[-1][:-4]+'.'+split(filter,'/')[-1][:-4]+'.AB'
    
    #print "Clipping the AB file"
    #fmax=max(f)
    #f=where(less(f,fmax*ab_clip),0.,f)
    
    print 'Writing AB file ',ABoutput
    put_data(ABoutput,(z_ab,f))

