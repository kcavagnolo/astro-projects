## Automatically adapted for numpy Jul 20, 2006 by convertcode.py

# $p/sedfit.py BRZ 3
# NEW VERSION USING matplotlib

# python bpzPlotschisq2.py bvizjh 7
#   loads bvizjh.bpz
#   makes plot for object w/ id = 7

# python bpzPlotschisq2.py bvizjh 7
#   "i7" = 7th object in sequence

# -SAVE TO WRITE .eps
# -ZSPEC USES SPEC-Z INSTEAD OF BPZ

# scp $work/p/BPZ/bpzPlots.py .

from useful import *
#from bpz_tools_coe import *
from bpz_tools import *
#from coebiggles import *
#from coeplot2a import *
from coeplot2 import *  # pylab, prange, rectangle
#from pylab import *
import shelve
#from afewtools import *
from MLab_coe import ndec
#from ksbtools import loaddata, loadfile, params_cl, str2num, prange, loaddict, plotconfig
from coetools import loaddata, loadfile, params_cl, str2num, loaddict, findmatch1, pause  #, prange, plotconfig
#from numpy import array  # (REIMPORT!, OTHERWISE numarray TAKES OVER)
from numpy import *  # (REIMPORT!, OTHERWISE numarray TAKES OVER)
#import string  # AFTER numpy, WHICH HAS ITS OWN string
#from na import np2na  # CONVERT A numpy ARRAY TO A numarray ARRAY -- NEEDED FOR MY pylab !!!  plot(x,y)
#matplotlib.rc('text', usetex = True)

# $p/bpzPlots.py UBgrizJHK 11

# python ~coe/p/BPZ/bpzPlots.py Idet3 i7
# "i" USES INDEX (ith ITEM IN FILE).  NO "i" SELECTS BY ID.
# -SAVE TO WRITE .eps
# -ZSPEC USES SPEC-Z INSTEAD OF BPZ

# --DC:
# CHANGED spectra FROM CWWSB.list TO CWWSB_fuv.list
# ENABLED INTERPOLATION OF SPECTRA
# LOAD PARAMETERS FROM .bpz FILE
# IMPROVED PLOTTING OF UNOBSERVED & UNDETECTED OBJECTS
# -ZSPEC OPTION USES SPEC-Z INSTEAD OF BPZ

#htmldir = loadfile('/Users/coe/p/htmldir.txt')[0]
#outdir = htmldir + 'sedplots/'
#if not os.path.exists(outdir):
#    os.mkdir(outdir)
outdir = ''

class bpzPlots:
    """
    Usage:
    python bpzPlots.py 
    Define a series of plots given the name of a bpz run and a string which
    identifies an object, and which can be either its ID of a pair of x,y
    coordinates e.g. 1001,2000.In the later case, a tuple containing the indexes of
    the columns containing X,Y information in the main catalog have to be supplied. 
    The plots will be produced for the closest
    object in the catalog. Optionally, different values for the bpz catalog,
    flux comparison file and probs file can be introduced
    """
    
    def __init__(self, run_name, id_str=None,
                 cat=None,probs=None,flux_comparison=None,columns=None,
                 xy_cols=None,spectra='CWWSB_fuv_f_f.list',
		 show_plots=1,save_plots=0
                 ):
        self.run_name=run_name
        
        #Define names of data catalogs
        if cat == None: self.cat=run_name+'.bpz'
        else: self.cat =bpz
        
	self.bpzstr = loadfile(self.cat)
	self.bpzparams = {}
	i = 0
	while self.bpzstr[i][:2] == '##':
	    line = self.bpzstr[i][2:]
	    if '=' in line:
		[key, value] = string.split(line, '=')
		self.bpzparams[key] = value
	    i = i + 1
	self.bpzcols = []
	while self.bpzstr[i][:2] == '# ':
	    line = self.bpzstr[i][2:]
	    [col, key] = string.split(line)
	    self.bpzcols.append(key)	   
	    i = i + 1
	
	self.spectra = self.bpzparams.get('SPECTRA', 'CWWSB_fuv_f_f.list')
	self.columns = self.bpzparams.get('COLUMNS', run_name+'.columns')
	self.flux_comparison = self.bpzparams.get('FLUX_COMPARISON', run_name+'.flux_comparison')
	self.interp = str2num(self.bpzparams.get('INTERP', '2'))

	params = params_cl()
        print 'params', params
	#self.save_plots = 'SAVE' in params
	self.save_plots = save_plots
	self.show_plots = 1 - save_plots

	self.bw = 'BW' in params
        self.thick = 'THICK' in params

##         if probs == None: self.probs_file=run_name+'.probs'
##         else: self.probs_file=probs
        
##         if flux_comparison == None: self.flux_comparison=run_name+'.flux_comparison'
##         else: self.flux_comparison=flux_comparison

##         if columns == None: self.columns=run_name+'.columns'
##         else: self.columns=columns
        
        #Look for the corresponding ID number

        if ',' in str(id_str) and xy_cols<>None: #If the input is a pair of X,Y coordinates
            x,y=map(float,tuple(split(id_str),','))
            x_cat,y_cat=get_data(self.cat,xy_cols)
            self.id=argmin(dist(x_cat,y_cat,x,y))+1
	elif not id_str:
	    self.id = None
	else:
	    if id_str[-2:] == '.i':
	        self.id = ravel(loaddata(id_str).astype(int))
	    elif id_str[0] == 'i':
		#id_str[1:]
                #self.id = self.id[int(id_str[1:])-1]
                self.id = id_str
	    else:
		self.id=int(id_str)
            
        self.templates=get_str(sed_dir+self.spectra,0)
        
    def flux_comparison_plots(self,show_plots=1,save_plots=0):            
      print 'Reading flux comparison data from %s' % self.flux_comparison
      #Get the flux comparison data
      #z = zeros(4, Float)
      #print less(z, 1)
      all=get_2Darray(self.flux_comparison) #Read the whole file
      print 'less'
      #print less(all, 1)
      id=all[:,0] #ID column
        
      #Get the row which contains the ID number we are interested in
      if self.id == None:
	  self.id = id  # DEFAULT: DO 'EM ALL
      if type(self.id) == str:
        i_ids = [str2num(self.id[1:])-1]
        #i_ids = [int(self.id)]
      else:
          try:
              n = len(self.id)  # IF THIS FAILS, THEN IT'S NOT AN ARRAY / LIST
              i_ids = []
              for selfid in self.id:
                  i_id = findmatch1(id, selfid)
                  if i_id == -1:
                      print 'OBJECT #%d NOT FOUND.' % selfid
                      sys.exit()
                  i_ids.append(i_id)
          except:
                i_id = findmatch1(id, self.id)
                if i_id == -1:
                    print 'OBJECT NOT FOUND.'
                    sys.exit()
                else:
                    i_ids = [i_id]
      ncols=len(all[0,:])
      nf=(ncols-5)/3
      for i_id in i_ids:
	print 'sed plot %d / %d : #%d' % (i_id, len(i_ids), id[i_id])
	if self.save_plots:
	    outimg = self.run_name+'_sed_%d.png' % id[i_id]
	    if os.path.exists(outdir + outimg):
		print outdir + outimg, 'ALREADY EXISTS'
		continue
        ft=all[i_id,5:5+nf]  # FLUX (from spectrum for that TYPE)
        fo=all[i_id,5+nf:5+2*nf]  # FLUX (OBSERVED)
        efo=all[i_id,5+2*nf:5+3*nf]  # FLUX_ERROR (OBSERVED)
	#efo = array(efo)
	#print type(efo)
	print 'efo', efo
	#observed = less(efo, 1)
	observed = efo < 1
	#print 'ft', ft
	#print 'fo', fo
	#print 'efo', efo

        #Get the redshift, type and magnitude of the galaxy
        m,z,t=all[i_id,1],all[i_id,2],all[i_id,3]
	params = params_cl()
	
        bpzdata = loaddata(self.bpzstr)
	if len(bpzdata.shape) == 1:
	    bpzdata.shape = (1, len(bpzdata))
        bpzdata = transpose(bpzdata)
        #odds = bpzdata[self.bpzcols.index('ODDS')]
        if 'ODDS' in self.bpzcols:
            i = self.bpzcols.index('ODDS')
        else:
            i = self.bpzcols.index('ODDS_1')
        odds = bpzdata[i]

	# Z-SPEC
	if 'Z_S' in self.bpzcols:
	    #bpzdata = transpose(loaddata(self.bpzstr))
	    zspeccol = self.bpzcols.index('Z_S')
	    zspec = bpzdata[zspeccol]
	    #zspec = ravel(loaddata(params['ZSPEC']))
	if 'ZSPEC' in params:
	    z = zspec[i_id]
	    print "z SET TO SPECTROSCOPIC VALUE OF %.3f" % z
	    ## 	z = 0.1972
## 	print "z ARTIFICIALLY SET TO ", z

 	#print "USING INTERP=2 (YOUR RESULTS MAY VARY)"
	print "type=", t
	interp = self.interp
 	print "USING INTERP=%d" % interp
	t = (t + interp) / (1.*interp + 1)
        #print 'ARTIFICIALLY SETTING z & TYPE'
        # NOTE: THIS DOESN'T MOVE THE BLUE BOXES!
        #z, t = 3.14, 1
        #t, z = 5.33, 2.77
	#t = (t + 2) / 3.
	print "%.3f" % t,
	betweentypes = ndec(t)
## 	t = int(round(t))
## 	print t,
        sed=self.templates[int(t-1)]
	print sed,
	print "z=", z,
        #odds = [odds]
        print 'odds=%.2f' % odds[i_id]
        #print 'odds=%.2f' % odds
        if 'Z_S' in self.bpzcols:
	    print 'zspec=%.3f' % zspec[i_id]
	    
        #Get the filter wavelengths
        print 'Reading filter information from %s' % self.columns
        filters=get_str(self.columns,0,nrows=nf,)
        lambda_m=ft*0.

        for i in range(len(filters)): lambda_m[i]=filter_center(filters[i])
	#print filters
	#print lambda_m
	
        # chisq 2
        eft = ft / 15.
        #eft = zeros(nf) + max(eft)
	#print eft
	#print max(eft)
	#print 'eft', eft
	eft = array([max(eft)] * nf)
	#print 'eft', eft
	#print 'efo', efo
        #eft = ones(nf) * max(eft)
        #eft = zeros(nf) + max(eft)
        #ef = sqrt(efo**2 + eft**2)
        #ef = hypot(eft, eft)
        #ef = hypot(efo, efo)
	#print type(efo), type(eft)
	#efo = array(efo.tolist())
	#eft = array(eft.tolist())
        ef = hypot(efo, eft)
        #
        dfosq = ((ft - fo) / ef) ** 2
        dfosqsum = sum(dfosq)
        #
        #observed = less(efo, 1)
        observed = efo < 1
	#print observed
	nfobs = 0
	for obs1 in observed:
	    if obs1:
		nfobs += 1
	#print nfobs
        #nfobs = sum(observed)
        #
        if nfobs > 1:
            dof = max([nfobs - 3, 1])  # 3 params (z, t, a)
            chisq2 = dfosqsum / dof
        elif nfobs: # == 1
            chisq2 = 999.
        else:
            chisq2 = 9999.

        print 'chisq2 = ', chisq2


        #Convert to f_l
        #print 'Convert to f_l'
        ft=ft/lambda_m**2
        fo=fo/lambda_m**2
	#print "FLUX: OBS / TYPE =", fo / ft
        efo=efo/lambda_m**2
	#print 'ft', ft
	#print 'fo', fo
	#print 'efo', efo
        
        # fo, efo, ft IN ACTUAL UNITS OF f_lambda
        print 'USE ACTUAL UNITS OF F_lambda'
        fo = fo * 0.112
        efo = efo * 0.112
        ft = ft * 0.112
	#print 'ft', ft

        eft = ft / 15.
	eft = array([max(eft)] * nf)


        #p.add(Curve(x,y, linewidth=linewidth, color=black))
	#p.add(Curve((x[0], x[-1]), (0, 0), linetype='dashed', color='gray', linewidth=linewidth))
        #p=FramedPlot()
	#title = "Object #%d, type=%.2f, bpz=%.3f" % (id[i_id], t, z)
	ptitle = "#%d, type=%.2f, bpz=%.2f, odds=%.2f" % (id[i_id], t, z, odds[i_id])
	#ptitle = "#%d, type=%.2f, bpz=%.2f, odds=%.2f, chisq2=%.2f" % (id[i_id], t, z, odds[i_id], chisq2)
	if 'Z_S' in self.bpzcols:
	    ptitle += ", zspec=%.2f" % zspec[i_id]
	title(ptitle)
	#p.title="Object #%d, type=%.2f, z=%.3f" % (id[i_id], t, z)
		
	# -DC CORRECTING FLUX ERRORS:
	# mag = (-99, 0) NOT HANDLED CORRECLY BY BPZ WHEN OUTPUTTING TO .flux_comparison
	# ASSIGNS LARGE ERROR TO FLUX (DIVIDING BY ZERO MAG_ERROR)
	# MAYBE bpz SHOULD ASSIGN mag = (-99, maglimit) INSTEAD, LIKE IT DOES FOR mag = (99,
	#efo = where(less(efo, 1), efo, 0)
	#fomin = where(fo, fo-efo, 0)
	#fomax = where(fo, fo+efo, 2*efo)
##         if sum(greater(efo,2*fo)):
##             p.add(ErrorBarsY(lambda_m,fo,fo+2*fo))
##         else:
##             p.add(ErrorBarsY(lambda_m,fo-efo,fo+efo))        
##	p.add(ErrorBarsY(lambda_m,fo-efo,fo+efo))        
	#p.add(ErrorBarsY(lambda_m,fomin,fomax))        

        print sed, z
        x,y=obs_spectrum(sed,z)
	#print x
	#print y
	#x = array(x.tolist())
	#y = array(y.tolist())
	#print type(x), type(y)
	#xna = np2na(x)
	#yna = np2na(y)
	#plot(x,y)
        #xlabel(r"$\lambda~(\AA)$")
        #ylabel(r"$f_\lambda~~(ergs / cm^2 / s / \AA)$")
        #xlabel(r"$\lambda \rm{A}$")
        xlabel(r"$\lambda (A)$")
        ylabel(r"$f_\lambda (ergs / cm^2 / s / A)$")
        #xlabel(r"$\lambda (A)$")
        #ylabel(r"f_lambda (ergs / cm^2 / s / A)")
	if betweentypes:
	    # INTERPOLATE! --DC
	    t1 = int(t)
	    t2 = t1 + 1
	    sed2=self.templates[int(t2-1)]
	    x2,y2 = obs_spectrum(sed2,z)
	    y2 = match_resol(x2,y2,x)
	    y = (t2 - t) * y + (t - t1) * y2

        #Normalize spectrum to model fluxes
	#x = array(x.tolist())
	#y = array(y.tolist())
	#lambda_m = array(lambda_m.tolist())
	#print x
	#print y
	#print lambda_m
	#lambda_m = np2na(lambda_m)
	#print type(x), type(y), type(lambda_m)
        y_norm=match_resol(x,y,lambda_m)
        if sum(ft):
            norm=sum(y_norm*ft)/sum(ft*ft)
            y=y/norm
            # USED TO DO THIS BELOW
            # REPLACED WITH ORIGINAL CODE ABOVE
            #normt=sum(y_norm*ft)/sum(ft*ft)
            #norm=sum(y_norm*fo)/sum(fo*fo)
            #print "Normalizing to observed instead of calculated."
            #y=y/norm
            #ft = ft * normt / norm
        else:
            print 'OBSERVED FIT MINIZED & COMPRIMISED!!'
        
        black = 'grey60'

        #p.add(Curve(x,y, linewidth=linewidth, color=black))
	#p.add(Curve((x[0], x[-1]), (0, 0), linetype='dashed', color='gray', linewidth=linewidth))
        #xrange = [3800, 16700]
        xrange = prange(lambda_m, None, 0.025)
        xrange = prange(lambda_m, None, 0.075)
        inxrange = between(xrange[0], x, xrange[1])
        xinxrange = compress(inxrange, x)
        yinxrange = compress(inxrange, y)
        yyy = concatenate([fo*0, fo, ft, yinxrange])
        yyy2 = concatenate([fo, ft])
        #print max(yyy), 1.5*max(yyy2), 1.5*max(fo)
        yyymax = min([max(yyy), 1.5*max(yyy2), 1.5*max(fo)]) # cap max, so you don't show big peaks and so you don't squash all efo
        if not yyymax:
            yyymax = max(yyy)
	yrange = prange([0, yyymax])
        print xrange, yrange
	#print xrange
	#print yyymax

        # THIS SHOULD FORCE THE PLOT WINDOW TO WHAT I WANT
        # BUT IT DOESN'T QUITE WORK
	#plot([xrange[0]], [yrange[0]])
	#plot([xrange[1]], [yrange[1]])

	#plot(xrange, yrange)
	#plot([xrange[0]], [0])
	#plot([xrange[1]], [yyymax])
        #p.xrange = [3900, 16750]
        #p.xrange = xrange
        #p.yrange = prange([0, yyymax])
        #print "Zooming in on observed range."
        #yyy = concatenate([fo*0, fo])
        #p.xrange = prange(lambda_m)
        #p.xrange = [3900, 16250]
        #p.xrange = [3900, 16500]
        #p.xrange = [3900, 16750]
        #p.yrange = prange(yyy)
	
	#plot(np2na(x),np2na(y))
	#plot(x.tolist(), y.tolist(), color='gray')
	plot(xinxrange.tolist(), yinxrange.tolist(), color='gray')
        linewidth = 1 + 2 * self.thick
        fontsize = 3 + 0.5 * self.thick
        
	maxy = max(y)
	#efo = where(less(efo, maxy), efo, maxy)  # CAP ERROR AT LARGEST FLUX

        #We need to figure out which is the lambda for each filter...
        #have to read the .columns file 
        #p.add(Points(lambda_m,ft,type='square',size=3,color='blue'))
##         p.add(Points(lambda_m,fo,type='filled circle',size=2))
## 	print 2*fo
## 	print efo
## 	print greater(efo,2*fo)

        #filts = string.split('B V i z J H $J_{VLT}$ $Ks_{VLT}$')
        #filts = string.split('$B_{WFC}$ $V_{WFC}$ $i_{WFC}$ $z_{WFC}$ $J_{NIC3}$ $H_{NIC3}$ $J_{VLT}$ $Ks_{VLT}$')
        indict = os.path.join(os.environ['BPZPATH'], 'plots/filtnicktex.dict')
        filtdict = loaddict(indict)

#x = 5e-18
#'%.2e' % x

	for i in range(len(filters)):
            if self.bw:
                color = 'grey65'
                if filters[i][-4:] == 'NIC3':
                    color = 'grey35'
                if filters[i][:3] == 'HST':
                    color = 'grey50'
                blue = 'black'
            else:
                blue = 'blue'
                if filters[i][:3] == 'HST':
                    if self.thick:
                        color = 'magenta'
                    else:
                        #color='green'
                        #color='dark orange'
                        color='red'
                elif filters[i][-3:] == 'VLT':
                    if self.thick:
                        color = 'darkgreen'
                    else:
                        #color = 'blue'
                        color = 'magenta'
                else:  # NIC3
                    color='red'
## 	    if filters[i][0] == 'I':
## 		color='green'
	    #if efo[i] < 1:  # OBSERVED
            filtnick = filtdict.get(filters[i], 'afilta')
            filtnick = filtnick[1:-1]
            #print '%8s  %7.1f  %.3e  %.3e  %.3e' % (filtnick, lambda_m[i], fo[i], efo[i], ft[i])
            print '%8s  %7.1f  %.3e  %.3e  %.3e   %.3f' \
                % (filtnick, lambda_m[i], fo[i], efo[i], ft[i], sqrt(dfosq[i]))
	    if observed[i]:  # OBSERVED
                if max(eft) < yyymax*10:
		    #print 'max(eft) < yyymax*10'
                    rectwidth = .015 * (xrange[1] - xrange[0])
		    rectangle([lambda_m[i]-rectwidth, ft[i]-eft[i]], [lambda_m[i]+rectwidth, ft[i]+eft[i]], color=blue, linewidth=linewidth)
                    #p.add(Box([lambda_m[i]-200, ft[i]-eft[i]], [lambda_m[i]+250, ft[i]+eft[i]], color=blue, linewidth=linewidth))
                else:
		    print 'NOT max(eft) < yyymax*10'
                    plot([lambda_m[i]], [ft[i]], 'v', markersize=6, markerfacecolor='blue')
                    #plot(lambda_m,ft,type='diamond',size=6,color='blue')
                    #p.add(Points(lambda_m,ft,type='diamond',size=6,color='blue'))
		#p.add(Point(lambda_m[i], fo[i], type='filled circle',color=color,size=2))
		if fo[i]:  # DETECTED
		    #print 'color', color
                    plot([lambda_m[i]], [fo[i]], 'o', markerfacecolor=color, markeredgecolor=color, markersize=7)
		    plot([lambda_m[i], lambda_m[i]], [fo[i]-efo[i], fo[i]+efo[i]], linewidth=linewidth, color=color)
                    #plot(lambda_m[i], fo[i], type='filled circle',color=color,size=3)
		    #p.add(ErrorBarsY([lambda_m[i]],[fo[i]-efo[i]],[fo[i]+efo[i]], linewidth=linewidth))
                    yl = min([fo[i], ft[i]-eft[i]*0.7])
                    ##p.add(Label(lambda_m[i], fo[i]+yyymax*0.07, filts[i], color=color, fontface='HersheySans-Bold', fontsize=3)) #, texthalign='left'
                    #p.add(Label(lambda_m[i], yl-yyymax*0.04, filtdict[filters[i]], color=color, fontface='HersheySans-Bold', fontsize=fontsize)) #, texthalign='left'
                    #p.add(Label(lambda_m[i], (fo[i]-min(fo))*0.2, filts[i], color=color, fontface='HersheySans-Bold', fontsize=3, textvalign='bottom')) #, texthalign='left'
		else:  # NOT DETECTED
                    if 0:
                        print 'NOT DETECTED'
                        print [lambda_m[i]], [fo[i]]
                        print [lambda_m[i], lambda_m[i]], [0, efo[i]]
                    plot([lambda_m[i]], [fo[i]], 'd', markerfacecolor=color, markeredgecolor=color, markersize=7)
		    plot([lambda_m[i], lambda_m[i]], [0., efo[i]], linewidth=linewidth, color=color)
                    #plot(lambda_m[i], fo[i], type='fancy cross',color=color,size=3)
		    #p.add(ErrorBarsY([lambda_m[i]],[0],[efo[i]], linewidth=linewidth))
                    yl = yyymax*0.04
                    #p.add(Label(lambda_m[i], yl+yyymax*0.04, filtdict[filters[i]], color=color, fontface='HersheySans-Bold', fontsize=fontsize)) #, texthalign='left'
                    #yl = max([fo[i], ft[i]+eft[i]*0.7])
                    ##p.add(Label(lambda_m[i], yl+yyymax*0.04, filtdict[filters[i]], color=color, fontface='HersheySans-Bold', fontsize=3)) #, texthalign='left'
	    else:  # NOT OBSERVED
		print 'SHOULD BE AN OPEN CIRCLE!'
		plot([lambda_m[i]], [0], 'o', markerfacecolor=color, markersize=2)

        if self.thick:
            plotconfig(696)
            configure('fontsize_min', 2)
            configure('fontface', 'HersheySans-Bold')
            p.frame.spine_style['linewidth'] = 3
            p.frame.ticks_style['linewidth'] = 3
            p.frame.subticks_style['linewidth'] = 3

        if show_plots:
	    #print 'show_plots!'
            plot(xrange, [0,0], '--')
	    xlim(xrange)
	    ylim(yrange)
            print 'KILL PLOT WINOW TO TERMINATE.'
	    show()
	    #pause()
	# ZSPEC thick bw show? save?:eps/png
	if self.save_plots:
	    #outimg = self.run_name+'_sed_'+str(self.id)+'.png'
	    outimg = self.run_name+'_sed_%d.png' % id[i_id]
	    print 'SAVING', outdir + outimg
	    savefig(outdir + outimg)
	    clear()  # OR ELSE SUBSEQUENT PLOTS WILL PILE ON

	    #file_eps=self.run_name+'_'+str(self.id)+'.eps'
	    #if 'ZSPEC' in params:
	#	file_eps=self.run_name+'_'+str(self.id)+'_z=%.3f.eps'%z
        #    if self.thick:
        #        file_eps = file_eps[:-4] + '_thick.eps'
        #    if self.bw:
        #        file_eps = file_eps[:-4] + '-bw.eps'
	    #print 'Writing plot to file %s' % file_eps
            #p.save_as_eps(file_eps)
            print self.thick
            #if not self.thick:
            #    print 'Writing plot to file %s' % file_eps
            #    p.save_as_eps(file_eps)
            #else:
            #    file_png = file_eps[:-4] + '.png'
            #    print 'Writing plot to file ', file_png
            #    p.write_img(696, 696, file_png)

        
    def probs_plots(self,show_plots=1,save_plots=0):
        file_root=self.run_name+'_'+str(self.id)
        print 'Reading probability distribution data from %s' % self.probs_file
        
        probs=shelve.open(self.probs_file)
        z,p_i,p,red_chi2=tuple(probs[str(self.id)])


        nf=p_i.shape[1]
        if nf==6: colors=['red','brown','green','blue','blue','blue']
        else: colors=biggles_colors()
            
        g=FramedPlot()
        g.title='Prior probabilities for object \#%s' % self.id
        g.xlabel=r"$z$"
        g.ylabel=r"$p(z,T|I)$"
        for i in range(nf): g.add(Curve(z,p_i[:,i],color=colors[i]))
        if show_plots: g.show()
	if save_plots:
	    print 'Saving plot to %s_prior.eps' % file_root
	    g.save_as_eps(file_root+'_prior.eps')

        g=FramedPlot()
        g.title='Likelihoods for object \#%s' % self.id
        g.xlabel=r"$z$"
        g.ylabel=r"$p(C|z,T)$"
        for i in range(nf): g.add(Curve(z,p[:,i],color=colors[i]))
        if show_plots: g.show()
	if save_plots:
	    print 'Saving plot to %s_likelihoods.eps' % file_root
	    g.save_as_eps(file_root+'_likelihoods.eps')
        
        g=FramedPlot()
        g.title='Full probability for object \#%s' % self.id
        g.xlabel=r"$z$"
        g.ylabel=r"$p(z|C,I)$"
        g.add(Curve(z,sum(p_i*p,-1)))
        if show_plots: g.show()
	if save_plots:
	    print 'Saving plot to %s_full.eps' % file_root
	    g.save_as_eps(file_root+'_full.eps')        
    
    
def run():
    id_str = None
    if len(sys.argv) > 2:
	id_str = sys.argv[2]
    probs = None
    if len(sys.argv) > 3:
	probs = sys.argv[3]
    params = params_cl()
    save_plots = 'SAVE' in params
    show_plots = 1 - save_plots

    b=bpzPlots(run_name=sys.argv[1], id_str=id_str, probs=probs)    
    b.flux_comparison_plots(show_plots=show_plots, save_plots=save_plots)
    #b.flux_comparison_plots(show_plots=1,save_plots=0)
    print "SKIPPING probs"
    #b.probs_plots(show_plots=0)
    
if __name__ == '__main__':run()
else: pass
