import shelve

infile = 'gal754.probs'
#infile = 'gals.probs'
probs = shelve.open(infile)

id = 754
z, p_i, p, red_chi2 = tuple(probs[str(id)])

i = 0
clf()
plot(z, p[:,i], '-o')

z   [701]:   REDSHIFT RANGE
p_i [701,6]: PRIOR
p   [701,6]: PROBAILITY(z,t)
red_chi2: REDUCED CHI-SQUARED (A SINGLE NUMBER)


from coeplot2a import *

minmax(ravel(p_i))

i = 3
plot(z, p_i[:,i])
