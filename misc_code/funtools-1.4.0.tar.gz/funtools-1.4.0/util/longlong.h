#ifndef LONGLONG_H
#define LONGLONG_H

#if HAVE_LONG_LONG
typedef long long longlong;
#else
typedef long longlong;
#endif

#endif


