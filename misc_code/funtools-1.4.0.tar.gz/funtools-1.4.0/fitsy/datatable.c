/* datatable.c
 */

ft_tablerecread()
{

}

ft_tablerecwrite()
{

}



