#include <string.h>
#include <stdio.h>
#include <math.h>
#include <kcorrect.h>
#define FUNC(x) ((*func)(x))

float k_midpnt(float (*func)(float), float a, float b, IDL_LONG n)
{
	float x,tnm,sum,del,ddel;
	static float s;
	IDL_LONG it,j;

	if (n == 1) {
		return (s=(b-a)*FUNC(0.5*(a+b)));
	} else {
		for(it=1,j=1;j<n-1;j++) it *= 3;
		tnm=it;
		del=(b-a)/(3.0*(float)tnm);
		ddel=del+del;
		x=a+0.5*del;
		sum=0.0;
		for (j=1;j<=it;j++) {
			sum += FUNC(x);
			x += ddel;
			sum += FUNC(x);
			x += del;
		}
		s=(s+(b-a)*sum/(float)tnm)/3.0;
		return s;
	}
}
#undef FUNC
