"""
The module contains some functions which are important
for all other modules. This includes the complete error
and warning feedback and some function to deal with
fits-data.
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os, string, sys, math
import pyfits, configfile
from pyraf import iraf
from pyraf.irafpar import IrafPar,IrafParI,IrafParS, IrafParList, makeIrafPar
#from axedrizzle import *

AXE_IMAGE_PATH   = './'
AXE_OUTPUT_PATH  = './'
AXE_CONFIG_PATH  = './'
AXE_DRIZZLE_PATH = './'


class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

def report_error(code, **keywords):
    """
    Input:
        code       - error code
        **keywords - list of keywords to give conclusive error messages

    Return:
        -

    Description:
        The function handles the error reporting of the whole axe-1.4
	python package. The function is called with a certain error code
	and, depending on the error code, one or several keywords as
	parameters. The error message is printed on the screen
	to give with the keyword parameters a meaningful feedback to
	the user. Then the an AXeError is raised.
    """

    if code == 10:
	estring = 'Kewyword: '+str(keywords['it'])+' missing in '+\
		  str(keywords['img'])+'['+str(keywords['ex'])+']'
    elif code == 110:
	estring = 'Neither '+str(keywords['cfile1'])+' nor '+\
		  str(keywords['cfile2'])+' exist!'
    elif code == 120:
	estring = 'AXEPREP: The number configuration files: '+\
		  str(keywords['cterm'])+\
		  '\n                   does not match the number of background\n'+\
		  '                   images: '+str(keywords['bterm'])
    elif code == 130:
	estring = 'AXEPREP: The number of object lists in: '+\
		  str(keywords['objcats'])+' does not\n'+\
		  '                   match the number of config files in: '+\
		  str(keywords['confs'])
    elif code == 140:
	estring = 'AXEPREP: The cr-flag image '+str(keywords['image'])+' is missing!'
    elif code == 150:
	estring = 'AXEPREP: The mask image '+str(keywords['image'])+' is missing!'
    elif code == 160:
	estring = 'AXEPREP: '+str(keywords['indata'])+' provides not enough input!'
    elif code == 165:
	estring = 'AXEPREP: No second normalization of images!'
    elif code == 170:
	estring = 'AXEPREP: Problems updating dq of: '+str(keywords['image'])+' !'
    elif code == 175:
	estring = 'AXEPREP: With back="YES" the name of the background image(s)\n'+\
		  '                   must be given!'
    elif code == 180:
	estring = 'AXEPREP: Problems normalizing of: '+str(keywords['image'])+' !'
    elif code == 185:
	estring = 'AXEPREP: Image list: '+str(keywords['dterm'])+' not available!'
    elif code == 190:
	estring = 'AXEPREP: Configuration file: '+str(keywords['cterm'])+' not available!'
    elif code == 195:
	estring = 'AXEPREP: Background image: '+str(keywords['bterm'])+' not available!'
    elif code == 210:
	estring = 'The first term in: '+str(keywords['input'])+' MUST be a string!'
    elif code == 220:
	estring = 'Not enough information found in: '+str(keywords['input'])+'.\n'+\
		  '          There must be at least '+str(keywords['minlen'])+'items!'
    elif code == 230:
	estring = 'The second term in: '+str(keywords['input'])+' MUST be a string!'
    elif code == 240:
	estring = 'The term for "dmag" in: '+str(keywords['input'])+' MUST be a number!'
    elif code == 305:
	estring = 'AXECORE: The Input Object Catalogue: '+str(keywords['incat'])+' does\n'+\
		  '                   NOT have a proper magnitude column!'
    elif code == 310:
	estring = 'AXECORE: The parameter "backfwhm" must be set to create background PETs!'
    elif code == 315:
	estring = 'AXECORE: The Input Object Catalogue: '+str(keywords['incat'])+' needs\n'+\
		  '                   at least one magnitude column which encodes the wavelength\n'+\
		  '                   to compute the contamination with Gaussian emission model!'
    elif code == 320:
	estring = 'AXECORE: The parameters "np" and "interp" must be set to create\n'+\
		  '                   background PETs!'
    elif code == 325:
	estring = 'AXECORE: Drizzled stamp images are not supported for prism data!\n'+\
		  '                   Choose a different sampling!'
    elif code == 330:
	estring = 'AXECORE: The numbe of object lists in: '+str(keywords['objcats'])+\
		  ' does not\n                   match the number of config files in: '+\
		  str(keywords['confs'])
    elif code == 335:
	estring = 'AXECORE: Optimal weigthing needs quantitative contamination!\n' + \
		  '         Please change to either the gaussian or fluxcube contamination\n' +\
		  '         model or drop optimal weighting!'
    elif code == 340:
	estring = 'AXECORE: The parameter "extrfwhm" must be set to create PETs!'
    elif code == 345:
	estring = 'AXECORE: Extraction width: '+str(keywords['efwhm'])+' and background extraction\n'+\
		  '                      width '+str(keywords['bfwhm'])+' must both be either POSITIVE or NEGATIVE!\n'
    elif code == 350:
	estring = 'AXECORE: Configuration file: '+str(keywords['cterm'])+' not available!'
    elif code == 355:
	estring = 'AXECORE: Extraction width: '+str(keywords['efwhm'])+' and drizzle extraction\n'+\
		  '                      width '+str(keywords['dfwhm'])+' must both be either POSITIVE or NEGATIVE!\n'
    elif code == 360:
	estring = 'AXECORE: Image list: '+str(keywords['dterm'])+' not available!'
    elif code == 365:
	estring = 'AXECORE: The fluxcube model is not applicable for prism data!!'
    elif code == 370:
	estring = 'AXECORE: Negative object extraction width: '+str(keywords['mfwhm'])+\
		  '\n                   does not make sense with orient="YES"!'
    elif code == 375:
	estring = 'AXECORE: Direct Image must be given for prism observations!'
    elif code == 380:
	estring = 'AXECORE: Background extraction width: '+str(keywords['mfwhm'])+\
		  '\n                   does not make sense!'
    elif code == 385:
	estring = 'AXECORE: Drizzle extraction width: '+str(keywords['dfwhm'])+' must be\n'+\
		  '                   SMALLER that object extraction width: '+str(keywords['efwhm'])+'!\n'
    elif code == 390:
	estring = 'AXECORE: Object extraction width: '+str(keywords['ifwhm'])+' must be\n'+\
		  '                      SMALLER that input extraction width: '+str(keywords['ofwhm'])+'!\n'
    elif code == 395:
	estring = 'AXECORE: Drizzle extraction width: '+str(keywords['mfwhm'])+\
		  '\n                   does not make sense!'
    elif code == 410:
	estring = 'AXEDRIZZLE: Configuration file: '+str(keywords['cterm'])+' not available!'
    elif code == 420:
	estring = 'AXEDRIZZLE: Image list: '+str(keywords['inlist'])+' not available!'
    elif code == 430:
	estring = 'AXEDRIZZLE: Extraction width: '+str(keywords['efwhm'])+' and drizzle extraction\n'+\
		  '                      width '+str(keywords['dfwhm'])+' must both be either POSITIVE or NEGATIVE!\n'
#    elif code == 430:
#	estring = 'AXEDRIZZLE: Input extraction width: '+str(keywords['fwhm'])+\
#		  '\n                      does not make sense!'
    elif code == 450:
	estring = 'AXEDRIZZLE: Output extraction width: fabs('+str(keywords['ofwhm']) + ') must be\n'+\
		  '                      SMALLER than background extraction width: fabs('+str(keywords['ifwhm'])+')!'
    elif code == 460:
	estring = 'AXEDRIZZLE: Invalid literal: '+str(keywords['item']) + ' in\n'+\
		  '                      in background extraction width: '+str(keywords['ofwhm'])
    elif code == 470:
	estring = 'AXEDRIZZLE: The object PET "'+ keywords['opet'] + '" does not\n'+\
		  '                      exist. Please create it in an axedrizzle run\n'+\
		  '                      with back="NO" before drizzling the background DPP\'s!'
    elif code == 480:
	estring = 'AXEDRIZZLE: The kernel"'+ keywords['kernel'] + '" is not supported.'
    elif code == 510:
	estring = keywords['command'] + ': the file ' + keywords['filename'] + ' does not exist!'
    elif code == 610:
	estring = 'An error occured during the execution of the external comand: \n"' +\
		  keywords['command'] +\
		  '"\nPlease run the command within pyraf to get a detailed error message!\n' +\
		  'A possible reason for the error might be the usage of a non standard flt-image.'
    else:
	estring = 'AXE: An error occured!'

    raise AXeError, estring

def report_warning(code, **keywords):
    """
    Input:
        code       - warning code
        **keywords - list of keywords to give conclusive warning messages

    Return:
        ret        - integer code

    Description:
        The function handles the warning reports of the whole axe-1.4
	python package. The function is called with a certain warning
	code and, depending on the error code, one or several keywords
	as parameters.
	One warning scenario demands interaction from the user.
	The function either exists the program execution or
	gives feedback to the calling function with an integer code. 
    """
    if code == 110:
	print ''
	print 'AXEPREP: Image: ', keywords['image'], 'has just been normalized!'

        idec = IrafParS(['         Normalize it again?[(y)es/(n)o/(q)uit] :(q)','string','h'],'whatever')
	idec.getWithPrompt()
	dec = string.strip(idec.value)
	if dec.upper() == 'Y':
	    print     '         Continue!'
	    print     ''
	    return 1
	elif dec.upper() == 'N':
	    print     '         Not normalizing image',keywords['image'],'!'
	    print     ''
	    return 0
	else:
	    print     ''
	    report_error(165)
    elif code == 120:
	print ''
	print 'AXEPREP: WARNING: Image ', keywords['image']
	print '                  is just background subtracted!'
	print ''
    elif code == 130:
	print ''
	print 'AXEPREP: WARNING: DQ extension of image ', keywords['image']
	print '                  was just updated!'
	print ''
    elif code == 140:
	print ''
	print 'No drizzle scale known for image: ', keywords['image']
	print '                  This might cause problems later on.'
	print ''
    elif code == 210:
	print ''
	print 'AXEDRIZZLE: There was a problem drizzling image:', keywords['image'], '!'
	print '            The program continues.'
	print ''
    elif code == 310:
	print ''
	print 'FCUBEPREP:  There was a problem blotting image:', keywords['image1'], ' to: ', keywords['image2'], '!'
	print '            The program continues.'
	print ''
    return 1

def get_header(image, ext=0, ver=1, list=None, error=1):
    """
    Input:
        image   - the image name
        ext     - the image extension (default='0')
	ver     - the extension version (default='1')
	list    - item list to check keyword against (default='None')
	error   - report error and break if 1, return None if 1

    Return:
        kheader - all the keywords of the imag/extension

    Description:
        The function retrieves the complete header of the images extension
	version specified in the parameters. The header is checked for the
	existence of the keywords listed in the parameter 'list'.
	If one of the listed keywords does not exist the program returns
	either 'None' (for error=0) or involes an error message (error!=0)
    """
    fimg = pyfits.open(image)
    if ext==0:
	kheader = fimg[ext].header
    else:
	kheader = fimg[ext,ver].header
    fimg.close()
    item = None
    if list != None:
	item = check_header(kheader, list)
    if item != None:
	if error == 1:
	    report_error(10, img=image, ex=ext, it=item)
	else:
	    return None
    return kheader

def check_header(header, list):
    """
    Input:
        image   - a fits header
        list    - a list of items

    Return:
        None - in case that all items are in the header
        item - in case that this requested item is missing

    Description:
        The function checks an image header for the existence
	of a set of keyword given in the parameter 'list'.
	Returns the first undetected keyword or 'None'
	if all keywords are in the header.
    """
    for item in list:
	success = header.has_key(item)
	if success == 0:
	    return item
    return None

def get_environments():
    """
    Input:
        - None

    Return:
        ret - the number of environmental variables
              found

    Description:
        The function checks for the existence of the environmental
	variables which are used in axe to direct in/output. 
	The values stored in the environmental variables are
	stored in global variables of the same name.
    """
    global AXE_IMAGE_PATH
    global AXE_OUTPUT_PATH
    global AXE_CONFIG_PATH
    global AXE_DRIZZLE_PATH
    allkeys = ['AXE_IMAGE_PATH','AXE_OUTPUT_PATH',
	       'AXE_CONFIG_PATH','AXE_DRIZZLE_PATH']

    ret = 0

    for akey in allkeys:
	try:
	    env = os.environ[akey]
	except KeyError:
	    print akey, 'not defined'
	    continue
	if akey == 'AXE_IMAGE_PATH':
	    AXE_IMAGE_PATH   = env
	    ret = ret+1
	elif akey == 'AXE_OUTPUT_PATH':
	    AXE_OUTPUT_PATH  = env
	    ret = ret+1
	elif akey == 'AXE_CONFIG_PATH':
	    AXE_CONFIG_PATH = env
	    ret = ret+1
	elif akey == 'AXE_DRIZZLE_PATH':
	    AXE_DRIZZLE_PATH = env
	    ret = ret+1
    return ret

def putCONF(name):
    """
    Input:
        name - the sequence to put behind the global variable

    Return:
        tmp  - the content of the global variable 'AXE_CONFIG_PATH'
	       + the input parameter appended.

    Description:
        Appends the input parameter behind the content of the
	(gloal) variable 'AXE_CONFIG_PATH'. Checks for
	multiple directory indicators ('/') before returning
	the result
    """
    if name == None:
	tmp = AXE_CONFIG_PATH + '/'
    else:
	tmp = AXE_CONFIG_PATH + '/' + string.strip(name)
    tmp = tmp.replace('//','/')
    return tmp

def putIMAGE(name):
    """
    Input:
        name - the sequence to put behind the global variable

    Return:
        tmp  - the content of the global variable 'AXE_IMAGE_PATH'
	       + the input parameter appended.

    Description:
        Appends the input parameter behind the content of the
	(gloal) variable 'AXE_IMAGE_PATH'. Checks for
	multiple directory indicators ('/') before returning
	the result
    """
    if name == None:
	tmp = AXE_IMAGE_PATH + '/'
    else:
	tmp = AXE_IMAGE_PATH + '/' + string.strip(name)
    tmp = tmp.replace('//','/')
    return tmp

def putOUTPUT(name):
    """
    Input:
        name - the sequence to put behind the global variable

    Return:
        tmp  - the content of the global variable 'AXE_OUTPUT_PATH'
	       + the input parameter appended.

    Description:
        Appends the input parameter behind the content of the
	(gloal) variable 'AXE_OUTPUT_PATH'. Checks for
	multiple directory indicators ('/') before returning
	the result
    """
    if name == None:
	tmp = AXE_OUTPUT_PATH + '/'
    else:
	tmp = AXE_OUTPUT_PATH + '/' + string.strip(name)
    tmp = tmp.replace('//','/')
    return tmp

def putDRIZZLE(name):
    """
    Input:
        name - the sequence to put behind the global variable

    Return:
        tmp  - the content of the global variable 'AXE_DRIZZLE_PATH'
	       + the input parameter appended.

    Description:
        Appends the input parameter behind the content of the
	(gloal) variable 'AXE_DRIZZLE_PATH'. Checks for
	multiple directory indicators ('/') before returning
	the result
    """
    if name == None:
	tmp = AXE_DRIZZLE_PATH + '/'
    else:
	tmp = AXE_DRIZZLE_PATH + '/' + string.strip(name)
    tmp = tmp.replace('//','/')
    return tmp

def get_extnum_axe(sciext, image, optkey=None, optval=None):
    """
    Input:
        sciext - the string information given in the 'SCIENCE_EXT' keyword of
	         the configuration file
        image  - the image name
	optkey - the possible optkey given in the configuration file
	optval - the value which optkey has in the matching extension

    Return:
        scinumext - the extension number in the axe format

    Description:
        The function executes the task catfits and searches for the extension
	which matches the string value given in the input, and perhaps
	has the correct value in the keyword given by the input "optkey".
	The result is given in axe-format where the primary header
	is 1 and the first extension 2 and so on.
    """

    allinfo = iraf.catfits( fits_file=putIMAGE(image), file_list='',
			    long_header='no', format_file='', log_file='',
			    short_header='YES', ext_print='YES', offset=0,
			    Stdout=1)
    scinumext=-1
    for info in allinfo:
	line = string.split(info)
	if len(line)>3 and string.strip(line[1]) =="IMAGE" and string.strip(line[2]) == sciext:
	    if optkey == None:
		scinumext=int(string.strip(line[0]))+1
	    else:
		hlist = [optkey]
		kheader = get_header(putIMAGE(image), ext='SCI', ver=int(string.strip(line[3])),
				     list=hlist, error=0)
		if str(kheader[optkey]) == str(optval):
		    scinumext=int(string.strip(line[0]))+1
		
		
    return scinumext

def get_sciextnum(image, conf):
    """
    Input:
        image - the image name
	conf  - the configuration name

    Return:
        scinum - the numeric value of the science
	         extension (axe format)

    Description:
        The function return the science extension targeted by the configuration
	file as a number in axe-format (prim-header=1, first extension=2 ...)
	In case the science extension is given as a number,
	this number is returned. If the number is not just given,
	the function "get_extnum_axe" gets is.
    """
    if isstringlike(conf.get_gvalue('SCIENCE_EXT')):
	if conf.get_gkey('OPTKEY1') and int(conf.get_gvalue('OPTVAL1')) > 0:
	    scinum = get_extnum_axe(conf.get_gvalue('SCIENCE_EXT'), image,
				    conf.get_gvalue('OPTKEY1'), conf.get_gvalue('OPTVAL1'))	    
	else:
	    scinum = get_extnum_axe(conf.get_gvalue('SCIENCE_EXT'), image)
    else:
	scinum = conf.get_gvalue('SCIENCE_EXT')

    return scinum

def get_versnum_axe(image,versnum):
    """
    Input:
        versnum - the numeric extension number in 'axe'-format
	image 

    Return:
        extvers - the extension version for this numeric extension

    Description:
        The function executes the iraf task 'catfits' and analyzes
	the outcome. Axe and catfits count the extensions
	in a different way: axe counts the prime header as 1, and the first
	extension as two. In catfits the prime header is 0, and the first extension
	is 1. The extension version for the given numeric extension is given
	back.
    """
    allinfo = iraf.catfits( fits_file=putIMAGE(image), file_list='',
			    long_header='no', format_file='', log_file='',
			    short_header='YES', ext_print='YES', offset=0,
			    Stdout=1)
    extvers=-1
    for info in allinfo:
	line = string.split(info)
	if len(line)>3:
	    if string.strip(line[1]) =="IMAGE" and int(string.strip(line[0])) == versnum-1:
		extvers=int(string.strip(line[3]))
    return extvers

def get_all_versnums(image, targex):
    """
    Input:
        image  - the image name
	targex - the target extension

    Return:
        extvers - a list of extension numbers which exist in the image
	         for the target extension

    Description:
        List all the extension versions which exist for a target extension.
	This is done by executing the catfits task on the image and
	analysing the output. The fourth item lists the extension version
	number. This number is put into a list, and the list is returned at
	the end.
    """
    allinfo = iraf.catfits( fits_file=putIMAGE(image), file_list='',
			    long_header='no', format_file='', log_file='',
			    short_header='YES', ext_print='YES', offset=0,
			    Stdout=1)
    extvers = []
    for info in allinfo:
	line = string.split(info)
	if len(line)>3:
	    if string.strip(line[1]) =="IMAGE" and string.strip(line[2]) == targex:
		extvers.append(int(string.strip(line[3])))
    return extvers
    

def get_sciextvers(image, conf):
    """
    Input:
        image - the image name
	conf  - the configuration file

    Return:
        scivers - the version number of the science extension which
	          is targeted by the configuration file

    Description:
        The science extension version can be given in three scenarios:
	a) the SCIENCE_EXT keyword is given as a numeric in the axe-format
	b) the SCIENCE_EXT keyword is given a a string (e.g. 'SCI')
	   + the optional keywords OPTKEY1 and OPTVAL1 are given
	c) only the SCIENCE_EXT keyword is given (no OPTKEY1 and OPTVAL1)

	for c) the extension version is assumed to be unique, since
	no further specification can be made, therefore the version is
	said to be '1'.
	for a) the extension version is determined with the function
	"get_versnum_axe"
	for b) the total number of extension versions is determined,
	and each one is checked for a matching OPTKEY1/OPTVAL1
    """
#    allconf = conf.get_config()
#    if isstringlike(allconf['SCIENCE_EXT']):
    if isstringlike(conf.get_gvalue('SCIENCE_EXT')):
#	if allconf.has_key('OPTKEY1'):
	if conf.get_gkey('OPTKEY1') != None:
	    hlist = [conf.get_gvalue('OPTKEY1')]
	    extvers = get_all_versnums(image,'SCI')
	    for num in extvers:
		kheader = get_header(putIMAGE(image), ext='SCI', ver=num, list=hlist, error=0)
		if str(kheader[conf.get_gvalue('OPTKEY1')]) == str(conf.get_gvalue('OPTVAL1')):
		    scivers = num
	else:
	    scivers = 1
    else:
	scivers = get_versnum_axe(image, int(conf.get_gvalue('SCIENCE_EXT')))
    return scivers


def isstringlike(item):
    """
    Input:
        item - the item to be checked

    Return:
        1/0  - if tiem is a pure string or not

    Description:
        Checks an item whether it is a pure string or not.
	A pure string means it can not be transformed to a float.
    """
    try: float(item)
    except: return 1
    else:   return 0

def resolve_configs(confterm):
    """
    Input:
        confterm - the term to be split up

    Return:
        conflist - the list with split items

    Description:
        Splits up a comma separated term (without blanks) into
	a list with the individual items.
    """
    conflist = string.split(string.strip(confterm),',')
    return conflist

def resolve_ofwhm(extr_out):
    """
    Input:
        extr_out - list with the output fwhm's

    Return:
        extrlist - the list with output fwhm's as ascending floats

    Description:
        Splits up a comma separated term (without blanks) into
	a list with the individual items.
    """
    extrlist = []

    tmp = string.split(string.strip(extr_out),',')

    for item in tmp:
	try:
	    extrlist.append(float(item))
	except ValueError:
	    report_error(460, item=item, ofwhm=extr_out)
    extrlist.sort()
    return extrlist

def parse_indata(data, minlen):
    """
    Input:
        data   - a data line from 'inlist'
	minlen - the minimum number of items which must
	         be present

    Return:
        axeitem - a dictionary with the various items stored
	          in the input data

    Description:
        The function separates a line in the task parameter 'inlist'
	into the different components. With minlen you can specify
	the minimum amount of items which have to be present.
	if there are less items, an error is launched.
	The logic is:
	 - first item:  grism image
	 - second item: comma separated list of object cataloges
	 - third item:  direct image if string, dmag value of grism image
	                if no string
	 - fourth item: dmag value for the grism image
    """
    axeitem = {}

    axeitem['DIRIM'] = ''
    axeitem['DMAG'] = 0.0

    stritems = string.split(data)

    if isstringlike(stritems[0]):
	axeitem['GRISIM'] = stritems[0]
    else:
	report_error(210, input=string.strip(data))

    if len(stritems) < minlen:
	report_error(220, input=string.strip(data), minlen=minlen)
  
    if len(stritems) > 1:
	if isstringlike(stritems[1]):
	    if string.find(stritems[1],',') > -1:
		objcats = string.split(stritems[1],',')
		axeitem['OBJCATS'] = objcats
	    else:
		objcats = []
		objcats.append(string.strip(stritems[1]))
		axeitem['OBJCATS'] = objcats
	else:
	    report_error(230, input=string.strip(data))

    if len(stritems) > 2:
	if isstringlike(stritems[2]):
	    axeitem['DIRIM'] = stritems[2]
	else:
	    axeitem['DMAG'] = stritems[2]

    if len(stritems) > 3:
	if  not isstringlike(stritems[3]):
	    axeitem['DMAG'] = stritems[3]
	else:
	    report_error(240, input=string.strip(data))

    return axeitem

def check_indata(command, axeitem):
    """
    Input:
        command - the name of the calling aXe task
	axeitem - the dictionary with the input

    Return:
        -

    Description:
        The method checks the files in the input data for
	existence.    
    """
    # Look whether a direct image name is given.
    # Check whether it exists.
    if axeitem.has_key('DIRIM') and len(string.strip(axeitem['DIRIM'])) > 0:
	if not os.path.isfile(putIMAGE(axeitem['DIRIM'])):
	    report_error(510, command=command, filename=putIMAGE(axeitem['DIRIM']))
    
    # Look whether a grism image name is given.
    # Check whether it exists.
    if axeitem.has_key('GRISIM') and len(string.strip(axeitem['GRISIM'])) > 0:
	if not os.path.isfile(putIMAGE(axeitem['GRISIM'])):
	    report_error(510, command=command, filename=putIMAGE(axeitem['GRISIM']))

    
    # Look whether names of Input Object Lists are given
    # Check whether they exists.
    if axeitem.has_key('OBJCATS') and len(axeitem['OBJCATS']) > 0:
	for cat in axeitem['OBJCATS']:
	    if len(string.strip(cat)) > 0 and not os.path.isfile(putIMAGE(string.strip(cat))):
		report_error(510, command=command, filename=putIMAGE(string.strip(cat)))

def check_IOLcolumns(axeitem, cont_model):
    import axecat
    if axeitem.has_key('OBJCATS') and len(axeitem['OBJCATS']) > 0:
	for cat in axeitem['OBJCATS']:
	    acat = axecat.AXeCat(putIMAGE(string.strip(cat)))
	    success = acat.setaxecols()
	    if success:
		report_error(305, incat=putIMAGE(string.strip(cat)))

	    if cont_model == 'gauss' and not acat.magwave:
		report_error(315, incat=putIMAGE(string.strip(cat)))

def check_prism(axeitem, cont_model, sampling):
    """
    Input:
	axeitem    - the dictionary with the input
        cont_model - the name of the contamination model
        sampling   - requested sampling for stamp images
    Return:
        -

    Description:
        Does some additional checks for prism images. There
	special conditions have to be applied.
    """
    # read the filter keywords from the image 
    hlist = ['FILTER1', 'FILTER2']
    header = get_header(putIMAGE(axeitem['GRISIM']), list=hlist, error=0)

    # check whether it is prism data
    if header and (header['FILTER1'].find('PR') > -1  or header['FILTER2'].find('PR') > -1):

	# prism data MUST have a direct image
	if not axeitem.has_key('DIRIM') or len(string.strip(axeitem['DIRIM'])) < 1:
	    report_error(375)

	# the fluscube contamination does not work for prism data
	if cont_model.lower() == "fluxcube":
	    report_error(365)

	# drizzled stamp images are not supported for prism data
	if sampling.lower() == "drizzle":
	    report_error(325)
	    

def check_dpps(command, conflist, inlist, bckmode):
    """
    Input:
        command  - the name of the invoking axe task
	conflist - a list with configuration filenames
	inlist   - the list with grims images
	bckmode  - the flack for backmode

    Return:
        -
	
    Description:
        The module derives fo a list of configuration files
	and a list of grim images the names of the associated
	DPP files and checks whether those DPP files
	exist at 'AXE_OUTPUT_PATH'. AN error is reported if
	a DPP file does not exist.
    """
    
    # go over all the configuration files
    for citem in conflist:

	# load the configuration
	conf = configfile.ConfigFile(putCONF(citem))
	success = conf.drizzle_check()
	if success == 1:
	    report_error(480, kernel=conf.get_gvalue('DRZKERNEL'))

	# open the list with input grism images
	datlist = file(inlist, 'r')
	alllist = datlist.readlines()
	datlist.close()

	# go over the grism image list
	for item in alllist:

	    # skip comments or empty lines
	    if len(string.strip(item)) == 0 or item[0] == '#':
		continue
	    sitem = string.strip(string.split(item)[0])

	    # check whether the grism image exists
	    if not os.path.isfile(putIMAGE(sitem)):
		report_error(510, command=command, filename=putIMAGE(sitem))

	    # get the science extension number
	    scinum = get_sciextnum(sitem, conf)

	    # form the DPP name
	    dppname, dppname_alt = get_dppname(sitem, scinum, bckmode)

	    # check whether the DPP exists
	    if not os.path.isfile(putOUTPUT(dppname)):
		report_error(510, command=command, filename=putOUTPUT(dppname))

def check_flxs(command, conflist, axeitem):
    """
    Input:
        command  - the name of the invoking axe task
	conflist - a list with configuration filenames
	inlist   - the list with grims images

    Return:
        -
	
    Description:
        The module derives fo a list of configuration files
	and a list of grim images the names of the associated
	FLX files and checks whether those FLX files
	exist at 'AXE_OUTPUT_PATH'. AN error is reported if
	a FLX file does not exist.
    """
    
    # goo over all the configuration files
    for citem in conflist:

	# load the configuration
	conf = configfile.ConfigFile(putCONF(citem))


	# go over the grism image list
	for item in axeitem:

	    # get the science extension number
	    scinum = get_sciextnum(item['GRISIM'], conf)

	    # form the FLX name
	    flxname    = get_flxname(item['GRISIM'], scinum)

	    # check whether the FLX exists
	    if not os.path.isfile(putIMAGE(flxname)):
		report_error(510, command=command, filename=putIMAGE(flxname))


def get_flxname(image, scinum):
    """
    Input:
        image   - the grism image name
	scinum  - the extension number in axe format

    Return:
        the name of the FLX file
	
    Description:
        Take the grism image name, the science extension number
	and return the name of the associated FLX frame.
	Example:
    
	j8m822qbq_flt.fits -> j8m822qbq_flt_2.FLX.fits
    """  
    return string.split(image,'.fits')[0] + '_' + str(scinum) + '.FLX.fits'

def get_dppname(image, scinum, bckmode):
    """
    Input:
        image   - the grism image name
	scinum  - the extension number in axe format
	bckmode - flagg set if background DPP are used

    Return:
        the name of the DPP file
	
    Description:
        Take the grism image name, the science extension number
	and the mode and return the name of the DPP frame.
	Example:
    
	j8m822qbq_flt.fits -> j8m822qbq_flt_2.DPP.fits
    """
    obj_dpp_name = string.split(image,'.fits')[0] + '_' + str(scinum) + '.DPP.fits'
    bck_dpp_name = string.split(image,'.fits')[0] + '_' + str(scinum) + '.BCK.DPP.fits'
    if bckmode:
	return bck_dpp_name,  obj_dpp_name
    else:
	return obj_dpp_name, bck_dpp_name


def is_quant_contmodel(cont_model):
    """
    Input:
        cont_model - the name of the emission model

    Return:
        isquant - 1 in case of a quantitative model,
	           0 if not

    Description:
        The module checks whether a contamination model
	is quantitative or not.
    """

    quant_models = ['gauss', 'fluxcube']

    isquant=0
    
    if string.lower(cont_model) in quant_models:
	isquant=1

    return isquant
	
def get_flambda_from_magab(mag, wlength):
    """
    /**
    * 
    * Function: get_flambda_from_magab
    * The subroutine calculates the flambda value for a
    * mag_AB value given with its wvavelength as input
    * parameters.
    *
    * Parameters:
    * @param  mag     - the mag_AB value
    * @param  lambda  - the wavelength for mag_AB [nm]
    *
    * Returns:
    * @return flambda - the calculated flambda value
    */
    double
    get_flambda_from_magab(double mag, double lambda)
    {
    double flambda=0.0;
    double fnu=0.0;
    
    fnu     = pow(10.0, -0.4*(mag+48.6));
    flambda = 1.0e+16*LIGHTVEL*fnu/(lambda*lambda);
    
    return flambda;
    };
    """

    fnu     = math.pow(10.0, -0.4*(mag+48.6))
    flambda = 2.99792458e+16*fnu/(wlength*wlength)

    return flambda

def get_stmag_from_magab(mag, wlength):
    
    flambda = get_flambda_from_magab(mag, wlength)
    stmag = -2.5*math.log10(flambda) - 21.10
    return stmag

def get_random_filename(dirname, ext):
    import random

    # assure a first go in the while loop
    found = 1

    # do until you find a unique name
    while found:

	# get a random int number
	str_num = str(random.randint(10000, 99999))

	# compose a random name
	fname = dirname + 'tmp' + str_num + ext

	# check whether the file exists
	if not os.path.isfile(fname):
	    found = 0

    return fname

def unlearn_axe():
    """
    Input:
        -

    Return:
        -
    Description:
        Unlearns all aXe task to prevent previous parameters
        from sneaking int the High Level Tasks.
    """

    # the list of all tasks to be unlearned
    tasks = ['af2pet',  'petcont',
             'backest', 'gol2af', 'petff',
             'drz2pet', 'sex2gol',
             'pet2spc', 'stamps']

    # go over all tasks
    for task in tasks:
        # unlearn the task
        iraf.unlearn(task)

def unlearn_daxe():
    """
    Input:
        -

    Return:
        -
    Description:
        Unlearns all aXe task to prevent previous parameters
        from sneaking int the High Level Tasks.
    """

    # the list of all tasks to be unlearned
    tasks = ['daf2pet', 'dpetcont',
             'dbackest', 'dgol2af', 'dpetff',
             'ddrz2pet', 'dsex2gol',
             'dpet2spc', 'dstamps']

    # go over all tasks
    for task in tasks:
        # unlearn the task
        iraf.unlearn(task)
