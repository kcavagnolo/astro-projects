import string
import os
import configfile

class Aperture(object):

    def __init__(self, aperID, beamList):

	# initialize the beam list
	self._beamList = []

	# set the aperture ID
	self.aperID = aperID
	
	# go over all incoming beams
	for beam in beamList:
	    
	    # check whether the aperture ID's coincide
	    if beam.aperID != self.aperID:

		# raise an exception
		raise 'Beam ID: ' + str(beam.aperID) + ' does NOT fit to aperture ID: ' + str(self.aperID)
	    else:

		# append the beam to the list
		self._beamList.append(beam)


    def __str__(self):

	# initialize the string
	bigString = ''

	# put in the start marker
	bigString += 'APERTURE ' + str(self.aperID) + '\n'

	# go over all beams
	for beam in self._beamList:

	    # add the current beam
	    bigString += str(beam)

	# put in the end marker
	bigString += 'APERTURE END\n'

	return bigString

    def __len__(self):
        """
        Simple length operator
        """
        return len(self._beamList)

    def __getitem__(self, beamID):
	
	# find the index of the requested item
	index = self._find_beamID(beamID)


	# check whether the item was found
	if index  > -1:
	    # return the identified item
	    return self._beamList[index]
        elif len(self) ==  1:
            # return the only beam
	    return self._beamList[0]            
	else:
	    # return NULL
	    return None

    def _find_beamID(self, beamID):

	# set the default return value
	found = -1

	# go over all items
	for index in range(len(self._beamList)):
	    # check whether it is the right item
	    if self._beamList[index].beamID == beamID:
		# set the return value to the index
		found = index

	# return the result
	return found

class Beam(object):

    def __init__(self, aperID, beamID, keyList):

	self.aperID   = aperID
	self.beamID   = beamID
	self._keyList = self._extract_keywords(aperID, beamID, keyList)

    def __str__(self):

	# initialize the string
	bigString = ''

	# put in the start marker
	bigString += '  BEAM ' + str(self.beamID) + '\n'

	# loop over rall keywords
	for keyword in self._keyList:

	    # check whether there is content
	    if keyword.keyvalue:
		
		# compose the beam keyword
		comp_key =  self._get_aperbeam_keyword(keyword.keyword,
						       self.aperID,self.beamID)
		# add the keyword string
		bigString += '    ' + comp_key + ' ' \
			     + str(keyword.keyvalue) + ' ; ' \
			     + keyword.comment + '\n'

	# add the end marker
	bigString += '  BEAM END\n'

	# return the whole string
	return bigString
	

    def __getitem__(self, kword):
	
	# find the index of the requested item
	index = self._find_item_index(kword)

	# check whether the item was found
	if index  > -1:
	    # return the identified item
	    return self._keyList[index].keyvalue
	else:
	    # return NULL
	    return None

    def _find_item_index(self, item):

	# set the default return value
	found = -1

	# go over all items
	for index in range(len(self._keyList)):
	    # check whether it is the right item
	    if self._keyList[index].keyword == item:
		# set the return value to the index
		found = index

	# return the result
	return found

    def _extract_keywords(self, aperID, beamID, keyList):

	# initialize the list
	list = []

	# the list of possible keyword roots
	klist = ['REFPIXEL', 'CORNERS', 'CURVE', 'WIDTH', 'ORIENT',
		 'AWIDTH', 'BWIDTH', 'AORIENT', 'FLUX', 'IGNORE']


	# fo over the keyword root list
	for key in klist:
	    
	    list.append(self._find_key(key, aperID, beamID, keyList))
	    

	# return the list of extracted
	# keywords
	return list


    def _find_key(self, keyword, aperID, beamID, keylist):
	"""
	Extract a certain keyword from the list

	The methods searches for a particular keyword
	in a keyword list. If found, the keyword is
	copied and destroied in the input list.
	If not found, an exception is fired.

        @param keyword: the keyword name
        @type keyword: string
        @param keylist: list of keywords
        @type keylist: [ConfKey]

	@return: the extracted keyword
        @rtype: ConfKey
	"""

	# initialize the index
	iindex = 0
	
	# set indicator to "not found"
	found = -1

	comp_keyword = self._get_aperbeam_keyword(keyword, aperID, beamID)

	# go over all keys in the list
	for key in keylist:

	    # checke whether the keyword is the desired one
	    if key.keyword == comp_keyword:
		# create a list keyword if desired
		nkey = configfile.ConfKey(keyword, key.keyvalue,
                                          key.comment)

		# store the index
		found = iindex

	    # enhance the index
	    iindex += 1

	# fire an exception if nothing was found
	if found < 0:
	    nkey = configfile.ConfKey(keyword, None)
	# delete the keyword from the inlist
	else:
	    del keylist[found]

	# return the keyword
	return nkey

    def _get_aperbeam_keyword(self, keyword, aperID, beamID):

	return keyword + str(aperID) + str(beamID)



class OAFFile(object):
    
    def __init__(self, filename=None):

	# check if a filename is given
	if filename is None or not os.path.isfile(filename):
	    # load the default
	    print 'No file given, can do nothing!!'

	else:
	    # safe the file name
	    self.filename = filename

	    self.apertures = self._load_OAF(filename)

    def __str__(self):

	# initialize the string
	bigString = ''

	# go over all apertures
	for aper in self.apertures:

	    # add the aperture string
	    bigString += str(aper)

	# return the string
	return bigString


    def __len__(self):
        """
        Simple length operator
        """
        return len(self.apertures)

    
    def __getitem__(self, aperID):
	
	# find the index of the requested item
	index = self._find_aperID(aperID)

	# check whether the item was found
        if aperID < 0 and len(self) == 1:
            return self.apertures[0]
	elif index  > -1:
	    # return the identified item
	    return self.apertures[index]
	else:
	    # return NULL
	    return None

    def _find_aperID(self, aperID):

	# set the default return value
	found = -1

	# go over all items
	for index in range(len(self.apertures)):
	    # check whether it is the right item
	    if self.apertures[index].aperID == aperID:
		# set the return value to the index
		found = index

	# return the result
	return found

    def _load_OAF(self, filename):
	
	# intitialize the aperture list
	apertures = []

	# intitialize the beam list
	beams = []

	# initialize the list
	keylist = []

	actAperID = 0

	actBeamID = 'Z'

	# open the file and parse through it
	fopen = file(filename, 'r')
	for line in fopen:

	    # get the content of the line
	    str_line = string.strip(line)
	    if len(str_line):
		
		# create a keyword if there
		# is content
		actKey = self._key_from_line(str_line)
		
		if actKey.keyword == 'BEAM' and actKey.keyvalue != 'END':
		    actBeamID = actKey.keyvalue
		if actKey.keyword == 'BEAM' and actKey.keyvalue == 'END':
		    beams.append(Beam(actAperID, actBeamID, keylist))
		if actKey.keyword == 'APERTURE' and actKey.keyvalue != 'END':
		    actAperID = int(actKey.keyvalue)
		if actKey.keyword == 'APERTURE' and actKey.keyvalue == 'END':
		    apertures.append(Aperture(actAperID, beams))

		    # intitialize the beam list
		    beams = []
		else:
		    keylist.append(actKey)

	return apertures

    def _key_from_line(self, line):
	"""
	Creates a keyword from a line

	The method extracts the konfiguration keyword,
	the associated value and, if present,
	a comment from a line in the configuration file.
	A configuration key object representing the extracted
	keyword is created and returned.

        @param line: line to analyze
        @type line: String

        @return: configuration key  object
        @rtype: ConfKey
	"""
	# split the line into items
	items = string.split(line)

	# for more than one item the 
	# first item is the keyword
	if len(items) > 1:
	    keyword  = items[0]

	    # check for a comment
	    cpos = line.rfind(';')
	    if cpos < 0:
		# evaluate the keyvalue
		keyvalue = string.strip(line[line.find(keyword)+len(keyword):])
		comment  = None
	    else:
		# evalute keyvalue and comment
		tmp_val  = string.strip(line[line.find(keyword)+len(keyword):])
		keyvalue = string.strip(string.split(tmp_val, ';')[0])
		comment  = string.strip(string.split(tmp_val, ';')[1])
		
	else:
	    # something's wrong here
	    raise 'Only one item in: ' + line + ' !'

	# create and return the keyword
	return configfile.ConfKey(keyword, keyvalue, comment)
