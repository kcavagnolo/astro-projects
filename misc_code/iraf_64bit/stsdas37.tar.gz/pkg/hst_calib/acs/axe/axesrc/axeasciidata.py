"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import string
import pyfits
import math
from axe import asciidata


class aXeAsciiData(asciidata.AsciiData):
    """
    Subclass of the AsciiData class for aXe
    """
    def __init__(self, filename, mag_wavelength=None):

        super(aXeAsciiData, self).__init__(filename=filename)

        # check whether rows do exist
        if self.nrows > 0:

            # check for the mandatory columns
            # in the table
            self._find_columns(mag_wavelength)


    def _find_columns(self, mag_wavelength=None):
        # search and store column number for "NUMBER"
	self.n_num = self.find("NUMBER")
	if self.n_num < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "NUMBER!"'
            raise err_msg

        # search and store column number for "X_IMAGE"
	self.n_xim = self.find("X_IMAGE")
	if self.n_xim < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "X_IMAGE!"'
            raise err_msg

        # search and store column number for "Y_IMAGE"
	self.n_yim = self.find("Y_IMAGE")
	if self.n_yim < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "Y_IMAGE!"'
            raise err_msg

        # search and store column number for "A_IMAGE"
	self.n_aim = self.find("A_IMAGE")
	if self.n_aim < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "A_IMAGE!"'
            raise err_msg

        # search and store column number for "B_IMAGE"
	self.n_bim = self.find("B_IMAGE")
	if self.n_bim < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "B_IMAGE!"'
            raise err_msg

        # search and store column number for "THETA_IMAGE"
	self.n_tim = self.find("THETA_IMAGE")
	if self.n_tim < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "THETA_IMAGE!"'
            raise err_msg

        # search and store column number for "X_WORLD"
	self.n_xwo = self.find("X_WORLD")
	if self.n_xwo < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "X_WORLD!"'
            raise err_msg

        # search and store column number for "X_WORLD"
	self.n_ywo = self.find("Y_WORLD")
	if self.n_ywo < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "Y_WORLD!"'
            raise err_msg

        # search and store column number for "X_WORLD"
	self.n_awo = self.find("A_WORLD")
	if self.n_awo < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "A_WORLD!"'
            raise err_msg

        # search and store column number for "X_WORLD"
	self.n_bwo = self.find("B_WORLD")
	if self.n_bwo < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "B_WORLD!"'
            raise err_msg

        # search and store column number for "X_WORLD"
	self.n_two = self.find("THETA_WORLD")
	if self.n_two < 0:
            err_msg = 'Catalogue: ' + filename + ' does not contain column: ' + ' "THETA_WORLD!"'
            raise err_msg

	# check for the MAG_AUTO-column 
	self.n_mau = self.find("MAG_AUTO")
	if self.n_mau < 0:
	    # if MAG_AUTO does not exist, search for 
	    # magnitude columns in general
	    mag_cols = self.search_mcols()

	    # if magnitude columns exist,
	    # search the one closest to the
	    # desired wavelength
	    if len(mag_cols) > 0:

		if mag_wavelength != None:
		    mag_index = self.find_magcol(mag_cols, mag_wavelength)
		else:
		    mag_index=0
		# set the column number and the wavelength
		self.n_mau   = mag_cols[mag_index][0]
		self.magwave = mag_cols[mag_index][1]
	    else:
		# enhance the error counter
                err_msg = 'Catalogue: ' + filename + ' does not contain any magnitude column!'
                raise err_msg
	else:
	    self.magwave = 0


    def find_magcol(self, mag_cols, mag_wave):
	"""
	Input:
	    mag_cols - the list with infos on magnitude columns
	    mag_wave - the target wavelength

	Return:
	    min_ind - the index of the closes column within mag-cols

	Description:
	    The method analyses all magnitude columns and finds the one
	    which is closest to a wavelength given in the input.
	    The index of the closest wavelength in the input
	    list is returned.
	"""
	import math
	
	# define a incredible large difference
	min_dist = 1.0e+30

	# define a non-result
	min_ind  = -1

	# go over al magnitude columns
	for index in range(len(mag_cols)):
	    # check wehether a new minimum distance is achieved
	    if math.fabs(mag_cols[index][1]-mag_wave) < min_dist:
		# transport the minimum and the index
		min_ind  = index
		min_dist = math.fabs(mag_cols[index][1]-mag_wave)

	# return the index
	return min_ind


    def search_mcols(self):
	"""
	Input:
	    -

	Return:
	    mag_cols - a list with tuples

	Description:
	    The method collects all magnitude columns
	    with an encoded wavelength in the column name.
	    For each such column the column index and the 
	    wavelength is stored in a list, and the list
	    of all columns is returned.
	"""

	# initialize the list with the result
	mag_cols = []
	
	# go over all columns
	for index in range(self.ncols):

	    # get the column name
	    colname = self[index].colname

	    # try to decode the wavelength
	    wave = self.get_wavelength(colname)

	    # if a wavelength is encoded
	    if wave:
		# compose and append the info
		# to the resulting list
		mag_cols.append([index, wave])

	# return the result
	return mag_cols


    def get_wavelength(self, colname):
	"""
	Input:
	    colname - the column name

	Return:
	    wave - the wavelength encoded in the
	            column name, or 0

	Description:
	    The method tries to extract the wavelength
	    encoded into a column name. The encoding
	    format is "MAG_<C><WAVE>*" with <C> a
	    single character, <WAVE> an integer number
	    and anything (*) afterwards.
	    in case that there is not wavelength encoded,
	    the value 0 id given back.
	"""
	# set the value for 'nothing found'
	wave = 0
	
	# check for the start string
	if colname.find('MAG_') == 0:

	    # copy the rest to a substring
	    rest_name = colname.split('MAG_')[1][1:]
	
	    # prepare to analyse the whole substring
	    for index in range(len(rest_name)):
		
		# make a progressively longer
		# substring, starting from the beginning
		cand_name = rest_name[0:index+1]

		# try to convert the substirng to
		# and integer, set a new wavelength
		# if it is possible
		try:
		    wave = int(cand_name)
		# as soon as the substirng can NOT
		# be transferred to an int
		# return the current, best wavelength
		except ValueError:
		    return wave

	# return the best result
	return wave


