"""
This module contains specific functions for the aXe task axecore.
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys, os, string,math, time
from pyraf import iraf
from pyraf.iraf import stsdas, dither
import pyfits
import numpy
from axedrzutils import *
import configfile

def make_affiles(list_filename, af_filename, comb_list, extr_in, extr_out):
    """
    Input:
        af_rootname - the rootname for the deep drizzled images
	              and the OAF/BAF file
	comb_list   - the list with deep drizzled images
	extr_in     - the input mfwhm value in the DPP's
	extr_out    - the output mfwhm value in the extraction ('pet2spc') 

    Return:
        None

    Description:

        Creates a OAF or BAF file for the deep drizzled image
	which are the result of 'axedrizzle'. This OAF is to be
	used as an input for the task 'drz2pet'.
	Also creates a list with the name of all the combined
	drizzle images (the multi extension files).
	The order of the beams matches exactly the order in the list
	of drizzled images.
	both files can be directly used as an iinput to
	the task 'drz2pet'.
    """

    if os.path.isfile(putDRIZZLE(af_filename)):
        os.unlink(putDRIZZLE(af_filename))
    if os.path.isfile(list_filename):
        os.unlink(list_filename)

    af_file = file(putDRIZZLE(af_filename), 'w')
    list_file = file(list_filename, 'w')
    
    for index in range(len(comb_list)):
        ID = append_aperture(str(comb_list[index]), af_file, extr_in, extr_out)
        list_file.write(str(comb_list[index]) + '\n')
    af_file.close()
    list_file.close()
    return 0

def append_aperture(imagefile, affile, extr_in, extr_out):
    """
    Input:
        imagefile - image file with keywords
        comb_list - pointer to the AF-file
	extr_in   - mfwhm of the input DPP's
	extr_out  - mfwhm to be extracted after drizzling

    Return:
        0

    Description:
        The function appends a beam/object to an already opened
	AF/BAF file. All the necessary information is taken
	from the descriptors of the drizzled image, and originally
	were written into the headder of the DPP stamp images 
	in the task 'drzprep'.
    """
    ID = imagefile[string.find(imagefile, 'ID')+2:string.find(imagefile, '.')]

    hlist = ['REFPNTX', 'REFPNTY', 'NAXIS1', 'NAXIS2', 'DRZWIDTH']
    header = get_header(putDRIZZLE(imagefile), 'sci', list=hlist)

    tr_header = header['DRZWIDTH']/extr_in*extr_out

    string1 = 'APERTURE ' + ID + '\n'
    string2 = '  BEAM A' + '\n'
    string3 = '     REFPIXEL' + ID + 'A' + ' ' + str(header['REFPNTX']-1.0) + ' ' + \
	      str(header['REFPNTY']-1.0) + '\n'
    string4 = '     CORNERS' + ID + 'A' + '  ' +\
	      '1.0'            + ' ' + '1.0'            + ' ' + \
	      str(header['NAXIS1'])            + ' ' + '1.0' + ' ' + \
	      str(header['NAXIS1']) + ' ' + str(header['NAXIS2']) + ' ' + \
	      '1.0 '           + ' ' + str(header['NAXIS2']) + '\n'
    string5 = '     CURVE' + ID + 'A' + '    ' + '1' + ' ' + '0.0' +\
	      ' ' + '0.0' + '\n'
    string6 = '     WIDTH' + ID + 'A' + '    ' + str(tr_header) + '\n'
    string7 = '     ORIENT' + ID + 'A' + '   ' + '90.0' + '\n'
    string8 = '     IGNORE' + ID + 'A' + '   ' + '0' + '\n'
    string9 = '  BEAM END' + '\n'
    string10= 'APERTURE END' + '\n'

    affile.write(string1)
    affile.write(string2)
    affile.write(string3)
    affile.write(string4)
    affile.write(string5)
    affile.write(string6)
    affile.write(string7)
    affile.write(string8)
    affile.write(string9)
    affile.write(string10)

    return ID

def make_coeffile(name, header):
    """
    Input:
        name   - name of the coefficient file
        header - image header with the coefficients

    Return:
        0

    Description:
        Creates the coefficient file for one stamp image.
	The coefficients coming from the header of the DPP file
	are arranged in the appropriate way and written to
	a file. For all the drizzle operation of a beam
	in a DPP the same file can be used.
    """
    row1 = str(header['DRZ00']) + ' ' + str(header['DRZ01']) + ' ' + \
	   str(header['DRZ02']) + ' ' + str(header['DRZ03']) + ' ' + \
	   str(header['DRZ04']) + ' ' + str(header['DRZ05']) + ' ' + \
	   str(header['DRZ06']) + ' ' + str(header['DRZ07']) + ' ' + \
	   str(header['DRZ08']) + ' ' + str(header['DRZ09']) + '\n'
    row2 = str(header['DRZ10']) + ' ' + str(header['DRZ11']) + ' ' + \
	   str(header['DRZ12']) + ' ' + str(header['DRZ13']) + ' ' + \
	   str(header['DRZ14']) + ' ' + str(header['DRZ15']) + ' ' + \
	   str(header['DRZ16']) + ' ' + str(header['DRZ17']) + ' ' + \
	   str(header['DRZ18']) + ' ' + str(header['DRZ19']) + '\n'
    if os.path.isfile(putDRIZZLE(name)):
        os.unlink(putDRIZZLE(name))
    coeffile = file(putDRIZZLE(name), 'w')
    coeffile.write('cubic\n')
    coeffile.write(row1)
    coeffile.write(row2)
    coeffile.close()

    return 0

def drizzleimage(extname, errname, whtname, conname, modname, varname, drzflt,
		 drzerr, drzerrw, drzwht, drzcon, drzconw, drzmod, drzmodw,
		 drzvar, drzvarw, exptime, config, opt_extr):
    """
    Input:
        extname - name of the temporary data input image
        errname - name of the temporary error input image
        whtname - name of the temporary weight input image
        conname - name of the temporary contamination input image
	drzflt  - name of the drizzled data  output image
	drzerr  - name of the drizzled error output image
	drzerrw - name of the drizzled error output image 2
	drzwht  - name of the drizzled weight output image
	drzcon  - name of the drizzled contamination output image
	drzconw - name of the drizzled contamination output image 2
	drzsky  - name of the drizzled sky output image
	exptime - exposure time of the DPP
	config  - dictionary holding the parameters of the configuration file
	opt_extr- flagg for optimum extraction

    Return:
        0/1     - 0 for all right, and 1 in case that drizzling was not
	          done. Drizzling is prohibited if at least one of the
		  drizzle coefficients shows NAN values.

    Description:
        The function takes the various temporary images extracted from
	the DPP and drizzles them onto the drizzled image for the
	beam which is under investigation. The drizzle task is called several
	times to create or update the deep data, error, weight and
	contamination image. 

	ATTENTION: function requires still some final makeover and
	           cleaning!!!!!
    """
    row1 = []
    row2 = []

    coefname = get_coefname(extname)

    hlist = ['DRZ00','DRZ01','DRZ02','DRZ03','DRZ04',\
	     'DRZ05','DRZ06','DRZ07','DRZ08','DRZ09',\
	     'DRZ10','DRZ11','DRZ12','DRZ13','DRZ14',\
	     'DRZ15','DRZ16','DRZ17','DRZ18','DRZ19',\
	     'NAXIS1', 'NAXIS2', 'LENGTH', 'OWIDTH', 'SKY_CPS']
    header = get_header(putDRIZZLE(extname), list=hlist)

    hlist = ['NAXIS1', 'NAXIS2']
    he_con = get_header(putDRIZZLE(conname), list=hlist)

    cr_header = ['DRZ00','DRZ01','DRZ02','DRZ03','DRZ04',\
		 'DRZ05','DRZ06','DRZ07','DRZ08','DRZ09',\
		 'DRZ10','DRZ11','DRZ12','DRZ13','DRZ14',\
		 'DRZ15','DRZ16','DRZ17','DRZ18','DRZ19',]
#
# small check for infinities or NAN's
#
    if (header['NAXIS1'] == 10 and header['NAXIS2'] == 10) or \
       (he_con['NAXIS1'] == 10 and he_con['NAXIS2'] == 10):

	statout = iraf.imstat(putDRIZZLE(extname),
			      fields='mean,stddev,npix', lower="INDEF",
			      upper="INDEF", nclip=0, lsigma=0.0, usigma=0.0,
			      binwidth=0.1, format="YES", Stdout=1)
	img_ave = float(string.split(statout[1])[0])
	img_std = float(string.split(statout[1])[1])
	img_npx = float(string.split(statout[1])[2])

	if img_ave == 0.0 and img_std == 0.0:
	    return 1
    
    for member in cr_header:
	if str(header[member]).upper() == 'INF' or str(header[member]).upper() == 'NAN':
	    return 2
#
    
    irafout=iraf.hedit(images=putDRIZZLE(extname), verify='NO',show='YES',
		       update='YES', field='exptime', value=exptime,
		       addonly='YES', add='YES', delete='NO',Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(errname), verify='NO',show='YES',
		       update='YES', field='exptime', value=exptime,
		       addonly='YES', add='YES', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(conname), verify='NO',show='YES',
		       update='YES', field='exptime', value=exptime,
		       addonly='YES', add='YES', delete='NO', Stdout=1)

    if opt_extr == iraf.yes:
	irafout=iraf.hedit(images=putDRIZZLE(modname), verify='NO',show='YES',
			   update='YES', field='exptime', value=exptime,
			   addonly='YES', add='YES', delete='NO', Stdout=1)

	irafout=iraf.hedit(images=putDRIZZLE(varname), verify='NO',show='YES',
			   update='YES', field='exptime', value=exptime,
			   addonly='YES', add='YES', delete='NO', Stdout=1)
    

    length  = int(header['LENGTH'])
    width   = 2*int(math.ceil(header['OWIDTH'])) + 10
    sky_cps = float(header['SKY_CPS'])
        
    make_coeffile(coefname, header)

    try:
        irafout=iraf.drizzle(data=putDRIZZLE(extname), outdata=putDRIZZLE(drzflt), outweig=putDRIZZLE(drzwht),
			     in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			     outnx=length, outny=width, in_un='cps', out_un='cps',
			     pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			     kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)
    except:
	report_warning(210, image=putDRIZZLE(extname))
	return 3

#    print """
#
#
#    """
#    print putDRIZZLE(extname)
#    print putDRIZZLE(drzflt)
#    print putDRIZZLE(drzwht)
#    print putDRIZZLE(whtname)
#    print exptime
#    print putDRIZZLE(coefname)
#    print length
#    print width
#    print """
#
#
#    """
#    sys.exit(0)

    try:
	irafout=iraf.drizzle(data=putDRIZZLE(errname), outdata=putDRIZZLE(drzerr), outweig=putDRIZZLE(drzerrw),
			     in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			     outnx=length, outny=width, in_un='counts', out_un='counts',
			     pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			     kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)
    except:
	report_warning(210, image=putDRIZZLE(errname))
	return 3

    if not os.path.isfile(putDRIZZLE(drzflt)):
	return 1

    # the next drizzle is a bit inconsistent since
    # the exposure time is used for the weighting instead
    # of the variance. However this has the advantage 
    # of getting an exposure time map used in non optimal extraction
    # later on. Using inverse variance weighting would require
    # a blank drizzle just to get the exposure time.
    try:
	irafout=iraf.drizzle(data=putDRIZZLE(conname), outdata=putDRIZZLE(drzcon), outweig=putDRIZZLE(drzconw),
			     in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			     outnx=length, outny=width, in_un='cps', out_un='cps',
			     pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			     kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)
    except:
	report_warning(210, image=putDRIZZLE(conname))
	return 3


    if opt_extr == iraf.yes:
	try:
	    irafout=iraf.drizzle(data=putDRIZZLE(modname), outdata=putDRIZZLE(drzmod), outweig=putDRIZZLE(drzmodw),
				 in_mask=putDRIZZLE(varname), wt_scl=1.0, coeffs=putDRIZZLE(coefname),
				 outnx=length, outny=width, in_un='cps', out_un='cps',
				 pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
				 kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)
	except:
	    report_warning(210, image=putDRIZZLE(modname))
	    return 3
	
	#
	# between the comments there is the old, aXe-1.4 drizzling scheme
	# which explicitly drizzles the errors.
	"""
    irafout=iraf.drizzle(data=putDRIZZLE(extname), outdata=putDRIZZLE(drzflt), outweig=putDRIZZLE(drzwht),
			 in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			 outnx=length, outny=width, in_un='cps', out_un='cps',
			 pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			 kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)

    if not os.path.isfile(putDRIZZLE(drzflt)):
	return 1

    irafout=iraf.drizzle(data=putDRIZZLE(conname), outdata=putDRIZZLE(drzcon), outweig=putDRIZZLE(drzconw),
			 in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			 outnx=length, outny=width, in_un='cps', out_un='cps',
			 pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			 kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)

    irafout=iraf.drizzle(data=putDRIZZLE(errname), outdata=putDRIZZLE(drzerr), outweig=putDRIZZLE(drzerrw),
			 in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			 outnx=length, outny=width, in_un='counts', out_un='counts',
			 pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			 kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)

    if opt_extr == iraf.yes:
	irafout=iraf.drizzle(data=putDRIZZLE(modname), outdata=putDRIZZLE(drzmod), outweig=putDRIZZLE(drzmodw),
			     in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			     outnx=length, outny=width, in_un='cps', out_un='cps',
			     pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			     kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)

	irafout=iraf.drizzle(data=putDRIZZLE(varname), outdata=putDRIZZLE(drzvar), outweig=putDRIZZLE(drzvarw),
			     in_mask=putDRIZZLE(whtname), wt_scl=exptime, coeffs=putDRIZZLE(coefname),
			     outnx=length, outny=width, in_un='counts', out_un='counts',
			     pixfrac=config.get_gvalue('DRZPFRAC'),scale=config.get_gvalue('DRZPSCALE'),
			     kernel=config.get_gvalue('DRZKERNEL'), Stdout=1)
	"""


    if header.has_key('XOFFS'):
	refx = header['XOFFS']
	refy = width/2+1.0
	## is that really necessary????????
	success = update_headers(drzflt,drzerr,drzwht,drzcon,drzmod,drzmodw,refx,refy, opt_extr)

    return 0

def update_headers(drzflt,drzerr,drzwht,drzcon,drzmod,drzvar,refx,refy, opt_extr):
    """
    Input:
	drzflt  - name of the drizzled data  output image
	drzerr  - name of the drizzled error output image
	drzwht  - name of the drizzled weight output image
	drzcon  - name of the drizzled contamination output image
	refx    - x-value of the reference pixel the reference wavelength
	          is drizzled to
        refy    - y-value of the reference pixel the reference wavelength
	          is drizzled to
        opt_extr- flagg for optimum extraction

    Return:
        0

    Description:
        Stores the new reference point to which the reference wavelength
	is drizzled to into the header of some drizzle products.
    """
    irafout=iraf.hedit(images=putDRIZZLE(drzflt), verify='NO',show='YES',
		       update='YES', field='REFPNTX', value=refx,
		       addonly='NO', add='YES', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(drzflt), verify='NO',show='YES',
		       update='YES', field='REFPNTY', value=refy,
		       addonly='NO', add='YES', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putDRIZZLE(drzerr), verify='NO',show='YES',
		       update='YES', field='REFPNTX', value=refx,
		       addonly='NO', add='YES', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(drzerr), verify='NO',show='YES',
		       update='YES', field='REFPNTY', value=refy,
		       addonly='NO', add='YES', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putDRIZZLE(drzwht), verify='NO',show='YES',
		       update='YES', field='REFPNTX', value=refx,
		       addonly='NO', add='YES', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(drzwht), verify='NO',show='YES',
		       update='YES', field='REFPNTY', value=refy,
		       addonly='NO', add='YES', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putDRIZZLE(drzcon), verify='NO',show='YES',
		       update='YES', field='REFPNTX', value=refx,
		       addonly='NO', add='YES', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=putDRIZZLE(drzcon), verify='NO',show='YES',
		       update='YES', field='REFPNTY', value=refy,
		       addonly='NO', add='YES', delete='NO', Stdout=1)

    if opt_extr == iraf.yes:
	irafout=iraf.hedit(images=putDRIZZLE(drzmod), verify='NO',show='YES',
			   update='YES', field='REFPNTX', value=refx,
			   addonly='NO', add='YES', delete='NO', Stdout=1)
	irafout=iraf.hedit(images=putDRIZZLE(drzmod), verify='NO',show='YES',
			   update='YES', field='REFPNTY', value=refy,
			   addonly='NO', add='YES', delete='NO', Stdout=1)

	irafout=iraf.hedit(images=putDRIZZLE(drzvar), verify='NO',show='YES',
			   update='YES', field='REFPNTX', value=refx,
			   addonly='NO', add='YES', delete='NO', Stdout=1)
	irafout=iraf.hedit(images=putDRIZZLE(drzvar), verify='NO',show='YES',
			   update='YES', field='REFPNTY', value=refy,
			   addonly='NO', add='YES', delete='NO', Stdout=1)
    return 0


def drizzle_prepare(extname, errname, conname, modname, varname, whtname, opt_extr):
    """
    Input:
        filename - the DPP filename
	extname  - name for the extracted data stamp image
	errname  - name for the extracted error stamp image
	conname  - name for the extracted contamination stamp image
	whtname  - name for the weight stamp image
	opt_extr - flagg for optimum extraction

    Return:
        0

    Description:
        The function extracts from the DPP image the data, error and
	contamination stamp image for one beam and stores them
	into temporary images which serve as an input for the
	drizzling. Also a weight image is derived (with 0 and 1
	indicating coverage on a pixel). 
    """
    if not os.path.isfile(putDRIZZLE(extname)):
	print 'aXe_DRIZZLE: Did not find: ', putDRIZZLE(extname)
    if not os.path.isfile(putDRIZZLE(errname)):
	print 'aXe_DRIZZLE: Did not find: ', putDRIZZLE(errname)
    if not os.path.isfile(putDRIZZLE(conname)):
	print 'aXeDRIZZLE: Did not find: ', putDRIZZLE(conname)
    if os.path.isfile(putDRIZZLE(whtname)):
       	os.unlink(putDRIZZLE(whtname))
    
    if opt_extr == iraf.yes:
	if not os.path.isfile(putDRIZZLE(varname)):
	    print 'aXeDRIZZLE: Did not find: ', putDRIZZLE(varname)	
	
	if not os.path.isfile(putDRIZZLE(modname)):
	    print 'aXeDRIZZLE: Did not find: ', putDRIZZLE(modname)

    irafout=iraf.imcopy(input=putDRIZZLE(extname),
			output=putDRIZZLE(whtname), verbose='yes', Stdout=1)
    irafout=iraf.imreplace(images=putDRIZZLE(whtname), value=1.0,
			   lower=-900000,upper='INDEF',
			   imaginary=0.0, radius=0.0, Stdout=1)
    irafout=iraf.imreplace(images=putDRIZZLE(whtname),
			   value=0.0, lower='INDEF', upper=-900000,
			   imaginary=0.0, radius=0.0, Stdout=1)
    irafout=iraf.imreplace(images=putDRIZZLE(extname), value=0.0,
			   lower='INDEF',upper=-900000,
			   imaginary=0.0, radius=0.0, Stdout=1)

    return 0


def filet_dpp(dppname, opt_extr):
    execfile = 'axebin$aXe_FILET'
    fname = iraf.osfn(execfile)
    cmd_str = fname+' '+dppname
    if opt_extr == iraf.yes:
	cmd_str = cmd_str + ' -opt_extr'
    status = iraf.clOscmd(cmd_str)
    return status

def get_cont_model(dppname, dppname_alt=None):

    extname = dppname
    hlist = ['CONTAM ']
    header = get_header(putOUTPUT(extname), list=hlist, error=0)

    if header != None:
	return header['CONTAM ']
    else:
        if dppname_alt:
            extname = dppname_alt
            header = get_header(putOUTPUT(extname), list=hlist, error=0)

            if header != None:
                return header['CONTAM ']
            else:
                return header
	return header

def analyzefits(fitsname):
    """
    Input
        fitsname  - image name to be analyzed

    Return
        file_info - dictionary with the the list which
	            contain beam information

    Description:
        Executes the iraf task 'catfits' on the input image and
	analyzes the result. The input image is a DPP multi extension
	fits file. From the information given in the output
	of 'catfits' the function extracts the beam numbers which
	are in the various extensions of the image.
	The stamp images for data, error and contamination are stored
	in dictionary lists and returned.
    """
    beams = []
    errs  = []
    conts = []
    mods  = []
    vars  = []
    file_info = {}
    file_info['FILENAME'] = fitsname
    allinfo = iraf.catfits( fits_file=putOUTPUT(fitsname), file_list='',
			    long_header='no', format_file='', log_file='',
			    short_header='YES', ext_print='YES', offset=0,
			    Stdout=1)
    for info in allinfo:
	line = string.split(info)
	if len(line) > 0 and string.find(line[2],'BEAM') > -1:
	    if line[1] == 'IMAGE' and \
	       string.rfind(line[2], 'A') == len(line[2])-1:
		beams.append(string.strip(line[2]))
	if len(line) > 0 and string.find(line[2],'ERR') > -1:
	    if line[1] == 'IMAGE' and \
	       string.rfind(line[2], 'A') == len(line[2])-1:
		errs.append(string.strip(line[2]))
	if len(line) > 0 and string.find(line[2],'CONT') > -1:
	    if line[1] == 'IMAGE' and \
	       string.rfind(line[2], 'A') == len(line[2])-1:
		conts.append(string.strip(line[2]))
	if len(line) > 0 and string.find(line[2],'MOD') > -1:
	    if line[1] == 'IMAGE' and \
	       string.rfind(line[2], 'A') == len(line[2])-1:
		mods.append(string.strip(line[2]))
	if len(line) > 0 and string.find(line[2],'VAR') > -1:
	    if line[1] == 'IMAGE' and \
	       string.rfind(line[2], 'A') == len(line[2])-1:
		vars.append(string.strip(line[2]))
    file_info['BEAMS'] = beams
    file_info['ERRS']  = errs
    file_info['CONTS'] = conts
    file_info['MODS']  = mods
    file_info['VARS']  = vars
    return file_info


def slicedata(file_info, allobjects, config, opt_extr):
    """
    Input
        file_info  - dictionary with the stamp image
	             information on a DPP file
        allobjects - dictionary with information on all
	             all beams in all DPP images drizzled
		     up to the time of the function call
	config     - the object for the configuration file
	opt_extr   - flagg to indicate optimum extraction

    Return
        allobjects - dictionary with information on all
	             all beams in all DPP images drizzled.
		     Updated during function execution

    Description:
        The function controles and executes the drizzling of the
	stamp images viacalling various other functions.
	The DPP's are sliced to extract the stamp images
	of individual beams. Those stamp images are then drizzled
	onto one common drizzle image per object.
	Information on the contribution of the various DPP's 
	to the different drizzle images is kept in the dictonary
	'allobjects'.
    """

    filename = file_info['FILENAME']
    beamers  = file_info['BEAMS']
    errors   = file_info['ERRS']
    contams  = file_info['CONTS']
    models   = file_info['MODS']
    vars     = file_info['VARS']


    hlist = ['EXPTIME']
    header = get_header(putOUTPUT(filename), list=hlist, error=1)
    exptime = header['EXPTIME']

    for index in range(len(beamers)):

        objid = get_objid(beamers[index])
        drzflt  = get_drizzallimg(filename, config.get_gvalue('DRZROOT'), objid)
        drzerr  = get_drizzallerr(filename, config.get_gvalue('DRZROOT'), objid)
        drzcon  = get_drizzallcon(filename, config.get_gvalue('DRZROOT'), objid)
        drzmod  = get_drizzallmod(filename, config.get_gvalue('DRZROOT'), objid)
        drzvar  = get_drizzallvar(filename, config.get_gvalue('DRZROOT'), objid)
        drzwht  = get_drizzallwht(filename, config.get_gvalue('DRZROOT'), objid)
        drzconw = get_drizzconwht(filename, config.get_gvalue('DRZROOT'), objid)
        drzerrw = get_drizzerrwht(filename, config.get_gvalue('DRZROOT'), objid)
        drzmodw = get_drizzmodwht(filename, config.get_gvalue('DRZROOT'), objid)
        drzvarw = get_drizzvarwht(filename, config.get_gvalue('DRZROOT'), objid)
        if not allobjects.has_key(objid):
            if os.path.isfile(putDRIZZLE(drzflt)):
                os.unlink(putDRIZZLE(drzflt))
            if os.path.isfile(putDRIZZLE(drzerr)):
                os.unlink(putDRIZZLE(drzerr))
            if os.path.isfile(putDRIZZLE(drzerrw)):
                os.unlink(putDRIZZLE(drzerrw))
            if os.path.isfile(putDRIZZLE(drzcon)):
                os.unlink(putDRIZZLE(drzcon))
            if os.path.isfile(putDRIZZLE(drzconw)):
                os.unlink(putDRIZZLE(drzconw))
            if os.path.isfile(putDRIZZLE(drzmod)):
                os.unlink(putDRIZZLE(drzmod))
            if os.path.isfile(putDRIZZLE(drzmodw)):
                os.unlink(putDRIZZLE(drzmodw))
            if os.path.isfile(putDRIZZLE(drzvar)):
                os.unlink(putDRIZZLE(drzvar))
            if os.path.isfile(putDRIZZLE(drzvarw)):
                os.unlink(putDRIZZLE(drzvarw))
            if os.path.isfile(putDRIZZLE(drzwht)):
                os.unlink(putDRIZZLE(drzwht))
        
        
	extname = get_objname(filename, beamers[index])
	errname = get_errname(filename, beamers[index])
        conname = get_contname(filename, beamers[index])
        modname = get_modname(filename, beamers[index])
        varname = get_varname(filename, beamers[index])
	whtname = get_inweight(filename, beamers[index])


	success = drizzle_prepare(extname, errname, conname, modname, varname, whtname, opt_extr)

	ID = string.split(beamers[index],'_')[1]
	pstring = 'aXe_DRIZZLE: %25s BEAM_%-5s drizzled' % (filename,ID)
        print pstring,
        success = drizzleimage(extname, errname, whtname, conname, modname,
			       varname, drzflt, drzerr, drzerrw, drzwht, 
			       drzcon, drzconw, drzmod, drzmodw, drzvar,
			       drzvarw, exptime, config, opt_extr)
	print ' Done'

	if success == 0:

	    hlist = ['WAVPNTX', 'WAVPNTY', 'REFPNTX',
		     'REFPNTY', 'OREFPNTX', 'OREFPNTY']
	    header = get_header(putDRIZZLE(extname), list=hlist)

            relx = header['WAVPNTX']
            rely = header['WAVPNTY']
            diffx = header['REFPNTX'] - header['OREFPNTX']
            if relx < 0.0:
                print 'Attention: ', extname, relx, rely
            diffy = header['REFPNTY'] - header['OREFPNTY']
            if rely < 0.0:
                print 'Attention: ', extname, relx, rely

            if allobjects.has_key(objid):
                allobjects[objid][0].append(extname)
	    
            else:
                allimas = []
                inimas = []
                ouimas = []

                inimas.append(extname)
                allimas.append(inimas)
                allimas.append(ouimas)
                allobjects[objid] = allimas

                if allobjects.has_key('IDENTS'):
                    allobjects['IDENTS'].append(objid)
                else:
                    allids = []
                    allids.append(objid)
                    allobjects['IDENTS'] = allids

                if allobjects.has_key('DRZFLT'):
                    allobjects['DRZFLT'].append(drzflt)
                else:
                    fltall = []
                    fltall.append(drzflt)
                    allobjects['DRZFLT'] = fltall

                if allobjects.has_key('DRZERR'):
                    allobjects['DRZERR'].append(drzerr)  # for exposure time weighting
#                    allobjects['DRZERR'].append(drzwht) # for inverse variance weighting
                else:
                    errall = []
                    errall.append(drzerr)                # for exposure time weighting
#                    errall.append(drzwht)               # for inverse variance weighting
                    allobjects['DRZERR'] = errall

                if allobjects.has_key('DRZWHT'):
                    allobjects['DRZWHT'].append(drzwht)   # for exposure time weighting
#                    allobjects['DRZWHT'].append(drzconw) # for inverse variance weighting
                else:
                    whtall = []
                    whtall.append(drzwht)                 # for exposure time weighting
#                    whtall.append(drzconw)               # for inverse variance weighting
                    allobjects['DRZWHT'] = whtall

                if allobjects.has_key('DRZMOD'):
                    allobjects['DRZMOD'].append(drzmod)
                else:
		    modall = []
                    modall.append(drzmod)
                    allobjects['DRZMOD'] = modall

		if allobjects.has_key('DRZVAR'):
                    allobjects['DRZVAR'].append(drzmodw)
#                    allobjects['DRZVAR'].append(drzvar)
                else:
                    varall = []
#                    varall.append(drzvar)
                    varall.append(drzmodw)
                    allobjects['DRZVAR'] = varall

                if allobjects.has_key('DRZCON'):
                    allobjects['DRZCON'].append(drzcon)
                else:
                    conall = []
                    conall.append(drzcon)
                    allobjects['DRZCON'] = conall

                if allobjects.has_key('GARBAGE'):
		    allobjects['GARBAGE'].append(drzerrw)
		    allobjects['GARBAGE'].append(drzconw)
		    allobjects['GARBAGE'].append(drzmodw)
		    allobjects['GARBAGE'].append(drzvarw)
		else:
		    garbadge = []
		    garbadge.append(drzerrw)
		    garbadge.append(drzconw)
		    garbadge.append(drzmodw)
		    garbadge.append(drzvarw)
		    allobjects['GARBAGE'] = garbadge


        elif success == 1:
            print 'Warning: No content in PET/DPP extension: ', extname
        elif success == 2:
            print 'Warning: Infinity-problems for: ', extname
	else:
	    print 'Drizzle did not finish for: ', extname
        if os.path.isfile(putDRIZZLE(extname)):
            os.unlink(putDRIZZLE(extname))	
        if os.path.isfile(putDRIZZLE(errname)):
            os.unlink(putDRIZZLE(errname))
        if os.path.isfile(putDRIZZLE(conname)):
            os.unlink(putDRIZZLE(conname))	
        if os.path.isfile(putDRIZZLE(modname)):
            os.unlink(putDRIZZLE(modname))	
        if os.path.isfile(putDRIZZLE(varname)):
            os.unlink(putDRIZZLE(varname))	
        if os.path.isfile(putDRIZZLE(whtname)):
            os.unlink(putDRIZZLE(whtname))	
        if os.path.isfile(putDRIZZLE(get_coefname(extname))):
            os.unlink(putDRIZZLE(get_coefname(extname)))	
    return allobjects

#------------------------------------------------------------------------
#
def correct_contam(image):
    """
    Input:
        image - name of the contamination image

    Return:
        None

    Description:
        The drizzling fills the contamination image with real
	values at the border of the object beams. This function
        transform the contamination image back into an image
	with integer values.
    """
    imexpr = '"nint(a)"'

    # define a tmp name
    tmp_name = get_random_filename('','.fits')

    irafout=iraf.imexpr(expr=imexpr, output=putDRIZZLE(tmp_name),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putDRIZZLE(image), rangecheck='YES',
			verbose='YES',Stdout=1)
    if os.path.isfile(putDRIZZLE(image)):
        os.unlink(putDRIZZLE(image))

    irafout=iraf.imrename(oldnames=putDRIZZLE(tmp_name),
			  newnames=putDRIZZLE(image), verbose='YES', Stdout=1)

#------------------------------------------------------------------------
#
def comp_error(whtimage, errimage, varimage, opt_extr):
    """
    Input:
        fltimage  -
	whtimage  -
	skyimage  -
	terrimage -
	nimages   -

    Return:
        errimage - the name of the errorimage

    Description:

    """

    #
    # The next lines check whether the weight image
    # has negative values. If yes, it is multiplied
    # by "-1.0". This is a fix to the drizzle-decennium
    # and will, artr some point, become obsolete
    #

    # make the image statistic
    statout = iraf.imstat(putDRIZZLE(whtimage),
                          fields='mean,stddev,npix', lower="INDEF",
                          upper="INDEF", nclip=0, lsigma=0.0, usigma=0.0,
                          binwidth=0.1, format="YES", Stdout=1)

    # extract the stat values
    img_ave = float(string.split(statout[1])[0])
    img_std = float(string.split(statout[1])[1])
    img_npx = float(string.split(statout[1])[2])

    # decide whether something must be done
    if img_ave < 0.0:

        # define a tmp name
        tmpname = get_random_filename('','.fits')

        # multiply the image times "-1.0"
        iraf.imcalc(input=putDRIZZLE(whtimage), output=putDRIZZLE(tmpname), equals="-1.0*im1",
                    pixtype="old", nullval=0.0, verbose="YES", Stdout=1)

        # delete the old file
        if os.path.isfile(putDRIZZLE(whtimage)):
            os.unlink(putDRIZZLE(whtimage))

        # rename the inverted image to the old name
        irafout=iraf.imrename(oldnames=putDRIZZLE(tmpname),
                              newnames=putDRIZZLE(whtimage),
                              verbose='YES', Stdout=1)
    
    # define a tmp name
    tmpname = get_random_filename('','.fits')


    imexpr = '"b < 1.0e-16 ? 0.0 : sqrt(a)/b"'   # for exosure time weighting
    irafout=iraf.imexpr(expr=imexpr, output=putDRIZZLE(tmpname),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putDRIZZLE(errimage), b=putDRIZZLE(whtimage),
			rangecheck='YES', verbose='YES',Stdout=1)
#    imexpr = '"a < 1.0e-16 ? 0.0 : 1.0/sqrt(a)"' # for inverse variance weighting
#    irafout=iraf.imexpr(expr=imexpr, output=putDRIZZLE(tmpname),
#			dims='auto', intype='auto', outtype='auto',
#			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
#			exprdb='none', a=putDRIZZLE(errimage),
#			rangecheck='YES', verbose='YES',Stdout=1)
    if os.path.isfile(putDRIZZLE(errimage)):
	os.unlink(putDRIZZLE(errimage))
    irafout=iraf.imrename(oldnames=putDRIZZLE(tmpname),
			  newnames=putDRIZZLE(errimage),
			  verbose='YES', Stdout=1)


    if opt_extr:

	# define a tmp name
	tmpname = get_random_filename('','.fits')

	imexpr = '"a < 1.0e-16 ? 0.0 : 1.0/a"'
	irafout=iraf.imexpr(expr=imexpr, output=putDRIZZLE(tmpname),
			    dims='auto', intype='auto', outtype='auto',
			    refim='auto', bwidth=0, btype='nearest',
			    bpixval=0.0, exprdb='none', a=putDRIZZLE(varimage),
			    rangecheck='YES', verbose='YES',Stdout=1)
	if os.path.isfile(putDRIZZLE(varimage)):
	    os.unlink(putDRIZZLE(varimage))
	irafout=iraf.imrename(oldnames=putDRIZZLE(tmpname),
			      newnames=putDRIZZLE(varimage),
			      verbose='YES', Stdout=1)

    return errimage

def norm_wht_cont(allobjects, cont_model, opt_extr, bckmode):
    """
    Input:
        allobjects - the dictionary with the information on all the drizzling
	             of the DPP's to deep drizzle images
        cont_model - the contamination model
	opt_extr   - flagg to indicate optimal extraction

    Return:
        extlist - a list with the name of all images with the
	          deep drizzled images

    Description:
        Composes the individual images for data, error, weight and
	contamination to a single multiextension image per beam and
	reworks e.g. the contamination image. Calls other functions
	to do the dirty job.
	
    """
    fltlist = allobjects['DRZFLT']
    errlist = allobjects['DRZERR']
    whtlist = allobjects['DRZWHT']
    conlist = allobjects['DRZCON']
    modlist = allobjects['DRZMOD']
    varlist = allobjects['DRZVAR']

    extlist = []

    if not is_quant_contmodel(cont_model):
	print ""
	print "Do contamination correction!", is_quant_contmodel(cont_model),cont_model 
	print ""
	for item in conlist:
	    if string.find(item, '.BCK.') < 0:
		objid = item[int(str.find(item,'_con_')+5):int(str.find(item,'.fits'))]
	    else:
		objid = item[int(str.find(item,'_con_')+5):int(str.find(item,'.BCK.fits'))]
	    if allobjects.has_key(objid):
		correct_contam(item)
    else:
	print ""
	print "No correction of the contamination image!", is_quant_contmodel(cont_model),cont_model
	print ""

    for index in range(len(fltlist)):
        if string.find(fltlist[0], '.BCK.') < 0:
            objid = fltlist[index][int(str.find(fltlist[index],'_flt_')+5):int(str.find(fltlist[index],'.fits'))]
        else:
            objid = fltlist[index][int(str.find(fltlist[index],'_flt_')+5):int(str.find(fltlist[index],'.BCK.fits'))]
        nimages = len(allobjects[objid][1])

        err_image = comp_error(whtlist[index],errlist[index], varlist[index], opt_extr)
     
	mexname = get_mename(fltlist[index])
        if os.path.isfile(putDRIZZLE(mexname)):
                os.unlink(putDRIZZLE(mexname))

	make_mex_image(mexname, fltlist[index], errlist[index], conlist[index],
		       whtlist[index],modlist[index],varlist[index], nimages, opt_extr)
	for index in range(len(allobjects[objid][1])):
	    dpp_name = 'FRAME' + str(index)
	    irafout=iraf.hedit(images=str(putDRIZZLE(mexname+'[0]')), verify='NO',
			       show='YES', update='YES', field=dpp_name,
			       value=allobjects[objid][1][index],
			       addonly='YES', add='YES', delete='NO', Stdout=1)

	    pname = string.strip(allobjects[objid][1][index])
	    pname = pname[ : string.find(allobjects[objid][1][index],'_flt_')] + '_raw.fits\n'
	
	irafout=iraf.hedit(images=str(putDRIZZLE(mexname+'[0]')), verify='NO',
			   show='YES', update='YES', field="CONTAM",
			   value=cont_model, addonly='YES', add='YES',
			   delete='NO', Stdout=1)
	extlist.append(mexname)

	if opt_extr and bckmode:
	    copy_optext_images(mexname)


    return extlist

def copy_optext_images(mexname):
    obj_drz = mexname.replace('.BCK.', '.')
    print mexname, ' --> ', obj_drz

    mex_ext = mexname + '[VAR]'
    obj_ext = obj_drz + '[VAR,overwrite]'
    iraf.imcopy(input=putDRIZZLE(mex_ext),
		output=putDRIZZLE(obj_ext),
		verbose='YES', Stdout=1)
    mex_ext = mexname + '[MOD]'
    obj_ext = obj_drz + '[MOD,overwrite]'
    iraf.imcopy(input=putDRIZZLE(mex_ext),
		output=putDRIZZLE(obj_ext),
		verbose='YES', Stdout=1)

#------------------------------------------------------------------------
#
def make_mex_image(mex_image, flt_image, err_image, con_image, wht_image,
		   mod_image, var_image, nimages, opt_extr):
    """
    Input:
        mex_image - name of the multi extension fits file
	flt_image - name of the drizzled data image
	err_image - name of the drizzled error image
	con_image - name of the drizzled contamination image
	wht_image - name of the drizzled weight image
	nimages   - number of stamp images drizzled to the data image
	opt_extr  - flagg to indicate optimum extraction

    Return:
        None

    Description:
        Makes a single multi extension withsfile out of the deep data,
	error, contam and weight image for each object. Stores the number
	of input stamp images drizzled into the data image in the
	keyword 'NUM_DRIZ'.
    """
    
    make_WCS_header(putDRIZZLE(flt_image))
    make_WCS_header(putDRIZZLE(err_image))
    make_WCS_header(putDRIZZLE(wht_image))
    make_WCS_header(putDRIZZLE(con_image))

    if opt_extr == iraf.yes:
	make_WCS_header(putDRIZZLE(mod_image))
	make_WCS_header(putDRIZZLE(var_image))

    if os.path.isfile(putDRIZZLE(mex_image)):
        os.unlink(putDRIZZLE(mex_image))
    mex_hdu = pyfits.HDUList()
    hdrpr = pyfits.PrimaryHDU()
    mex_hdu.append(hdrpr)
    hdr = mex_hdu[0].header
    hdr.update('NUM_DRIZ',nimages, comment='NUMBER OF IMAGES DRIZZLED')
    mex_hdu.writeto(putDRIZZLE(mex_image))
    mex_hdu.close()

    iraf.flprc()
    iraf.imcopy(input=putDRIZZLE(flt_image),
		output=putDRIZZLE(str(mex_image+'[SCI,1,append]')),
		verbose='YES', Stdout=1)
    iraf.flprc()
    iraf.imcopy(input=putDRIZZLE(err_image),
		output=putDRIZZLE(str(mex_image+'[ERR,1,append]')),
		verbose='YES', Stdout=1)
    iraf.flprc()
    iraf.imcopy(input=putDRIZZLE(wht_image),
		output=putDRIZZLE(str(mex_image+'[EXPT,1,append]')),
		verbose='YES', Stdout=1)
    iraf.flprc()
    iraf.imcopy(input=putDRIZZLE(con_image),
		output=putDRIZZLE(str(mex_image+'[CON,1,append]')),
		verbose='YES', Stdout=1)

    if opt_extr == iraf.yes:
        iraf.flprc()
	iraf.imcopy(input=putDRIZZLE(mod_image),
		    output=putDRIZZLE(str(mex_image+'[MOD,1,append]')),
		    verbose='YES', Stdout=1)
        iraf.flprc()
	iraf.imcopy(input=putDRIZZLE(var_image),
		    output=putDRIZZLE(str(mex_image+'[VAR,1,append]')),
		    verbose='YES', Stdout=1)
    pstring = 'aXe_DRIZZLE: composed MEX image %28s Done' % (mex_image)
    print pstring

    #
    # Check whether the wht-extension coincides with the
    # weight file.
    #
#    tmp_name = get_random_filename('','.fits')
#    iraf.imarith(operand1=putDRIZZLE(mex_image+"[EXPT,1]"), op="-",
#                 operand2=putDRIZZLE(wht_image), result=putDRIZZLE(tmp_name))
#    statout = iraf.imstat(putDRIZZLE(tmp_name),
#                          fields='mean,stddev,npix', lower="INDEF",
#                          upper="INDEF", nclip=0, lsigma=0.0, usigma=0.0,
#                          binwidth=0.1, format="YES", Stdout=1)
#    img_ave = float(string.split(statout[1])[0])
#    img_std = float(string.split(statout[1])[1])
#    img_npx = float(string.split(statout[1])[2])
#    if math.fabs(img_ave) > 1.0e-05 and math.fabs(img_std) > 1.0e-05:
#        print putDRIZZLE(mex_image+"[EXPT,1]"),  " differs from , ",  putDRIZZLE(wht_image), "!!"
#    else:
#        print putDRIZZLE(mex_image+"[EXPT,1]"), " - ",  putDRIZZLE(wht_image), " = ", img_ave, " +- ", img_std
#    os.unlink(putDRIZZLE(tmp_name))
    os.unlink(putDRIZZLE(flt_image))
    os.unlink(putDRIZZLE(err_image))
    os.unlink(putDRIZZLE(con_image))
    os.unlink(putDRIZZLE(wht_image))
    if os.path.isfile(putDRIZZLE(mod_image)):
	os.unlink(putDRIZZLE(mod_image))
    if os.path.isfile(putDRIZZLE(var_image)):
	os.unlink(putDRIZZLE(var_image))
    
def make_WCS_header(fitsimage):
    """
    Input:
        fitsimage - the image to update the header for

    Return:
        0/1 - in case of failure/success

    Description:
        The method creates and stores the WCS header for a
	axedrizzled grism image. The necessary information
	on CRPIX, CRVALS and so on a re extracted from already
	existing keywords. The standard keys are then
	stored at the beginning of the header.
    """

    # those keywords must just exist
    WCS_keys = ['REFPNTX', 'REFPNTY','CDSCALE','LAMBDA0','DLAMBDA']

    # get the input keywords
    WCS_input = get_header(fitsimage, 0, 1, list=WCS_keys, error=0)

    # if one of the input keywords is missing, go back
    if WCS_input == None:
	return 0

    # open the image, and extract the header
    fimg = pyfits.open(fitsimage, mode="update")
    kheader = fimg[0].header

    # insert the new items in inverse order all after 'DATe'
    # this way they will appear in correct order at the beginning
    kheader.update('CDELT2', WCS_input['CDSCALE'], '[arcsec/pixel] cross-dispersion scale',after='DATE')
    kheader.update('CRVAL2', 0.0, '[pixel] Reference value',after='DATE')
    kheader.update('CRPIX2', WCS_input['REFPNTY'], '[arcsec] Reference pixel',after='DATE')
    kheader.update('CUNIT2', 'arcsec', 'Cross-dispersion units',after='DATE')
    kheader.update('CTYPE2', 'CRDIST', 'Cross-dispersion distance',after='DATE')

    kheader.update('CDELT1', WCS_input['DLAMBDA'], '[Angstrom/pixel] dispersion',after='DATE')
    kheader.update('CRVAL1', WCS_input['LAMBDA0'], '[Angstrom] Reference value',after='DATE')
    kheader.update('CRPIX1', WCS_input['REFPNTX'], '[pixel] Reference pixel',after='DATE')
    kheader.update('CUNIT1', 'Angstrom', 'Dispersion units',after='DATE')
    kheader.update('CTYPE1', 'WAVE', 'Grating dispersion function',after='DATE')

    # save the modified image/header and close the fits
    fimg.flush()
    fimg.close()

    return 1

def make_dummy(filename):
    """
    Input:
        filename - name of the dummy image

    Return:
        0

    Description:
        Creates a dummy image just to fake later commands like
	'pet2spc' and 'stamps'. The dummy image is a multi
	extension fits image with the usual data, error, dq
	extension, but the pixel is a 10x10 array with
	zeros inside. The extensions fit to the
	new configuration file created in 'axedrizzle'.
    """
    if os.path.isfile(putDRIZZLE(filename)):
        os.unlink(putDRIZZLE(filename))

    imhdr1 = pyfits.PrimaryHDU()
    imhdr1.data = numpy.zeros((10,10), dtype=float)
    hdu1 = pyfits.ImageHDU(imhdr1.data, header=imhdr1.header,\
			   name='SCI')
    hdu1.header.update('extver',1)

    imhdr2 = pyfits.PrimaryHDU()
    imhdr2.data = numpy.zeros((10,10), dtype=float)
    hdu2 = pyfits.ImageHDU(imhdr2.data, header=imhdr2.header,\
			   name='ERR')
    hdu2.header.update('extver',1)

    imhdr3 = pyfits.PrimaryHDU()
    imhdr3.data = numpy.zeros((10,10), dtype=float)
    hdu3 = pyfits.ImageHDU(imhdr3.data, header=imhdr3.header,\
			   name='DQ')
    hdu3.header.update('extver',1)

    mex_hdu = pyfits.HDUList()
    mex_hdr = pyfits.PrimaryHDU()
    mex_hdu.append(mex_hdr)

    mex_hdu.append(hdu1)
    mex_hdu.append(hdu2)
    mex_hdu.append(hdu3)

    mex_hdu.writeto(putDRIZZLE(filename))
    mex_hdu.close()
    return 0


def get_objname(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary stamp image as input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the science image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_flt_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, '.BCK.') < 1:
	tmp2 = string.split(filename,'.')[0] + '_flt_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_flt_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_errname(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary error stamp image as
	       input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the error image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_err_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, '.BCK.') < 1:
	tmp2 = string.split(filename,'.')[0] + '_err_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_err_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_contname(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary contamination stamp image as
	       input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the contamination image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_con_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, '.BCK.') < 1:
	tmp2 = string.split(filename,'.')[0] + '_con_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_con_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_modname(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary model stamp image as
	       input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the model image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_mod_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, '.BCK.') < 1:
	tmp2 = string.split(filename,'.')[0] + '_mod_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_mod_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_varname(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary variance stamp image as
	       input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the variance image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_var_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, '.BCK.') < 1:
	tmp2 = string.split(filename,'.')[0] + '_var_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_var_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_inweight(filename, beam):
    """
    Input:
        filename - the name of the DPP file
	beam     - the object to work on

    Return:
        tmp2 - the name of the temporary weight stamp image as
	       input for drizzle

    Description:
        Take the DPP-filename and the beam name and return the
	name of the weight image which serves as drizzle input
	Example:

	j8m822qbq_flt_2.DPP.fits --> j8m822qbq_flt_2_wht_ID3.fits
    """
    tmp1 = get_objid(beam)
    if str.find(filename, 'BCK') < 1:
	tmp2 = string.split(filename,'.')[0] + '_wht_' + tmp1 + '.fits'
    else:
	tmp2 = string.split(filename,'.')[0] + '_wht_' + tmp1 + '.BCK.fits'	
    return tmp2

def get_drizzallimg(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined science drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined science drizzle output of this object.
	Example:

	aXedrizzle + ID4 --> aXedrizzle_flt_ID3.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_flt_' + objid + '.fits' 
    else:
         tmp = outroot + '_flt_' + objid + '.BCK.fits' 
    return tmp

def get_drizzallerr(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined error drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined error drizzle output of this object.
	Example:
	
	aXedrizzle + ID4 --> aXedrizzle_flt_ID3.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_err_' + objid + '.fits' 
    else:
         tmp = outroot + '_err_' + objid + '.BCK.fits' 
    return tmp

def get_drizzallcon(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined contamination drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined contamination drizzle output of this object.
	Example:

	aXedrizzle + ID4 --> aXedrizzle_con_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_con_' + objid + '.fits' 
    else:
         tmp = outroot + '_con_' + objid + '.BCK.fits' 
    return tmp

def get_drizzallmod(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined model drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined model drizzle output of this object.
	Example:

	aXedrizzle + ID4 --> aXedrizzle_mod_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_mod_' + objid + '.fits' 
    else:
         tmp = outroot + '_mod_' + objid + '.BCK.fits' 
    return tmp

def get_drizzallvar(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined variance drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined variance drizzle output of this object.
	Example:

	aXedrizzle + ID4 --> aXedrizzle_con_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_var_' + objid + '.fits' 
    else:
         tmp = outroot + '_var_' + objid + '.BCK.fits' 
    return tmp

def get_drizzallwht(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of the combined weight drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for the combined weight drizzle output of this object.
	Example:

	aXedrizzle + ID4 --> aXedrizzle_wht_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = outroot + '_wht_' + objid + '.fits' 
    else:
         tmp = outroot + '_wht_' + objid + '.BCK.fits' 
    return tmp

def get_drizzerrwht(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of a unique dummy drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for a dummy image of this object.
	Example:
	
	aXedrizzle + ID4 --> dummy_wht_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = 'dummy' + '_err_' + objid + '.fits' 
    else:
         tmp = 'dummy' + '_err_' + objid + '.BCK.fits' 
    return tmp

def get_drizzconwht(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of a unique dummy drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for a dummy image of this object.
	Example:

	aXedrizzle + ID4 --> dummy_wht_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = 'dummy' + '_wht_' + objid + '.fits' 
    else:
         tmp = 'dummy' + '_wht_' + objid + '.BCK.fits' 
    return tmp

def get_drizzmodwht(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of a unique dummy drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for a dummy image of this object.
	Example:

	aXedrizzle + ID4 --> dummy_mod_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = 'dummy' + '_mod_' + objid + '.fits' 
    else:
         tmp = 'dummy' + '_mod_' + objid + '.BCK.fits' 
    return tmp

def get_drizzvarwht(filename, outroot, objid):
    """
    Input:
        filename - a stamp image name to analyze for background mode
	outroot  - the output drizzle root name as specified in
	           the configuration file
        objid    - the object id of the beam/object

    Return:
        tmp - the name of a unique dummy drizzle image

    Description:
        Take the output root name and the object ID and return the
	name for a dummy image of this object.
	Example:

	aXedrizzle + ID4 --> dummy_var_ID4.fits
    """
    if str.find(filename, 'BCK') < 1:
        tmp = 'dummy' + '_var_' + objid + '.fits' 
    else:
         tmp = 'dummy' + '_var_' + objid + '.BCK.fits' 
    return tmp

def get_objid(beam):
    """
    Input:
        beam - the beam name

    Return:
        tmp2 - the beam id

    Description:
        Extracts the beam ID number from the beam name.
	Example:
	BEAM_3A  -> 3
    """
    tmp = string.split(string.strip(beam),'_')[1]
    tmp2 = 'ID' + tmp[:string.find(tmp,'A')]
    return tmp2

def get_mename(imname):
    """
    Input:
        imname - the name of the drizzled science image

    Return:
        tmp - name of the multi extension fits file

    Description:
       Returns the name of the multi extension fits file
       where all drizzled image are copied to.
    """
    tmp = imname.replace('_flt_', '_ext_')
    return tmp

def get_coefname(inname):
    """
    Input:
        inname - the input name

    Return:
        tmp - the name of the coefficients file

    Description:
        Returns the name of the coefficiens file
    """
    tmp = string.split(inname,'.fits')[0] + '.coeffs'
    return tmp

def make_spectra(list_filename, conf_filename, img_filename, af_filename,
		 opet_filename, bpet_filename, ospc_filename,stam_filename,
		 back, opt_extr):
    """
    Input:
        af_filename - the name of the file with all the
	              combined drizzle image names
	rootname    - the drizzle root name given in the configuration file
	back        - flagg whether background drizzle are computed

    Return:
        None

    Description:
        The function performs the tasks 'drz2pet', 'pet2spc'
	and 'stamps' on the combined drizzle images. uses
	all the lists, AF/BAF's and dummy images created before.
    """
    if back != 'YES':
	iraf.drz2pet(inlist=list_filename,config=conf_filename,
		      in_af=putDRIZZLE(af_filename), out_pet=putDRIZZLE(opet_filename),
		      back=back, opt_extr=opt_extr)
    else:
	iraf.drz2pet(inlist=list_filename,config=conf_filename,
		      in_af=putDRIZZLE(af_filename), out_pet=putDRIZZLE(bpet_filename),
		      back=back, opt_extr=opt_extr)
	if opt_extr:
	    list_filename = list_filename.replace ('.BCK.', '.')
	    print ''
	    print list_filename
	    print ''
	    iraf.drz2pet(inlist=list_filename,config=conf_filename,
			  in_af=putDRIZZLE(af_filename), out_pet=putDRIZZLE(opet_filename),
			  back='NO', opt_extr=opt_extr)	    

    iraf.pet2spc(grism=img_filename,config=conf_filename,drzpath='yes',use_bpet=back,
		  do_flux='YES', in_af=putDRIZZLE(af_filename),
		  opet=putDRIZZLE(opet_filename), bpet=putDRIZZLE(bpet_filename), out_spc=putDRIZZLE(ospc_filename))

    if opt_extr == iraf.no:
	iraf.stamp(grism=img_filename,config=conf_filename,drzpath='yes',
		    sampling="rectified", in_af=putDRIZZLE(af_filename),
		    in_pet=putDRIZZLE(opet_filename),out_stp=stam_filename)

def drzim_extract(rootname, extr_in, extrlist, makespc, back,
		  comb_list, opt_extr):

    img_filename  = rootname+'.fits'
    conf_filename = rootname+'.conf'

    for extitem in extrlist:

	if len(extrlist) > 1:
	    pfix = str(extitem).replace('.','')
	else:
	    pfix = ''

	opet_filename = rootname + pfix + '_2' + '.PET.fits'
	bpet_filename = rootname + pfix + '_2' + '.BCK.PET.fits'
	ospc_filename = rootname + pfix + '_2' + '.SPC.fits'
	bspc_filename = rootname + pfix + '_2' + '.BCK.SPC.fits'
	stam_filename = rootname + pfix + '_2' + '.STP.fits'

	if back != 'YES':
	    af_filename   = rootname + pfix + '_2' + '.OAF'
	    list_filename = rootname + '_2' + '.list'
	else:
	    af_filename   = rootname + pfix + '_2' + '.BAF'
	    list_filename = rootname + '_2' + '.BCK.list'

	success = make_affiles(list_filename, af_filename, comb_list,
			       extr_in, extitem)
	success = make_dummy(img_filename)

	if makespc == 'YES':
	    make_spectra(list_filename, conf_filename, img_filename,
			 af_filename, opet_filename, bpet_filename,
			 ospc_filename,stam_filename,back, opt_extr=iraf.no)
	    if opt_extr == iraf.yes:
		opet_filename = rootname + pfix + '_2_opt' + '.PET.fits'
		bpet_filename = rootname + pfix + '_2_opt' + '.BCK.PET.fits'
		ospc_filename = rootname + pfix + '_2_opt' + '.SPC.fits'
		bspc_filename = rootname + pfix + '_2_opt' + '.BCK.SPC.fits'
		stam_filename = rootname + pfix + '_2_opt' + '.STP.fits'
		make_spectra(list_filename, conf_filename, img_filename,
			     af_filename, opet_filename, bpet_filename,
			     ospc_filename,stam_filename,back, opt_extr)

def create_drizzleconf(config, modvar):

    keylist = []
	
    header = """
    #---------------------------------------------------
    #
    # Configuraton file to extract 1D spectra from
    # 2D drizzled images. The configuration file was
    # automatically created to be further used in tasks
    # as "aXe_DRZ2PET" and "aXe_PET2SPC". Please change
    # this file ONLY if you know what you are doing!
    #
    #---------------------------------------------------
    """
    
    keylist.append(configfile.ConfKey('INSTRUMENT', config.get_gvalue('INSTRUMENT')))
    keylist.append(configfile.ConfKey('CAMERA', config.get_gvalue('CAMERA')))
    keylist.append(configfile.ConfKey('SCIENCE_EXT', 'SCI'))
    keylist.append(configfile.ConfKey('DQ_EXT', 'DQ'))
    keylist.append(configfile.ConfKey('ERRORS_EXT', 'ERR'))
    keylist.append(configfile.ConfKey('WEIGHT_EXT', 'WHT'))
    keylist.append(configfile.ConfKey('FFNAME', 'None'))
    keylist.append(configfile.ConfKey('DRZRESOLA', config.get_gvalue('DRZRESOLA')))
    keylist.append(configfile.ConfKey('DRZSCALE', config.get_gvalue('DRZSCALE')))
    keylist.append(configfile.ConfKey('DRZLAMB0', config.get_gvalue('DRZLAMB0')))
    keylist.append(configfile.ConfKey('DRZXINI', config.get_gvalue('DRZXINI')))
    keylist.append(configfile.ConfKey('DRZPFRAC', config.get_gvalue('DRZPFRAC')))
    keylist.append(configfile.ConfKey('DRZPSCALE', config.get_gvalue('DRZPSCALE')))
    keylist.append(configfile.ConfKey('DRZKERNEL', config.get_gvalue('DRZKERNEL')))
    keylist.append(configfile.ConfKey('DRZROOT', config.get_gvalue('DRZROOT')))
    keylist.append(configfile.ConfKey('BEAMA', config.beams['A'].get_bvalue('BEAMA')))
    keylist.append(configfile.ConfKey('MMAG_EXTRACT_A', config.beams['A'].get_bvalue('MMAG_EXTRACT_A')))
    keylist.append(configfile.ConfKey('MMAG_MARK_A', config.beams['A'].get_bvalue('MMAG_MARK_A')))
    
    keylist.append(configfile.ConfKey('DYDX_ORDER_A', '1'))
    keylist.append(configfile.ConfKey('DYDX_A_0', '0.0'))
    keylist.append(configfile.ConfKey('DYDX_A_1', '0.0'))
    keylist.append(configfile.ConfKey('XOFF_A', '0.0'))
    keylist.append(configfile.ConfKey('YOFF_A', '0.0'))
    keylist.append(configfile.ConfKey('DISP_ORDER_A', '1'))
    keylist.append(configfile.ConfKey('DLDP_A_0', config.get_gvalue('DRZLAMB0')))
    keylist.append(configfile.ConfKey('DLDP_A_1', config.get_gvalue('DRZRESOLA')))
    keylist.append(configfile.ConfKey('SENSITIVITY_A', config.beams['A'].get_bvalue('SENSITIVITY_A')))
    if modvar:
	keylist.append(configfile.ConfKey('MODEL_EXT', 'MOD'))
	keylist.append(configfile.ConfKey('VARIANCE_EXT', 'VAR'))

    if config.get_gvalue('IPIXFUNCTION') != None:
        keylist.append(configfile.ConfKey('IPIXFUNCTION', config.get_gvalue('IPIXFUNCTION')))        

    drizzle_conf = configfile.ConfigList(keylist, header)
    print str(drizzle_conf)
    print 
    drizzle_conf.writeto(putCONF(config.get_gvalue('DRZROOT')+'.conf'))
