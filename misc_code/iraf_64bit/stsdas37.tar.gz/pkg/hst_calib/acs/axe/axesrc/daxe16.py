"""
This module includes the main functions
to execute the three pure python tasks
AXEPREP, AXECORE and AXEDRIZZLE. The main
functions are directly called by the three
iraf frontends 'axeprep_iraf.py', 'axecore_iraf.py'
and 'axedrizzle_iraf.py'
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys, os, string,math,stat
import string, pyfits
from pyraf import iraf
from iraf import stsdas
import pyfits, pydrizzle

import configfile
import axeprep, axedrizzle, axecore, fcubeprep, drz_coeffs, axeinputs
from   axedrzutils import *
import filechecks

AXE_IMAGE_PATH   = './'
AXE_OUTPUT_PATH  = './'
AXE_CONFIG_PATH  = './'
AXE_DRIZZLE_PATH = './'

def run_axecore(datafile='',
		confterm='',
		fconfterm='',
		back='NO',
		extrfwhm=0.0,
		drzfwhm=0.0,
		backfwhm=0.0,
		lambda_mark=800.0,
		autoo='YES',
		orient='YES',
		exclude='NO',
		cont_model='gauss',
		model_scale=3.0,
		inter_type='linear',
		lambda_psf=400.0,
		np=0,
		interp=0,
		niter_med=0,
		niter_fit=0,
		kappa=0.0,
                smooth_length=0,
                smooth_fwhm=0.0,
		spectr='NO',
		weights='NO',
		sampling='drzizzle',
                ipc_corr='no',
                nli_corr='no',
                max_ext=0.0):
    """
    Input:
        inlist      - list with input images
	configs     - configuration filenames for CCDs
	back        - create also the background PET ["YES"/"NO"]
	extrfwhm    - multiplicative factor for object mask image
	drzfwhm     - multiplicative factor for object extraction
                      after axedrizzle
	backfwhm    - multiplicative factor for background mask image
	exclude     - remove faint objects from the results?
	auto_orient - enable automatic extraction orientation? ["YES"/"NO"]
	orient      - use tilted extraction ["YES"/"NO"]
	cont_model  - the name of the contamination model ot be applied
	np          - number of points to use for computation
	interp      - type of interpolation to perform
	spectr      - extract spectra and stamp images
	do_flux     - perform flux calibration
	sampling   - rectify stamp image ["YES"/"NO"]

    Return:
        None

    Description:
        This function is the main program for the axe1.4 task AXECORE.
	Please consult the iraf help or the aXe manual at:
	http://www.stecf.org/software/aXe/index.html
	learn about the purpose of AXECORE.
    """
    success = get_environments()

    # unlearn the aXe tasks
    unlearn_axe()

    # check the existence of the Input Image List
    if  not os.path.isfile(datafile):
	report_error(360, dterm=datafile)	

    # create a list with the basic aXe inputs
    axe_inputs = axeinputs.aXeInputList(datafile, confterm, fconfterm)

    # perform basic checks on the list files
    file_checker = filechecks.FileChecker(axe_inputs, 'AXECORE')
    file_checker.check_axecore(fconfterm, cont_model, sampling)

    # check the consistency of the
    # input parameters
    axecore.check_input(back, extrfwhm, drzfwhm, backfwhm, orient,
			autoo, np, interp, cont_model, weights)

    # go over all the iput
    for item in axe_inputs:

        # store the drizzle coefficients in the flt files
        if drzfwhm > 0.0 \
	  or is_quant_contmodel(cont_model):
#          or distortion == 'YES':
            conf = configfile.ConfigFile(putCONF(item['CONFIG']))
            extvers = get_sciextvers(item['GRISIM'], conf)
            scinum  = get_sciextnum(item['GRISIM'], conf)
            drz_coeffs.get_coeffs(item['GRISIM'],extvers, scinum)


        # create the object PET
        axecore.make_extrcore(item['GRISIM'], 
                              putIMAGE(item['OBJCAT']), 
                              item['DIRIM'], item['CONFIG'],
                              extrfwhm, lambda_mark, exclude, autoo,orient,
                              item['DMAG'], cont_model, model_scale,
                              inter_type, lambda_psf, back)

        # create the background PET
        if back == 'YES':
            axecore.make_backcore(item['GRISIM'], item['CONFIG'],
                                  backfwhm, lambda_mark, exclude, autoo, orient,
                                  item['DMAG'], np, interp, niter_med, niter_fit,
                                  kappa, smooth_length, smooth_fwhm)

        if fconfterm:
            iraf.fringecorr(grism=item['GRISIM'], config=item['CONFIG'],
                             fconfig=item['FRINGE'], back=back)


        # create the SPC and STP, if requested
        if spectr == 'YES':
            axecore.make_spectr(item['GRISIM'], item['CONFIG'],
                                back, weights, sampling)

        # for geometrical contamination: create and 
        # store the correct contamination
        if drzfwhm > 0.0 and (not is_quant_contmodel(cont_model)):
            axecore.make_drzcont(item['GRISIM'], item['CONFIG'],\
                                 drzfwhm, lambda_mark, exclude, autoo,\
                                 orient, item['DMAG'], cont_model, back)

        if ipc_corr == 'YES' or nli_corr == 'YES':
            # check whether the number for the object extend
            # makes sense
            if max_ext <= 0.0:
                raise "AXECORE: maximal extend for point-like object as: " + str(max_ext) + " does not make sense!"

            # apply the intra-pixel correction function
            iraf.ipixcorr(item['GRISIM'], item['CONFIG'], ip_corr=ipc_corr,
                           nl_corr=nli_corr,max_ext=max_ext, in_OAF="",
                           in_SPC="", out_SPC="")

            

def run_axeprep(datafile='',
		confterm='',
		backgr='YES',
		backterm='',
		mfwhm='0.0',
		norm='YES',
		histogram='YES'):
    """
    Input:
        inlist    - list with input images
	configs   - configuration filenames for CCD's
	backgr    - subtract background image
	backims   - background image(s)
	mfwhm      - multiplicative factor for mask image
	norm      - normalize image image ["YES"/"NO"]
	histogram - show a histogram of the final image ["YES"/"NO"]

    Return:
        None

    Description:
        This function is the main program for the axe1.4 task AXEPREP.
	Please consult the iraf help or the aXe manual at:
	http://www.stecf.org/software/aXe/index.html
	to learn about the purpose of AXEPREP.
    """
    success = get_environments()
    
    # unlearn the aXe tasks
    unlearn_axe()

    # check the existence of the Input Image List
    if  not os.path.isfile(datafile):
	report_error(185, dterm=datafile)	

    # create a list with the basic aXe inputs
    axe_inputs = axeinputs.aXeInputList(datafile, confterm, backterm)

    # perform basic checks on the list files
    file_checker = filechecks.FileChecker(axe_inputs, 'AXEPREP')
    file_checker.check_axeprep(backterm)


    if backgr == 'YES' and backterm == None:
	report_error(175)


    # go over all the input
    for item in axe_inputs:

        entry = {}

	conf = configfile.ConfigFile(putCONF(item['CONFIG']))

        extvers = get_sciextvers(item['GRISIM'], conf)
        scinum  = get_sciextnum(item['GRISIM'], conf)

        # if a global background
        #subtraction is desired
        if backgr == 'YES':

            # put all relevant parameters into a
            # dictionary object
            entry['GRISM']  = item['GRISIM']
            entry['INSEX']  = putIMAGE(item['OBJCAT'])
            if item['DIRIM']:
                entry['DIRECT'] = item['DIRIM']
                entry['UDIRIM'] = 'YES'
            else:
                entry['DIRECT'] = None
                entry['UDIRIM'] = 'NO'

            entry['CONFIG'] = item['CONFIG']
            entry['FWHM']   = mfwhm
            entry['DMAG']   = item['DMAG']
            
            # create the mask image
            mask = axeprep.make_mask(entry)

            # ckeck whether the mask image exists
            if os.path.isfile(putOUTPUT(mask)):

                nicmos_data = axeprep.is_nicmos_data(item['GRISIM'])

                if nicmos_data:
                    success = axeprep.subtract_nicsky(item, mask, scinum, extvers, histogram)
                else:
                    success = axeprep.subtract_sky(item['GRISIM'], mask,
                                                   item['FRINGE'], extvers,
                                                   histogram)

            else:
                success = 1

            # report on problems if necessary
            if success != 0:
                report_error(150, image=putOUTPUT(mask))
            else:
                pstring = 'AXEPREP:  %25s[SCI,%s] sky-subtracted.' % (item['GRISIM'],extvers)
                print pstring


        if norm == 'YES':
            success = axeprep.transform_to_cps(item['GRISIM'], conf, backgr, extvers)
            if success > 0:
                report_error(180, image=item['GRISIM'])
            elif success < 0:
                pstring = 'AXEPREP:  Skip normalizing image %25s[SCI,%s].' % (item['GRISIM'],extvers)
                print pstring		    
            else:
                pstring = 'AXEPREP:  %25s[SCI,%s] normalized.' % (item['GRISIM'],extvers)
                print pstring



def run_axedrizzle(inlist,
		   confterm,
		   extr_in,
		   extr_oterm,
		   back,
		   makespc,
		   opt_extr):
    """
    Input:
        inlist  - name of image list 
	configs - configuration filenames for the CCD's 
	infwhm  - multiplicative factor in DPP's
	outfwhm - multiplicative factor for drizzled data
	back    - drizzling a background image ["YES"/"NO"]
	makespc - making the final SPC and STP ["YES"/"NO"]

    Return:
        None

    Description:
        This function is the main program for the axe1.4 task AXEDRIZZLE.
	Please consult the iraf help or the aXe manual at:
	http://www.stecf.org/software/aXe/index.html
	to learn about the purpose of AXEDRIZZLE.
    """
    success = get_environments()

    # unlearn the aXe tasks
    unlearn_axe()

    allobjects = {}
  
    # check the existence of the Input Image List
    if  not os.path.isfile(inlist):
	report_error(420, inlist=inlist)

    if back == 'YES':
	bckmode=1
    else:
	bckmode=0

    # create a list with the basic aXe inputs
    axe_inputs = axeinputs.aXeInputList(inlist, confterm)

    # perform basic checks on the list files
    file_checker = filechecks.FileChecker(axe_inputs, 'AXEDRIZZLE')
    file_checker.check_axedrizzle(bckmode)

    # well, this is obsolete now
    extrlist = resolve_ofwhm(str(extr_oterm))

    # do some consitency checks
    for drz_out in extrlist:
	if extr_in*drz_out < 0.0:
	    report_error(430, efwhm=extr_in, dfwhm=drz_out)
	    
    if extr_in > 0.0 and max(extrlist) >= extr_in:
	report_error(450, ifwhm=extr_in, ofwhm=max(extrlist))

    if extr_in < 0.0 and min(extrlist) <= extr_in:
	report_error(450, ifwhm=extr_in, ofwhm=min(extrlist))

    # delete a tmp-file from a previous run
    if os.path.isfile(putDRIZZLE('dummy2.fits')):
	os.unlink(putDRIZZLE('dummy2.fits'))



    # go over all the input
    for item in axe_inputs:

        # load the configuration file
	conf = configfile.ConfigFile(putCONF(item['CONFIG']))
        # check the drizzle keywords
        success = conf.drizzle_check()
        if success == 1:
            report_error(480, kernel=conf.get_gkey('DRZKERNEL'))

        # in case of drizzling backgrounds:
        # check that the foreground PET just exists
	if bckmode and makespc == 'YES':
	    opet_filename = conf.get_gvalue('DRZROOT') + '_2' + '.PET.fits'
	    if not os.path.isfile(putDRIZZLE(opet_filename)):
		report_error(470, opet=putDRIZZLE(opet_filename))

        sitem = item['GRISIM']
        scinum = get_sciextnum(sitem, conf)
        dppname, dppname_alt    = axedrizzle.get_dppname(sitem, scinum, bckmode)
        file_info  = axedrizzle.analyzefits(dppname)
        success    = axedrizzle.filet_dpp(dppname, opt_extr)
        cont_model = axedrizzle.get_cont_model(dppname, dppname_alt)
        allobjects = axedrizzle.slicedata(file_info, allobjects,
                                          conf, opt_extr)

    # convert a parameter to
    # a boolean variable
    if opt_extr == iraf.yes:
	modvar=1
    else:
	modvar=0

    # check whether there are
    # drizzled images
    if len(allobjects) > 0:

        # make a configuration file
        # for the drizzled images
        axedrizzle.create_drizzleconf(conf, modvar)

        # generate the multi-extention
        # fits images
	comb_list = axedrizzle.norm_wht_cont(allobjects, cont_model, opt_extr,
					     bckmode)
        # delete all files which
        # are no longer needed
	garbadge = allobjects['GARBAGE']
	for item in garbadge:
	    if os.path.isfile(putDRIZZLE(item)):
		os.unlink(putDRIZZLE(item))

        # extract spectra from the
        # 2D drizzled grism images
	axedrizzle.drzim_extract(conf.get_gvalue('DRZROOT'), extr_in,
				 extrlist, makespc, back, comb_list, opt_extr)


