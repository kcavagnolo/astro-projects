"""
This module contains specific functions for the aXe task axecore.
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pyraf import iraf
import configfile
import sys, math
from axedrzutils import *

def make_extrcore(grisim, objcat, dirim, config, mfwhm,
		  lambda_mark, exclude, autoo, orient, dmag, cont_model,
		  model_scale, inter_type, lambda_psf, back):
    """
    Input:
        grisim     - the input grism image
	objcat     - the object catalogue for the grism or direct image 
	config     - the configuration file
	mfwhm      - multiplicative factor for the apertures
	exclude    - remove faint objects from the results?
	autoo      - enable automatic extraction orientation? ["YES"/"NO"]
	orient     - use tilted extraction ["YES"/"NO"]
	dmag       - the dmag value for the grims image
	cont_model - the name of the contamination model to be applied
	back       - background flag

    Return:
        None

    Description:
        Performs the low level tasks sex2gol, gol2af, af2pet, ....
	until a complete axe reduction for the foreground
	of one axe grims image has been done. This is done in a straight
	forward assembly similar to a script running on an individual
	grism image.
	If no background PET is requested in the axecore task,
	a fake BAF which is identical to the OAF is added for
	compatibility reasons.
    """
#   sex2gol
    if dirim != None and len(dirim)>0:
	iraf.sex2gol(direct=dirim, grism=grisim, config=config,
		      in_sex=objcat, use_direct='YES',
		      dir_hdu='', spec_hdu='', out_sex='')
    else:
	iraf.sex2gol(grism=grisim, config=config, in_sex=objcat, dir_hdu='',
		      spec_hdu='', use_direct='NO')
#   gol2af
    iraf.gol2af(grism=grisim, config=config, mfwhm=mfwhm, back='NO',
		 orient=orient, auto_orient=autoo, exclude=exclude,
		 lambda_mark=lambda_mark, dmag=dmag, out_af='', in_gol='')
#   af2pet
    iraf.af2pet(grism=grisim, config=config, back='NO', out_pet='')
#   petcont
    iraf.petcont(grism=grisim, cont_model=cont_model, model_scale=model_scale,
		  inter_type=inter_type, lambda_psf=lambda_psf,
		  in_af='', config=config, cont_map='YES')
#   petff
    iraf.petff(grism=grisim, config=config, back='NO', ffname='')


def make_backcore(grisim, config, mfwhm, lambda_mark, exclude, autoo,
		  orient, dmag, np, interp, niter_med, niter_fit, kappa,
                  smooth_length, smooth_fwhm):
    """
    Input:
        grisim  - the input grism image
	config  - the configuration file
	mfwhm    - multiplicative factor for the apertures
	exclude - remove faint objects from the results?
	autoo   - enable automatic extraction orientation? ["YES"/"NO"]
	orient  - use tilted extraction ["YES"/"NO"]
	dmag    - the dmag value for the grims image
	np      - the number of points used in the background estimation
	interp  - the interpolation method for the background

    Return:
        None

    Description:
        Performs the low level tasks gol2af, backest, af2pet, ....
	until a complete axe reduction for the background
	of one axe grims image has been done. This is done in a straight
	forward assembly similar to a script running on an individual
	grism image.
    """
#   gol2af
    iraf.gol2af(grism=grisim, config=config, mfwhm=mfwhm, back='YES',
		 orient=orient, auto_orient=autoo, exclude=exclude,
		 lambda_mark=lambda_mark, dmag=dmag, out_af='', in_gol='')
#   backest
    iraf.backest(grism=grisim, config=config, mask='NO', np=np,
                 interp=interp, niter_med=niter_med, niter_fit=niter_fit,
                 kappa=kappa, smooth_length=smooth_length,
                 smooth_fwhm=smooth_fwhm, in_af='', out_back='')
#   af2pet
    iraf.af2pet(grism=grisim, config=config, back='YES', out_pet='')
#   petff 
    iraf.petff(grism=grisim, config=config, back='YES', ffname='')
    
def make_drzcont(grisim, config, mfwhm, lambda_mark, exclude, autoo,
		 orient, dmag, cont_model, back):
    """
    Input:
        grisim  - the input grism image
	config  - the configuration file
	mfwhm    - multiplicative factor for the apertures
	exclude - remove faint objects from the results?
	autoo   - enable automatic extraction orientation? ["YES"/"NO"]
	orient  - use tilted extraction ["YES"/"NO"]
	dmag    - the dmag value for the grims image
	back    - background flag

    Return:
        None

    Description:
        Does a gol2af run with drizzle extraction width for
        mfwhm, and finally a petcont-run to store the new contamination
	values in the PET. The contamination is different for
        the PET extraction width and the extraction width used
	after axedrizzle. this module provides the right
	contamination to the PET.
    """
    conf = configfile.ConfigFile(putCONF(config))
    rootname = grisim[:grisim.find('.fits')]
    pfix     = str(mfwhm).replace('.','')
    scinum   = get_sciextnum(grisim, conf)
    drzoaf   = rootname + pfix + '_' + str(scinum) + '.OAF'

#   gol2af
    iraf.gol2af(grism=grisim, config=config,  mfwhm=mfwhm, back='NO',
		 orient=orient, auto_orient=autoo, exclude=exclude,
		 lambda_mark=lambda_mark, dmag=dmag,
		 out_af=putOUTPUT(drzoaf), in_gol='')
#   petcont
    iraf.petcont(grism=grisim, config=config, cont_model=cont_model, 
		  in_af=putOUTPUT(drzoaf), cont_map='YES')

def make_spectr(grisim,config,back,weights,sampling):
    """
    Input:
        grisim    - the input grism image
	config    - the configuration file
	back      - background flag 
	do_flux   - do flux calibration 
	sampling - extract sampling stamp images

    Return:
        None

    Description:
        Performs the low level tasks pet2spc and stamps
	on the PET's of an individual grism image.
	A task collection as in a script to run
	axe on one grism image.
    """
    # pet2spc
    if back == 'YES':
	iraf.pet2spc(grism=grisim, config=config, drzpath='NO',
		      use_bpet='YES', do_flux='YES',  weights=weights,
		      in_af='', opet='', bpet='', out_spc='')
    else:
	iraf.pet2spc(grism=grisim, config=config, drzpath='NO',
		      use_bpet='NO', do_flux='YES', weights=weights,
		      in_af='', opet='', bpet='',
		      out_spc='')
    #stamps
    iraf.stamps(grism=grisim, config=config, drzpath='NO',
		 sampling=sampling, in_af='', in_pet='', out_stp='')

def check_input(back, extrfwhm, drzfwhm, backfwhm, orient,
		auto_orient, np, interp, cont_model, weights):
    """
    Input:
	back        - background flag 
        extrfwhm    - object extraction width
        drzfwhm     - drizzle extraction width
        backfwhm    - background extraction width
	orient      - extraction orientation flag
	auto_orient - auto-orient flag
	np          - number of interpolation points
	interp      - interpolation type

    Return:
        None

    Description:
        Performs some checks on the input parameter.
	Gives error message in case that the input
	is wrong or inconsistent or does not make
	sense. The rules are rather loosely and
	disconnected implemented.
    """
    # the extraction width must be set!
    if not extrfwhm:
	report_error(340)

    # negative extraction width is significant ONLY
    # if orient="NO"
    if orient == iraf.yes and extrfwhm < 0.0:
	report_error(370, mfwhm=extrfwhm)

    # for background extraction the width must be set! 
    if back == iraf.yes and not backfwhm:
	report_error(310)

    # extraction width and drizzle extraction width
    # must have the same sign
    if extrfwhm*drzfwhm < 0.0:
	report_error(355, efwhm=extrfwhm, dfwhm=drzfwhm)
    else:
	# the extractionwidth must be larger than the
	# drizzle extraction width
	if not math.fabs(extrfwhm) > math.fabs(drzfwhm):
	    report_error(385, dfwhm=drzfwhm, efwhm=extrfwhm)	    

    # extraction width and background extraction width
    # must have the same sign
    if back == iraf.yes and extrfwhm*backfwhm < 0.0:
	    report_error(345, efwhm=extrfwhm, bfwhm=backfwhm)
    # the background extraction width must be larger than the
    # object extraction width
    elif back == iraf.yes and math.fabs(extrfwhm) > math.fabs(backfwhm):
	    report_error(390, ifwhm=extrfwhm, ofwhm=backfwhm)

    # for background extraction the number of background
    # pixels must be set
    if back == iraf.yes and np == None:
	report_error(320)

    # for background extraction the interpolation
    # type must be set
    if back == iraf.yes and interp == None:
	report_error(320)

    if cont_model == "geometric" and weights == iraf.yes:
	report_error(335)
