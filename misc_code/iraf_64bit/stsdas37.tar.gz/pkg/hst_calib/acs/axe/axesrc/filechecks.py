"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pyraf import iraf
import configfile
import sys, math
from axedrzutils  import *
#from calib_lambda import *
from oaf_file     import *
from axe import asciidata


class FileChecker(object):

    def __init__(self, axeinputs, taskname):
        """
        Initializes the class
        """

        # get the environmental variables
#        get_environments()

        # store the parameters
        self._axeinputs = axeinputs
        self._taskname  = taskname

        # check for the existence of the
        # grism images
        self._check_grisims(axeinputs)

        # check for the existence of all
        # aXe configuration files
        self._all_configs = self._check_configs(axeinputs)


    def _check_grisims(self, axeinputs):
        """
        Check the existence of all grism images
        """
        # go over all inputs
        for index in range(len(axeinputs)):

            # get the grim image name
            grisim = axeinputs[index]['GRISIM']

            # check whether the grism image exists
            if  not os.path.isfile(putIMAGE(grisim)):
                # give an error if not
                report_error(510, command=self._taskname,
                             filename=putIMAGE(grisim))


    def _check_configs(self, axeinputs):
        """
        Check the existence of all aXe configuration files
        """
        all_configs = []

        # go over all inputs
        for index in range(len(axeinputs)):

            # get the configuration file name
            config = axeinputs[index]['CONFIG']

            # perhaps the config file was just checked
            if config in all_configs:
                continue

            # check whether the configuration file exists
            if  not os.path.isfile(putCONF(config)):
                # give an error if not
                report_error(510, command=self._taskname,
                             filename=putCONF(config))

            # append the config file to the list
            all_configs.append(config)

        # return the list of
        # all aXe configuration files        
        return all_configs


    def check_axeprep(self, backterm):
        """
        Comprises all file and file format checks for AXEPREP
        """
        # check the axe configuration files
        self.check_basic()

        # check for the fringe configuration files
#        if len(backterm) > 0:
#            self.check_fringe()
        if backterm != None and len(backterm) > 0:
            self.check_fringe()


    def check_axecore(self, fconfterm, cont_model, sampling):
        """
        Comprises all file and file format checks for AXECORE
        """
        self.check_basic()

        # check for the fringe configuration files
        if len(fconfterm) > 0:
            self.check_fringe()

        # check the axe configuration files
        self.check_config_format()

        # check for the existence of the FLX-files
        if cont_model == 'fluxcube':
            self.check_fluxcube()

        # check the prism conditions
        self.check_prism(cont_model, sampling)

        # check the IOL format
        self.check_IOLcolumns(cont_model)


    def check_axedrizzle(self, bckmode):
        """
        Comprises all file and file format checks for AXEDRIZZLE
        """
        # check the axe configuration files
        self.check_config_format()

        # check the existence of the
        # DPP files
        self.check_drzprep(bckmode)


    def check_basic(self):
        """
        Perform a basic data check 
        """
        # go over all inputs
        for index in range(len(self._axeinputs)):

            # get the configuration file name
            iol = self._axeinputs[index]['OBJCAT']

            # get the name of the direct image
            if self._axeinputs[index]['DIRIM']:
                dirim = self._axeinputs[index]['DIRIM']
            else:
                dirim = None

            # check whether the IOL exists
            if  not os.path.isfile(putIMAGE(iol)):
                # give an error if not
                report_error(510, command=self._taskname,
                             filename=putIMAGE(iol))

            if dirim and not os.path.isfile(putIMAGE(dirim)):
                # give an error if not
                report_error(510, command=self._taskname,
                             filename=putIMAGE(dirim))


    def check_fringe(self):
        """
        Check the existence of all fringe configuration files
        """
        all_fconfs = []

        # go over all inputs
        for index in range(len(self._axeinputs)):

            # get the name of the fringe configuration file
            if self._axeinputs[index]['FRINGE']:
                fconf = self._axeinputs[index]['FRINGE']
            else:
                continue

            # perhaps the config file was just checked
            if fconf in all_fconfs:
                continue

            # check whether the fringe configuration file exists
            if  not os.path.isfile(putCONF(fconf)):
                # give an error if not
                report_error(350, cterm=putCONF(fconf))


    def check_config_format(self):
        """
        Check the format and content of the aXe configuration files
        """
        # check all configuration files
        # for consistent keyword and the
        # existence of the files mentioned there
        for citem in self._all_configs:
            # load the config file
            conf = configfile.ConfigFile(putCONF(citem))

            # check the drizzle keywords
            success = conf.drizzle_check()
            if success == 1:
                report_error(480, kernel=conf.get_gkey('DRZKERNEL'))

            # check the existence of the
            # calibration files
            conf.check_files()


    def check_fluxcube(self):
        """
        Check for the existence of the fluxcube files
        """
        # go over all inputs
        for index in range(len(self._axeinputs)):

            # load the configuration
            conf = configfile.ConfigFile(putCONF(self._axeinputs[index]['CONFIG']))

	    # get the science extension number
	    scinum = get_sciextnum(self._axeinputs[index]['GRISIM'], conf)

	    # form the FLX name
	    flxname    = get_flxname(self._axeinputs[index]['GRISIM'], scinum)

	    # check whether the FLX exists
	    if not os.path.isfile(putIMAGE(flxname)):
		report_error(510, command=self._taskname,
                             filename=putIMAGE(flxname))


    def check_drzprep(self, bckmode):
        """
        Check for the existence of the DPP files
        """
        
        # go over all inputs
        for index in range(len(self._axeinputs)):

            # load the configuration
            conf = configfile.ConfigFile(putCONF(self._axeinputs[index]['CONFIG']))

	    # get the science extension number
	    scinum = get_sciextnum(self._axeinputs[index]['GRISIM'], conf)

	    # get the science extension number
	    scinum = get_sciextnum(self._axeinputs[index]['GRISIM'], conf)

	    # form the DPP name
	    dppname, dppname_alt = get_dppname(self._axeinputs[index]['GRISIM'], scinum, bckmode)

	    # check whether the DPP exists
	    if not os.path.isfile(putOUTPUT(dppname)):
		report_error(510, command=self._taskname, filename=putOUTPUT(dppname))


    def check_prism(self, cont_model, sampling):
        """
        Input:
	    axeitem    - the dictionary with the input
            cont_model - the name of the contamination model
            sampling   - requested sampling for stamp images
        Return:
            -

        Description:
            Does some additional checks for prism images. There
	    special conditions have to be applied.
        """

        # go over all inputs
        for index in range(len(self._axeinputs)):

            # read the image names
            grisim = self._axeinputs[index]['GRISIM']
            dirim  = self._axeinputs[index]['DIRIM']

            # read the filter keywords from the image 
            hlist = ['FILTER1', 'FILTER2']
            header = get_header(putIMAGE(grisim), list=hlist, error=0)

            # check whether it is prism data
            if header and (header['FILTER1'].find('PR') > -1
                           or header['FILTER2'].find('PR') > -1):

                # prism data MUST have a direct image
                if not dirim:
                    report_error(375)

                # the fluscube contamination does not work for prism data
                if cont_model.lower() == "fluxcube":
                    report_error(365)

                # drizzled stamp images are not supported for prism data
                if sampling.lower() == "drizzle":
                    report_error(325)


    def check_IOLcolumns(self, cont_model):
        """
        Checks the IOL format
        """
        import axecat

        # go over all inputs
        for index in range(len(self._axeinputs)):

            # extract the catalogue name
            catname = self._axeinputs[index]['OBJCAT']

            # make a catalogue
            acat = axecat.AXeCat(putIMAGE(string.strip(catname)))

            # make the consistency determination
            success = acat.setaxecols()

            # report on general errors
            if success:
                report_error(305, incat=putIMAGE(string.strip(catname)))

            # report if incorrect magnitude column format
            if cont_model == 'gauss' and not acat.magwave:
                report_error(315, incat=putIMAGE(string.strip(catname)))

