"""This module contains specific functions for the aXe task axeprep.
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os, string
from pyraf import iraf
from pyraf.iraf import stsdas
import pyfits, pydrizzle
from axedrzutils import *
import configfile


def transform_to_cps(imagefile, conf, backgr,ext):
    """
    Input:
        imagefile - the input image name
        conf      - the configuration structure
	backgr    - flagg whether a background image has been removed
	ext       - the targeted extension version 

    Return:
        0/-1       - 0 for OK, -1 if normalization was not done

    Description:
        The function transforms flt-images into counts per second,
	the input unit for aXe. Also the error array is tranformed
	into counts per second. The keywords 'SKY_CPS' with the sky
	background value is stored.
	Also the keyword 'AXEPRNOR' is set to indicate that
	the flt-image was transformed to cps.
	In case that the function encounters a flt-image
	with keyword 'AXEPRNOR' just set, the user has to explicitly
	allow the second normalization and also gets an option to quit
	any further program execution.
	The second normalization usually makes the flt unusable for
	further reduction with aXe. The additional interaction can
	save the user from spoiling the flt-frames.
    """

    dec = 1

    ext_image = imagefile+'[SCI,'+str(ext)+']'
    ext_image2 = imagefile+'[SCI,'+str(ext)+',overwrite]'
    err_image = imagefile+'[ERR,'+str(ext)+']'
    err_image2 = imagefile+'[ERR,'+str(ext)+',overwrite]'

#    conf_keys = conf.get_config()
    if not conf.get_gkey('EXPTIME'):
	exptime_kword = 'EXPTIME'
    else:
	exptime_kword = conf.get_gvalue('EXPTIME')

    hlist = [exptime_kword]
    kheader1 = get_header(putIMAGE(imagefile),list=hlist)

    hlist = ['AXEPRNOR']
    check = get_header(putIMAGE(imagefile), ext='SCI', ver=ext,
		       list=hlist, error=0)
    if check != None:
	dec = report_warning(110,image=putIMAGE(imagefile))

    if dec:
	pstring = 'aXe_PREPARE: Image %25s exposure time %7.1f.' % (ext_image, kheader1[exptime_kword])
	print pstring
	irafout=iraf.imarith(operand1=putIMAGE(ext_image), op='/',
			     operand2=kheader1[exptime_kword],
			     result=putIMAGE(ext_image2),
			     title='', divzero=0.0, hparams='', pixtype='',
			     calctype='',
			     verbose='NO', noact='NO', Stdout=1)
        irafout=iraf.imarith(operand1=putIMAGE(err_image), op='/',
			     operand2=kheader1[exptime_kword],
			     result=putIMAGE(err_image2),
			     title='', divzero=0.0, hparams='', pixtype='',
			     calctype='',
			     verbose='NO', noact='NO',  Stdout=1)

	irafout=iraf.hedit(images=putIMAGE(ext_image), verify='NO',show='YES',
			   add='YES', field='AXEPRNOR', value='Done', update='YES',
			   addonly='NO', delete='NO', Stdout=1)

	# check for the constant background level subtracted
	# in multidrizzle
	hlist = ['MDRIZSKY']
	kheader3 = get_header(putIMAGE(imagefile),list=hlist, error=0)

	# check  hether a global bias subtraction was done
	# in axeprep
	if backgr == 'YES':

	    # read the desctiptors written
	    # in the global bias subtraction
	    hlist = ['SKY_SCAL','SKY_MAST']
	    kheader2 = get_header(putIMAGE(imagefile), ext='SCI', ver=ext,
				  list=hlist)

	    # compute the total subtracted background level
	    # in multidrizzle and axeprep (in cps)
	    if (kheader3):
		sky_cps = (kheader2['SKY_SCAL'] * kheader2['SKY_MAST'] + kheader3['MDRIZSKY']) / kheader1[exptime_kword]
	    else:
		sky_cps = (kheader2['SKY_SCAL'] * kheader2['SKY_MAST']) / kheader1[exptime_kword]
	else:

	    # compute the total subtracted bias level (in cps)
	    if (kheader3):
		sky_cps = kheader3['MDRIZSKY'] / kheader1[exptime_kword]
	    else:
		sky_cps = 0.0

	# write the subtracted background level
	# into a defined descriptor for later use
	irafout=iraf.hedit(images=putIMAGE(ext_image), verify='NO',
			   show='YES',add='YES', field='SKY_CPS', update='YES',
			   value=sky_cps, addonly='NO', delete='NO', Stdout=1)
    else:
	return -1

    return 0

def is_nicmos_data(grisim):
    """
    Input:
        grisim - the input image name
	ext    - the background mask name
	mst_sky   - the master background image
	ext       - the targeted extension version 
	histogram - flagg to show the histogram of the background
	            subtracted image
    Return:
        0/1        - 0 for OK
    """
    hlist = ['INSTRUME']
    header = get_header(putIMAGE(grisim), ext=0, ver=0,
                        list=hlist, error=0)

    if header['INSTRUME'].find('NICMOS') > -1:
        return 1
    else:
        return 0

def subtract_nicsky(item, msk_img, scinum, ext, histogram):
    """
    Input:
        inp_image - the input image name
	msk_image - the background mask name
	mst_sky   - the master background image
	ext       - the targeted extension version 
	histogram - flagg to show the histogram of the background
	            subtracted image
    Return:
        0         - 0 for OK

    Description:
    """
    # compose the extension name
    inp_image_sc = putIMAGE(item['GRISIM']) + '[SCI,'+str(ext)+']'

    # check whether itis the first
    # subtraction of the background
    hlist = ['AXEPRBCK']
    check = get_header(putIMAGE(item['GRISIM']), ext='SCI', ver=ext,
		       list=hlist, error=0)
    # give a warning if a background
    # already had been subtracted
    if check != None:
	dec = report_warning(120,image=inp_image_sc)


    # compose the parameter string for the background task
    cmd_str = item['GRISIM'] + ' ' + item['CONFIG'] + ' ' + item['FRINGE']

    # invoke the background task
    status = make_nicback(cmd_str)

    # compose the name of the background
    bckname = string.split(item['GRISIM'],'.fits')[0] + '_' + \
              str(scinum) + '.NBCK.fits'

    # check whether the background image exists
    if not os.path.isfile(putOUTPUT(bckname)):
        report_error(150, image=putOUTPUT(bckname))

    imexpr = '"a-b"'
    inp_image_res =  putIMAGE(item['GRISIM']) + '[SCI,'+str(ext)+',overwrite]'
    irafout=iraf.imexpr(expr=imexpr, output=inp_image_res,
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=inp_image_sc,b=putOUTPUT(bckname+"[1]"),
			rangecheck='YES', verbose='YES',Stdout=1)

    
    if histogram =='YES':
	irafout=iraf.imstat(images=inp_image_sc,
			    fields='midpt,stddev', binwidt=0.01, lower='INDEF',
			    upper='INDEF', format='YES', cache='NO',
			    nclip=3, lsigma=3.0, usigma=3.0, Stdout=1)
	line = string.split(irafout[1])
	lower=float(line[0])-5*float(line[1])
	upper=float(line[0])+5*float(line[1])
	irafout=iraf.imhist(image=inp_image_sc, z1=lower, z2=upper,
			    binwidth='INDEF', nbins=512, autoscale='YES',
			    top_closed='NO', hist_type='normal', listout='NO',
			    plot_type='line', logy='YES', device='stdgraph', 
			    Stdout=1)

    # extract keyword information
    # from the header
    hlist = ['SKY_SCAL', 'F_SKYPIX']
    header = get_header(putOUTPUT(bckname), ext='BCK',
                        list=hlist, error=0)

    # check whether the keywords were found
    if header != None:
        # transfer important keywords
        # to the grism image
        irafout=iraf.hedit(images=inp_image_sc, verify='NO',show='YES',
                           add='YES', field='SKY_SCAL', value=float(header['SKY_SCAL']),
                           update='YES', addonly='NO', delete='NO', Stdout=1)
        irafout=iraf.hedit(images=inp_image_sc, verify='NO',show='YES',
                           add='YES', field='F_SKYPIX', value=float(header['F_SKYPIX']),
                           update='YES', addonly='NO', delete='NO', Stdout=1)
        

    irafout=iraf.hedit(images=inp_image_sc, verify='NO',show='YES',\
		       add='YES', field='AXEPRBCK', value='Done', update='YES',
		       addonly='NO', delete='NO', Stdout=1)
    irafout=iraf.hedit(images=inp_image_sc, verify='NO',show='YES', \
		       add='YES', field='SKY_IMG', value=item['FRINGE'], update='YES',
		       addonly='NO', delete='NO', Stdout=1)


    return 0

def make_nicback(cmd_str):
    execfile = 'axebin$aXe_NICBACK'
    fname = iraf.osfn(execfile)
    cmd_str = fname + ' ' + cmd_str
    status = iraf.clOscmd(cmd_str)
    return status

def subtract_sky(inp_image, msk_img, mst_sky, ext, histogram):
    """
    Input:
        inp_image - the input image name
	msk_image - the background mask name
	mst_sky   - the master background image
	ext       - the targeted extension version 
	histogram - flagg to show the histogram of the background
	            subtracted image
    Return:
        0         - 0 for OK

    Description:
        The function performs the background subtraction on a flt file.
	It needs the master background image and a mask file, an
	image where the pixels in the beams are marked with -1000000.
	The beam pixels are masked out on both, the grism image
	and the master background. The mean intensity is determined
	on both using the median, and then the scaled version of
	the master background is subtracted from the grism image.
	Some keywords are created in the flt-file to store background value
	and the name of the master sky used for background subtraction.
	Also the keyword 'AXEPRBCK' is set to indicate that background
	subtraction has been performed on the image.
	In case that the function meets a flt image with this flag just
	set, a warning message is printed out.
    """
    tmpname1 = get_random_filename('','.fits')
    tmpname2 = get_random_filename('','.fits')
    tmpname3 = get_random_filename('','.fits')
    tmpname4 = get_random_filename('','.fits')
    tmpname5 = get_random_filename('','.fits')

    inp_image_dq = inp_image + '[DQ,'+str(ext)+']'
    inp_image_sc = inp_image + '[SCI,'+str(ext)+']'
    msk_image_sc = msk_img   + '[SCI]'

    hlist = ['AXEPRBCK']
    check = get_header(putIMAGE(inp_image), ext='SCI', ver=ext,
		       list=hlist, error=0)
    if check != None:
	dec = report_warning(120,image=putIMAGE(inp_image_sc))

    hlist = ['NAXIS1','NAXIS2']
    kheader = get_header(putIMAGE(inp_image), ext='SCI', ver=ext,
		       list=hlist, error=1)
    npix = float(kheader['NAXIS1'])*float(kheader['NAXIS2'])

    """
    imexpriraf. = '"(a>0.5) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname1),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(inp_image_dq), b=putIMAGE(inp_image_sc),
			Stdout=1)
    imexpr = '"(a<-900000) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname4),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putOUTPUT(msk_image_sc), b=putIMAGE(tmpname1),
			Stdout=1)

    imexpr = '"(a>0.5) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname2),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(inp_image_dq), b=putCONF(mst_sky),
			Stdout=1)
    imexpr = '"(a<-900000) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname5),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putOUTPUT(msk_image_sc), b=putIMAGE(tmpname2),
			Stdout=1)

    statout = iraf.imstat(images=putIMAGE(tmpname4),
			  fields='midpt,stddev,npix', lower=-900000,
			  upper="INDEF", nclip=3, lsigma=3.0, usigma=3.0,
			  binwidth=0.1, format="YES", Stdout=1)
    img_ave = float(string.split(statout[1])[0])
    img_std = float(string.split(statout[1])[1])
    img_npx = float(string.split(statout[1])[2])

    statout = iraf.imstat(images=putIMAGE(tmpname5),
			  fields='midpt,stddev,npix', lower=-900000,
			  upper="INDEF", nclip=3, lsigma=3.0, usigma=3.0,
			  binwidth=0.1, format="YES", Stdout=1)
    mst_ave = float(string.split(statout[1])[0])
    mst_std = float(string.split(statout[1])[1])
    mst_npx = float(string.split(statout[1])[2])

    scale = str(img_ave/mst_ave)
    npix  = img_npx/npix

    irafout=iraf.imcopy(input=putIMAGE(inp_image_sc),
			output=putIMAGE(tmpname3), Stdout=1)
    imexpr = '"a-'+scale+'*b"'
    inp_image_sc = inp_image + '[SCI,'+str(ext)+',overwrite]'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(inp_image_sc),
			a=putIMAGE(tmpname3),b=putCONF(mst_sky), Stdout=1)
    """
    imexpr = '"a/b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname1),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(inp_image_sc),b=putCONF(mst_sky),
			rangecheck='YES', verbose='YES', Stdout=1)
    imexpr = '"(a>0.5) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname2),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(inp_image_dq), b=putIMAGE(tmpname1),
			rangecheck='YES', verbose='YES', Stdout=1)
    imexpr = '"(a<-900000) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname4),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putOUTPUT(msk_image_sc), b=putIMAGE(tmpname2),
			rangecheck='YES', verbose='YES', Stdout=1)

    os.unlink(putIMAGE(tmpname1))
    os.unlink(putIMAGE(tmpname2))
	
    imexpr = '"(a>0.5) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname2),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(inp_image_dq), b=putCONF(mst_sky),
			rangecheck='YES', verbose='YES', Stdout=1)
    imexpr = '"(a<-900000) ? -1000000 : b"'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(tmpname5),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putOUTPUT(msk_image_sc), b=putIMAGE(tmpname2),
			rangecheck='YES', verbose='YES', Stdout=1)

    statout = iraf.imstat(images=putIMAGE(tmpname4),
			  fields='midpt,stddev,npix', lower=-900000,
			  upper="INDEF", nclip=3, lsigma=3.0, usigma=3.0,
			  binwidth=0.01, format="YES", cache='NO', Stdout=1)

    flt_ave = float(string.split(statout[1])[0])
    flt_std = float(string.split(statout[1])[1])
    flt_npx = float(string.split(statout[1])[2])
    npix  = flt_npx/npix

    statout = iraf.imstat(images=putIMAGE(tmpname5),
			  fields='midpt,stddev,npix', lower=-900000,
			  upper="INDEF", nclip=3, lsigma=3.0, usigma=3.0,
			  binwidth=0.01, format="YES", cache='NO', Stdout=1)
    mst_ave = float(string.split(statout[1])[0])
    mst_std = float(string.split(statout[1])[1])
    mst_npx = float(string.split(statout[1])[2])

    irafout=iraf.imcopy(input=putIMAGE(inp_image_sc),
			output=putIMAGE(tmpname3), verbose='YES', Stdout=1)
    imexpr = '"a-'+str(flt_ave)+'*b"'
    inp_image_sc = inp_image + '[SCI,'+str(ext)+',overwrite]'
    irafout=iraf.imexpr(expr=imexpr, output=putIMAGE(inp_image_sc),
			dims='auto', intype='auto', outtype='auto',
			refim='auto', bwidth=0, btype='nearest',bpixval=0.0,
			exprdb='none',
			a=putIMAGE(tmpname3),b=putCONF(mst_sky),
			rangecheck='YES', verbose='YES',Stdout=1)


    inp_image_sc = inp_image + '[SCI,'+str(ext)+']'
    hval = '"' + str(flt_ave) + '"/ scale for master sky'
    irafout=iraf.hedit(images=putIMAGE(inp_image_sc), verify='NO',show='YES', \
		       add='YES', field='SKY_SCAL', value=float(flt_ave), update='YES',
		       addonly='NO', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putIMAGE(inp_image_sc), verify='NO',show='YES', \
		       add='YES', field='SKY_MAST', value=float(mst_ave), update='YES',
		       addonly='NO', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putIMAGE(inp_image_sc), verify='NO',show='YES', \
		       add='YES', field='SKY_IMG', value=mst_sky, update='YES',
		       addonly='NO', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putIMAGE(inp_image_sc), verify='NO',show='YES',\
		       add='YES', field='F_SKYPIX', value=npix, update='YES',
		       addonly='NO', delete='NO', Stdout=1)

    irafout=iraf.hedit(images=putIMAGE(inp_image_sc), verify='NO',show='YES',\
		       add='YES', field='AXEPRBCK', value='Done', update='YES',
		       addonly='NO', delete='NO', Stdout=1)

    if histogram =='YES':
	irafout=iraf.imstat(images=putIMAGE(inp_image_sc),
			    fields='midpt,stddev', binwidt=0.01, lower='INDEF',
			    upper='INDEF', format='YES', cache='NO',
			    nclip=3, lsigma=3.0, usigma=3.0, Stdout=1)
	line = string.split(irafout[1])
	lower=float(line[0])-5*float(line[1])
	upper=float(line[0])+5*float(line[1])
	irafout=iraf.imhist(image=putIMAGE(inp_image_sc), z1=lower, z2=upper,
			    binwidth='INDEF', nbins=512, autoscale='YES',
			    top_closed='NO', hist_type='normal', listout='NO',
			    plot_type='line', logy='YES', device='stdgraph', 
			    Stdout=1)

    os.unlink(putIMAGE(tmpname2))
    os.unlink(putIMAGE(tmpname3))
    os.unlink(putIMAGE(tmpname4))
    os.unlink(putIMAGE(tmpname5))

    return 0


def store_coeffs(image, xcoeffs, ycoeffs, scinum):
    """
    Input:
        image   - the image name
	xcoeffs - list with x-coefficients
	ycoeffs - list with y-coefficients
	scinum - the targeted extension version 

    Return:
        -

    Description:
        The function stores the drizzle coefficients in the
	header of the image. Those drizzle coefficients are
	the ones to remove the image distortions, and were
	computed with PyDrizzle.
	They are stored in the Keywords 'DRZ(scinum)X/Y(num)',
	where number simply runs from 1 to the number of coefficients.
	Also the keywords 'DRZSCALE' and 'DRZCNUM' are set
	to store the basic scale out the output drizzle and
	the number of coefficients, respectively.
    """

    length = len(xcoeffs)

    flt_imag = pyfits.open(putIMAGE(image),'update', memmap=0)
    flt_head = flt_imag[0].header

    flt_head.update('DRZCNUM', length,comment='Number of coefficients per coordinate')

    
    instrume = string.strip(flt_head.get('INSTRUME'))
    detector = flt_head.get('DETECTOR')
    if detector == None:
        detector = flt_head.get('CAMERA')
    else:
        detector = string.strip(detector)
    
    if instrume == 'ACS' and detector == 'HRC':
	flt_head.update('DRZSCALE', 0.025,comment='Scale for drizzling')
    elif instrume == 'ACS' and detector == 'SBC':
	flt_head.update('DRZSCALE', 0.025,comment='Scale for drizzling')
    elif instrume == 'ACS' and detector == 'WFC':
	flt_head.update('DRZSCALE', 0.050,comment='Scale for drizzling')
    elif instrume == 'NICMOS' and detector == 3:
#    elif instrume == 'NICMOS' and detector == 'NIC3':
	flt_head.update('DRZSCALE', 0.20,comment='Scale for drizzling')
    else:
	report_warning(140,image=putIMAGE(image))
	flt_head.update('DRZSCALE', 1.0,comment='Default scale for drizzling')
	
	
    for index in range(length):
	keyname = 'DRZ%01iX%02i' % (int(scinum), index+1)
	keycomm = 'Drizzle coefficient %02i in X' % (index+1)
	flt_head.update(keyname, xcoeffs[index],comment=keycomm)
    for index in range(length):
	keyname = 'DRZ%01iY%02i' % (int(scinum), index+1)
	keycomm = 'Drizzle coefficient %02i in Y' % (index+1)
	flt_head.update(keyname, ycoeffs[index],comment=keycomm)

    flt_imag.close()

def get_coeffs_old(image, extvers, scinum):
    """
    Input:
        image   - the image name
	extvers - the targeted extension version 
	scinum  - axe number of the science extension version

    Return:
        -

    Description:
        The function creates and reads in the drizzle coefficients
	to create undistorted images for the specified extension version.
	The coefficients themselves are created calling
	PyDrizzle. The coefficients file is read in,
	and are call to the function 'store_coeffs'
	stores the coefficients in the header.

	Note about the coefficient file:
	If the image is in the current directory,
	PyDrizzle creates a coefficient file following the
	naming convention
	'grism_flt.fits' --> 'grism_coeffs(scinum).dat'
	If the image is NOT in the current directory, it creates a
	coefficient file with the name '_coeffs'+ext+'.dat'. This
	behaviour is also there if you point to the correct image`
	location via the parameter of the PyDrizzle method.
    """

    xcoeffs = []
    ycoeffs = []

    cfname = None

    try:
	# create a distortion coefficient file
	pydrizzle.PyDrizzle(putIMAGE(image))
    except:
	# if this fails, create a default coefficients file
#	report_error(610, command='pydrizzle.PyDrizzle("'+str(putIMAGE(image))+'")')
	cfname = 'dummy_coeffs.dat'
	make_dummy_coeffs(putIMAGE(cfname))
#------------------------------------------------------------------------
#
#  If the image is in the current directory,
#  PyDrizzle creates a coefficient file following the
#  naming convention in the next line. If the image is NOT
#  in the current directory, it creates a coefficient file
#  with the name '_coeffs'+ext+'.dat'. This behaviour is also
#  there if you pint to the correct image location via the parameter.

    # check whether a distortion coefficient
    # file is already defined
    if not cfname:
	# derive the regular coefficients filename
	# default is ACS
	hlist = ['CCDCHIP']
	header = get_header(putIMAGE(image), 'SCI', extvers, hlist, 0)
	if header == None:
	    # this branch is for NICMOS
	    hlist = ['CAMERA']
	    header = get_header(putIMAGE(image), 0, 0, hlist, 0)
	    if header == None:
		chipnum = 1
	    else:
		# here for ACS/HRC
		chipnum = header['CAMERA']
	    cfname = image.replace('.fits','_coeffs'+str(chipnum)+'.dat')
	else:
	    # the ACS branch
	    chipnum = header['CCDCHIP']
	    cfname = image.replace('.fits','_coeffs'+str(chipnum)+'.dat')

    # check whether the coefficients file does exist
    if not os.path.isfile(putIMAGE(cfname)):
	# this try is to correct for
	# an old STSDAS bug
	cfname2 = '_coeffs'+str(chipnum)+'.dat'

	if not os.path.isfile(cfname2):
	    # if everything fails, report an error
	    report_error(110, cfile1=putIMAGE(cfname), cfile2=putIMAGE(cfname2))
	else:
	    # load the file and destroy it on disk
	    print 'AXEPREP: Using coefficient file:', cfname2
	    cfile = file(cfname2)
	    coeffs = cfile.readlines()
	    cfile.close()
	    os.unlink(cfname2)
    else:
	# load the file and destroy it on disk
	print 'AXEPREP: Using coefficient file:', cfname
	cfile = file(putIMAGE(cfname), 'r')
	coeffs = cfile.readlines()
	cfile.close()
	os.unlink(putIMAGE(cfname))
#
#------------------------------------------------------------------------


    first = 0
    for line in coeffs:
	if line[0] == '#':
	    continue
	elif len(string.strip(line)) == 0:
	    first = 1
	elif isstringlike(string.split(string.strip(line))[0]) == 1:
	    continue
	else:
	    scoeffs = string.split(string.strip(line))
	    for number in scoeffs:
		if first == 0:
		    xcoeffs.append(float(number))
		else:
		    ycoeffs.append(float(number))
    
    store_coeffs(image, xcoeffs, ycoeffs, scinum)


    # mop up all remaining files created by pydrizzle:
    msk1name = image.replace('.fits','_final_mask1.fits')
    msk2name = image.replace('.fits','_final_mask2.fits')
    sing1name = image.replace('.fits','_single_mask1.fits')
    sing2name = image.replace('.fits','_single_mask2.fits')
    coeff1name = image.replace('.fits','_coeffs1.dat')
    coeff2name = image.replace('.fits','_coeffs2.dat')

    if os.path.isfile(putIMAGE(msk1name)):
        os.unlink(putIMAGE(msk1name))
    if os.path.isfile(putIMAGE(msk2name)):
        os.unlink(putIMAGE(msk2name))
    if os.path.isfile(putIMAGE(sing1name)):
        os.unlink(putIMAGE(sing1name))
    if os.path.isfile(putIMAGE(sing2name)):
        os.unlink(putIMAGE(sing2name))
    if os.path.isfile(putIMAGE(coeff1name)):
        os.unlink(putIMAGE(coeff1name))
    if os.path.isfile(putIMAGE(coeff2name)):
        os.unlink(putIMAGE(coeff2name))

def make_dummy_coeffs(coeff_file):

    if os.path.isfile(coeff_file):
        os.unlink(coeff_file)
    
    dummy_coeffs = """# Dummy polynomial distortion coefficients
# file, created bz aXe 
cubic
  0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0 

  0.0  0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0
"""
    cfile = open(coeff_file, 'w+')
    cfile.write(dummy_coeffs)
    cfile.close()

    return 1
    

def make_mask(instruct):
    """
    Input:
        instruct - structure with the necessary information
	           concerning grism image name, direct image name
		   object cat and mfwhm-value

    Return:
        maskname - the name of the mask image created

    Description:
        The function creates a mask image for the grism image
	specified in the input structure.
	To do that ite executes some standard aXe tasks.
	The mask name is done with th backest-task and
	the option 'mask' set.	
    """
    iraf.sex2gol(direct=instruct['DIRECT'], grism=instruct['GRISM'],
		  config=instruct['CONFIG'],in_sex=instruct['INSEX'],
		  use_direct=instruct['UDIRIM'],
		  dir_hdu='', spec_hdu='', out_sex='')
    iraf.gol2af(grism=instruct['GRISM'], config=str(instruct['CONFIG']),
		 dmag=instruct['DMAG'],mfwhm=instruct['FWHM'],
		 back='NO', exclude='NO',
		 auto_orient='YES', orient='YES', out_af='', in_gol='')
    iraf.backest(grism=instruct['GRISM'], config=str(instruct['CONFIG']),
		 mask='yes', np=0, interp=-1, in_af='', out_back='')

    conf = configfile.ConfigFile(putCONF(instruct['CONFIG']))
    scinum = get_sciextnum(instruct['GRISM'], conf)
    maskname = string.split(instruct['GRISM'],'.fits')[0] + '_' + \
	       str(scinum) + '.MSK.fits'
    return maskname
