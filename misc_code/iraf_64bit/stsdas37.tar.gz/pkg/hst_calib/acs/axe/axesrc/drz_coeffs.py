"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "June 30th 2004"
__version__ = "1.4 (June 2004)"
__credits__ = """This software was developed by the ACS group of the Space Telescope -
European Coordinating Facility (ST-ECF). The ST-ECF is a department jointly
run by the European Space Agency and the European Southern Observatory.
It is located at the ESO headquarters at Garching near Munich. The ST-ECF
staff supports the European astromical community in exploiting the research
opportunities provided by the earth-orbiting Hubble Space Telescope.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os, string
from pyraf import iraf
from pyraf.iraf import stsdas
import pyfits, pydrizzle
from axedrzutils import *
from axeprep import *
import configfile


def get_coeffs(image, extvers, scinum):
    """
    Store the distortion coefficients in the image header

    The function creates and reads in the drizzle coefficients
    to create undistorted images for the specified extension version.
    The coefficients themselves are created calling
    PyDrizzle. If the call to pydrizzle fails, configuration
    specific default coefficients are provided.
    The coefficients file is read in,
    and are call to the function 'store_coeffs'
    stores the coefficients in the header.

    @param image: the image name
    @type image: string
    @param extvers: the targeted extension version 
    @type extvers: int 
    @param scinum: axe number of the science extension version
    @type scinum: int
    """

    # get the name of the coefficients file
    cfnames, chipnum= get_coeffile_name(image, extvers)

    try:
	# create a distortion coefficient file
	pydrizzle.PyDrizzle(putIMAGE(image))
    except:

	# if this fails, create a default coefficients file
	cfnames = create_dummy_coeffs(image, chipnum)

    #------------------------------------------------------------------------
    #
    #  If the image is in the current directory,
    #  PyDrizzle creates a coefficient file following the
    #  naming convention in the next line. If the image is NOT
    #  in the current directory, it creates a coefficient file
    #  with the name '_coeffs'+ext+'.dat'. This behaviour is also
    #  there if you pint to the correct image location via the parameter.

    # check whether the 'normal' file exists
    if os.path.isfile(putIMAGE(cfnames[0])):
        # open the normal file
	cfile = file(putIMAGE(cfnames[0]), 'r')

    else:
        # check whether the truncated STSDAS 3.2 file exists
        if len(cfnames) > 1  and os.path.isfile(putIMAGE(cfnames[1])):
            
            # open the truncated file
            cfile = file(putIMAGE(cfnames[1]), 'r')

        else:
            # no file, give an error
            if len(cfnames) > 1:
                report_error(110, cfile1=putIMAGE(cfnames[0]), cfile2=putIMAGE(cfnames[1]))
            else:
                report_error(110, cfile1=putIMAGE(cfnames[0]), cfile2=putIMAGE(cfnames[0]))
                
    # read in the coefficients file,
    # close and delete it
    coeffs = cfile.readlines()
    cfile.close()

    if os.path.isfile(putIMAGE(cfnames[0])):
        os.unlink(putIMAGE(cfnames[0]))
    elif len(cfnames) > 1 and os.path.isfile(putIMAGE(cfnames[1])):
        os.unlink(putIMAGE(cfnames[1]))

    # convert the string into a float array
    xcoeffs, ycoeffs = get_coeffs_numbers(coeffs)

    # store the float arrays
    store_coeffs(image, xcoeffs, ycoeffs, scinum)

    # delete all remaining, drizzle related files
    mopup_pydrizzle(image)

def mopup_pydrizzle(image):
    """
    Delete al files created by pydrizzle

    The pydrizzle command creates  alarge amount of mask files which
    are not needed in aXe. This method deletes all these files
    
    @param image: the image name
    @type image: string
    """

    # compose the file names
    msk1name = image.replace('.fits','_final_mask1.fits')
    msk2name = image.replace('.fits','_final_mask2.fits')
    sing1name = image.replace('.fits','_single_mask1.fits')
    sing2name = image.replace('.fits','_single_mask2.fits')
    coeff1name = image.replace('.fits','_coeffs1.dat')
    coeff2name = image.replace('.fits','_coeffs2.dat')

    # check if the files exist;
    # delete them if yes
    if os.path.isfile(putIMAGE(msk1name)):
        os.unlink(putIMAGE(msk1name))
    if os.path.isfile(putIMAGE(msk2name)):
        os.unlink(putIMAGE(msk2name))
    if os.path.isfile(putIMAGE(sing1name)):
        os.unlink(putIMAGE(sing1name))
    if os.path.isfile(putIMAGE(sing2name)):
        os.unlink(putIMAGE(sing2name))
    if os.path.isfile(putIMAGE(coeff1name)):
        os.unlink(putIMAGE(coeff1name))
    if os.path.isfile(putIMAGE(coeff2name)):
        os.unlink(putIMAGE(coeff2name))

def get_coeffs_numbers(coeffs):
    """
    Extract the coefficients from the file content

    This module parses through the list of strings extracted
    from the coefficient file. The numbers for the coefficients
    are extracted from the strings and converted to two
    list of coefficients, one for x and one for y.
    These lists are returned.

    @param coeffs: the image name
    @type coeffs: [string]

    @return: lists of coefficients for x and y
    @rtype: [float], [float]
    """

    # initialize the arrays
    xcoeffs = []
    ycoeffs = []

    # parse through the content
    first = 0
    for line in coeffs:

        # neglect lines starting with a comment
	if line[0] == '#':
	    continue

        # switch from x- to y-array
        # when encountering a blank line
	elif len(string.strip(line)) == 0:
	    first = 1

        # neglect also lines starting with a string
	elif isstringlike(string.split(string.strip(line))[0]) == 1:
	    continue

        # here are the data lines
	else:

            # convert the data lines to a list
	    scoeffs = string.split(string.strip(line))

            # parse through the list
	    for number in scoeffs:

                # append the item to x
		if first == 0:
		    xcoeffs.append(float(number))

                # or append it to y
		else:
		    ycoeffs.append(float(number))

    # return the lists
    return xcoeffs, ycoeffs



def get_coeffile_name(image, extvers):
    """
    Derive the name of the coefficents file

    From the image name and various kkeywords in the image the file
    name of the coeffients file created in 'pydrizzle.PyDrizzle(...)' is
    determined.
    This is done just following the rather strange naming scheme
    followed in Pydrizzle.

    @param image: the image name
    @type image: string
    @param extvers: the targeted extension version 
    @type extvers: int 

    @return: the file name(s) of the coefficients file, the chip number
    @rtype: [string], string
    """
    # try to geth the keyword 'CCDCHIP'
    # for ACS/WFC
    hlist = ['CCDCHIP']
    try:
        header = get_header(putIMAGE(image), 'SCI', extvers, hlist, 0)
    except KeyError:
         header = get_header(putIMAGE(image), 0, 0, hlist, 0)
         
    # check whether this keyword exists
    if header == None:

        # check for the keyword 'CAMERA'
        # for NICMOS
        hlist = ['CAMERA']
        header = get_header(putIMAGE(image), 0, 0, hlist, 0)

        # check whether the keyword exists
        if header == None:

            # if it does NOT exist, give the default chip number
            # for ACS/HRC and ACS/SBC
            chipnum = 1

        else:
            # set the chip number
            # for NICMOS
            chipnum = header['CAMERA']

    else:
        # set the chip number
        # for ACS/WFC
        chipnum = header['CCDCHIP']

    # compose the name of the coefficients file
    cfname1 = image.replace('.fits','_coeffs'+str(chipnum)+'.dat')

    # this is the alternative, STSDAS 3.2 name
    cfname2 = '_coeffs'+str(chipnum)+'.dat'

    # return the coeffcicients file
    return [cfname1, cfname2], str(chipnum)


def get_coeffile_dname():
    """
    Gives the default name for coefficients file

    This module is just a container for the defaul file
    name of the coefficients file where the drizzle
    coefficients are stored if the Pydrizzle() does NOT run.

    @return: the default coefficients file name
    @rtype: string
    """
    
    # this is the name for the
    # default coefficients file
    return 'default_coeffs.dat'


def create_dummy_coeffs(image, chipnum):
    """
    Creates the correct default coefficient file

    The module determines the instrument setup from the
    header keywords in the image. The right set of
    default coefficients is retrieved for the given
    instrumental setup, and these coefficents are stored
    inder a default filename.

    @param image: the image name
    @type image: string
    @param chipnum: the relevant chip number
    @type chipnum: string

    @return: the default coefficients file name
    @rtype: [string]
    """

    # get the instrumental setup
    instument, detector, disperser = get_spect_setup(image)

    # get the default coefficients
    default_coeffs = get_default_coeffs(instument, detector, disperser, chipnum)

    # get the default coefficient
    # name and destroy any existing
    # file with this name
    cfname = get_coeffile_dname()
    if os.path.isfile(cfname):
        os.unlink(cfname)

    # create, fill and close the
    # default coefficients file 
    cfile = open(putIMAGE(cfname), 'w+')
    cfile.write(default_coeffs)
    cfile.close()

    # return the coefficients name
    return [cfname]


def get_default_coeffs(instrument, detector, disperser, chipnum):
    """
    Defines and returns the default coefficients

    The module stores and returns the default distortion parameters for
    all ACS grism plus the NICMOS grism.
    The various combinations of instruments and grisms and chips make
    the selection rather awkward looking.

    @param instrument: the instrument name (ACS/NICMOS)
    @type instrument: string
    @param detector: the detector name (HRC/WFC/...)
    @type detector: string
    @param disperser: the disperser name (G800L/PR200L/...)
    @type disperser: string
    @param chipnum: the relevant chip number
    @type chipnum: string

    @return: the default coefficients
    @rtype: [string]
    """
  
    # the ACS/WFC branch
    if instrument == 'ACS' and detector == 'WFC':

        # select the detector
        if chipnum == '1':
            default_coeffs = """# ACS WFC/G800L chip 1 polynomial distortion coefficients
# Created for the data set j8qq10ikq_flt.fits using the IDCTAB q2h2010pj_idc.fits
quartic
     29.20952271       0.98463856      0.047121902    8.2405479e-06   -7.1109122e-06 
   1.7714826e-06   -4.6293307e-10    -1.243901e-10   -5.3285875e-10    5.1490811e-11 
   1.6734254e-14     3.425828e-14    9.5688062e-14   -1.6229259e-14    1.2711148e-13 

   1047.90670925      0.040785422       0.97161774   -2.5332551e-06    5.9183197e-06 
  -9.4306843e-06    7.3674246e-11   -4.3916951e-10    -5.371583e-11   -3.8747876e-10 
  -1.4892746e-14   -3.1028203e-14    -1.024679e-13    2.9690206e-14   -1.4559746e-13 
  """
        elif chipnum == '2':
            default_coeffs = """# ACS WFC/G800L chip 2 polynomial distortion coefficients
# Created for the data set j8qq10ikq_flt.fits using the IDCTAB q2h2010pj_idc.fits
quartic
    -60.03089477       0.99670914      0.041081449    8.4488359e-06   -4.9053436e-06 
   1.8548877e-06   -4.6793614e-10   -6.5382805e-11   -5.2464617e-10   -7.2436454e-12 
   2.2345506e-14    2.4896891e-16    3.6249087e-14   -2.3305606e-14    1.2703869e-14 

  -1029.88229222      0.027935398        1.0054611   -1.5024368e-06    6.0757868e-06 
  -7.2000302e-06    7.5714168e-11   -5.1072041e-10   -8.2177665e-11   -4.0937009e-10 
  -1.8200403e-14   -3.1767736e-15   -3.6857861e-14    1.2036951e-14   -9.5179518e-15 
  """

    # the ACS/HRC plus G800L branch
    elif instrument == 'ACS' and detector == 'HRC' and disperser == 'G800L':

        default_coeffs = """# ACS HRC/G800L polynomial distortion coefficients
# created for the image j8m820leq_flt.fits using IDCTAB n7o1634cj_idc.fits
quartic
      1.99990688        1.1312952    -0.0013998074   -3.7547287e-06    1.0207302e-05
  -8.1810015e-07    1.0776155e-10   -3.5401801e-11    4.6434155e-10    -2.226957e-11 
   3.6592701e-13   -2.5148205e-12   -1.5241192e-12   -2.0761802e-13    4.1691635e-14 

     -2.82194592       0.11656498       0.99377446    1.6018684e-06   -1.6023185e-06 
   1.1354663e-05    4.5674659e-10    2.9705672e-10   -5.8000163e-10    7.2709968e-10 
   3.0293949e-13   -1.5578453e-12    8.3043208e-13   -5.5750209e-13   -1.2661919e-12 
   """

    # the ACS/HRC plus PR200L  branch
    elif instrument == 'ACS' and detector == 'HRC' and disperser == 'PR200L':
        default_coeffs = """# ACS HRC/PR200L polynomial distortion coefficients
# Created for the data set j97b06sdq_flt.fits using the IDCTAB p5b1731aj_idc.fits
quartic
      2.08138254        1.1315262    -0.0015648471   -3.7322242e-06    1.0109418e-05
  -8.1409948e-07    1.3075234e-10    2.3539512e-11    4.3735033e-10   -1.0632533e-11 
   2.7818193e-13   -2.0905397e-12   -1.6363199e-12    1.4459954e-13    4.6694459e-14 

     -2.81487211       0.11637744       0.99369911    1.5666096e-06   -1.5948952e-06 
   1.1298673e-05    4.5586465e-10     3.300937e-10   -6.4272644e-10    4.9637125e-10 
   4.1921892e-13   -1.6327524e-12    8.2560585e-13   -5.5250041e-13   -1.0909078e-12 
   """

    
    # the ACS/SBC plus PR110L  branch
    elif instrument == 'ACS' and detector == 'SBC' and disperser == 'PR110L':
        default_coeffs = """# ACS SBC/PR110L polynomial distortion coefficients
# Created for the data set j97b11slq_flt.fits using IDCTAB o8u11395j_idc.fits
quartic
      1.04924098        1.3453513      0.020481231    -1.844869e-05    1.6256479e-05 
   5.8220551e-06    4.0145121e-09    2.3509428e-09   -5.7698408e-09   -7.6725898e-09 
   1.4285034e-11    1.6199441e-12    2.1826236e-12   -7.9748938e-12   -3.9227931e-11 

     -4.29830391       0.10788573        1.2035841   -1.4603854e-06     2.437245e-06 
   1.2681371e-05    1.5990346e-09   -8.8217959e-09   -1.0642736e-09    1.6438327e-09 
   3.5539949e-12   -9.4676107e-13    1.8894413e-12    8.9042909e-12   -2.9544276e-12 
   """
        
    # the ACS/SBC plus PR130L  branch
    elif instrument == 'ACS' and detector == 'SBC' and disperser == 'PR130L':
        default_coeffs = """# ACS SBC/PR130L polynomial distortion coefficients
# Created for the data set j97b11smq_flt.fits using IDCTAB o8u11395j_idc.fits
quartic
      1.04923371        1.3453499      0.020481207   -1.8448652e-05    1.6256445e-05 
    5.822046e-06    4.0144937e-09    2.3509343e-09   -5.7698199e-09   -7.6725457e-09 
   1.4284973e-11    1.6199372e-12    2.1826142e-12   -7.9748596e-12   -3.9227763e-11 

     -4.29829370       0.10788562        1.2035828   -1.4603816e-06    2.4372417e-06 
   1.2681344e-05    1.5990282e-09   -8.8217677e-09   -1.0642737e-09     1.643828e-09 
   3.5539797e-12   -9.4675702e-13    1.8894332e-12    8.9042528e-12    -2.954415e-12 
   """

    # the NICMOS plus G141 branch
    elif instrument == 'NICMOS' and disperser == 'G141':
        default_coeffs = """# ACS polynomial distortion coefficients
# taken from the stored STSDAS coefficients
cubic
      0.00000000        1.0018288                0      8.03467e-06      1.32241e-05
     5.83064e-06                0                0                0                0

      0.00000000     -0.000893359       0.99816635     -1.80668e-05        5.989e-07
    -1.15787e-05                0                0                0                0
        """

    # the default, which gives the identity matrix
    else:

        default_coeffs = """# Dummy polynomial distortion coefficients
# file, created bz aXe 
cubic
  0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0 

  0.0  0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0
  """

    return default_coeffs


def get_spect_setup(image):
    """
    Get the instrumental setup
    
    @param image: the image name
    @type image: string

    @return: setuo information
    @rtype: string, string , string
    """
    
    # get the typical ACS keywords
    hlist = ['INSTRUME', 'DETECTOR', 'FILTER1', 'FILTER2']
    header = get_header(putIMAGE(image), 0, 0, hlist, 0)

    # check whether the keywords exist
    if not header:

        # get the typical NICMOS keywords
        hlist = ['INSTRUME', 'FILTER']
        header = get_header(putIMAGE(image), 0, 0, hlist, 0)

        # check for success
        if header:

            # store the values
            instrument = header['INSTRUME']
            detector   = None
            disperser  = header['FILTER']

        else:

            # store the defaults
            instrument = None
            detector   = None
            disperser  = None

    # here all ACS keywords were found
    else:

        # store one value
        instrument = header['INSTRUME']
        detector   = header['DETECTOR']

        # identify the disperser
        # from ACS WFC/HRC/SBC keywords

        
        # this is for the HRC/WFC
        if   string.find(header['FILTER1'], 'CLEAR') > -1:
            disperser  = header['FILTER2']

        elif string.find(header['FILTER2'], 'CLEAR') > -1:
            disperser  = header['FILTER1']

        # this is for the SBC
        elif string.find(header['FILTER1'], 'N/A') > -1:
            disperser  = header['FILTER2']

        elif string.find(header['FILTER2'], 'N/A') > -1:
            disperser  = header['FILTER1']

        else:
            # this is the default
            disperser = None

    # return the instrument and the disperser
    return instrument, detector, disperser
