"""
A class to load and handle Sextractor ascii tables into python
arrays and to deliver table values bye corresponding methods.
As an input the usual ascii format of sextractor tables are assumed.
That is ans ascii fiel with column information in the header,
indicated by '#' as the first digit, followed by the content
of the table, grouped by the rows.
"""
"""
For when the One Great Scorer comes
to mark against your name,
He writes --not that you won or lost--
but how you played the Game.

Grantland Rice
"""
__author__ = "Martin Kuemmel <mkuemmel@eso.org>"
__date__ = "12 January 2004"
__version__ = "1.0 (Jan 12, 2004)"
__credits__ = """
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

import string

class ColHead:
    def __init__(self, oneline):
	"""
	Input:
	    oneline - a line from the header of a sextractor
	              catalog
	Return:
	    -

	Description:
	    The input line is passed to internal methods.
	    In those methods the relevant information is
	    extracted from the line and put into
	    the internal data fields.
	"""
	self.colinfo = {}
	self.colinfo['nr']          = self.setnr(oneline)
	self.colinfo['name']        = self.setname(oneline)
	self.colinfo['unit']        = self.setunit(oneline)
	self.colinfo['description'] = self.setdesc(oneline)
	
    def setnr(self, oneline):
	"""
	Input:
	    oneline - a header line

	Return:
	    value - the column number

	Description:
	    The input line is split up at blanks.
	    The element corresponding to the column number
	    is returned.
	"""
	value = int(string.split(oneline)[1])
	return value

    def setname(self, oneline):
	"""
	Input:
	    oneline - a header line

	Return:
	    value - the column name

	Description:
	    The input line is split up at blanks.
	    The element corresponding to the column name
	    is returned.
	"""
	value = string.split(oneline)[2]

	return value

    def setunit(self, oneline):
	"""
	Input:
	    oneline - a header line

	Return:
	    value - the column unit

	Description:
	    The input line is split up at blanks.
	    The element corresponding to the column unit
	    is returned.
	"""
	nitem = len(string.split((oneline)))
	value = string.split(oneline)[nitem-1]
	return value

    def setdesc(self, oneline):
	"""
	Input:
	    oneline - a header line

	Return:
	    value - the column description

	Description:
	    The input line is split up at blanks.
	    The element corresponding to the column description
	    is returned.
	"""
	nitem = len(string.split((oneline)))
	if nitem > 3:
	    for index in range(3, nitem):
		if index == 3:
		    value = string.split(oneline)[index]
		else:
		    value = value + " " + string.split(oneline)[index]
	else:
	    value = 'No desctription'

	return value

    def getnr(self):
	"""
	Input:
	    -

	Return
	    the column number

	Description:
	    Returns the column number to the calling
	    module
	"""
	return self.colinfo['nr']

    def getname(self):
	"""
	Input:
	    -

	Return
	    the column name

	Description:
	    Returns the column name to the calling
	    module
	"""
	return self.colinfo['name']

    def getunit(self):
	"""
	Input:
	    -

	Return
	    the column unit

	Description:
	    Returns the column unit to the calling
	    module
	"""
	return self.colinfo['unit']

    def getdesc(self):
	"""
	Input:
	    -

	Return
	    the column descritption

	Description:
	    Returns the column description to the calling
	    module
	"""
	return self.colinfo['description']

class TabCol:
    def __init__(self, colhead, data):
	"""
	Input:
            colhead - the column header
	    data    - the column data
	"""
	self.colhead = colhead
	self.entry   = data

    def printcol(self):
	"""
	Input:
	    -

	Return:
	    -

	Description:
	    Prints the column name followed
	    by the data in the column onto the screen
	"""
	print self.colhead.getname()
	for oneentry in self.entry:
	    print oneentry

    def getentry(self, index):
	"""
	Input:
	    index - the row index

        Return:
	    the requested row entry

	Description:
	    Delivers a column entry to the
	    calling module.
	"""
	return self.entry[index]

    def setentry(self, index, value):
	"""
	Input:
	    index - the row index
	    value - the value

        Return:
	    0/1 in case of success/faileaure

	Description:
            Sets the entry in row 'index' of 'self.entry'
            to 'value'. Returns '1' in case that the
            entry is longer than the list 'self.entry'
            and '0' in case of success.
	"""
        if index > len(self.entry):
            return 1
        else:
            self.entry[index] = value

	return 0

    def getname(self):
	"""
	Input:
	    -

	Return:
	    the column name

	Description:
	  Delivers the column name back to the
	  calling codule.
	"""
	return self.colhead.getname()

class AXeCat:
    def __init__(self, filename):
        linelist    = self.opencat(filename)
	self.headerlines = self.extractheader(linelist)
	rowlines    = self.extractrows(linelist)
	allheads    = self.makeheads(self.headerlines)
	self.ncols  = len(allheads)
	self.nrows  = self.makecols(allheads, rowlines)
	success     = self.makeorder()
    def opencat(self, filename):
	"""
	Input:
	    filename - the name of the sextractor ascii catalog

	Return:
     	    linelist - a list wit all lines of the sextractor
	               catalog

	Description:
	    Opens the file and stores all the lines in a list.
	    
	"""
	listfile = open(filename,'r')
	linelist = listfile.readlines()

	return linelist
	

    def extractheader(self, linelist):
	"""
	Input:
	    linelist - all lines of a sextractor catalog

	Return:
	    headerlines - the lines which contain header
	                  information

	Description:
	    Extracts the header lines from the list of lines
	    Header lines have a '#' as the first digits and are
	    longer than two characters. This allows for small
	    cosmetical changes to the original Sextractor tables
	"""
	headerlines = []
	for index in range(len(linelist)):
	    oneline = linelist[index]
	    if (oneline[0] == "#") and (len(oneline)) > 2:
		headerlines.append(oneline)

	return headerlines

    def extractrows(self, linelist):
	"""
	Input:
	    linelist - all lines of a sextractor catalog
	
	Return:
	    rowlines - the content lines of a sextractor
	               catalog

	Description:
	    Extracts the content lines from the list of lines.
	    Content lines have a all lines except the ones which start with a 
	    '#' and are longer than one character. This allows for
	    e.g. whitespaces as the last 'rows', which often remain 
	    after editing an ascii-file
	
	"""
	rowlines = []
	for index in range(len(linelist)):
	    oneline = linelist[index]
	    if oneline[0] != "#" and len(oneline) > 1:
		rowlines.append(oneline)

	return rowlines

    def makeheads(self, headerlines):
	"""
	Input:
	    headerlines - the lines with the header information
	                  of the sextractor catalog

	Return:
	    allheads - a list with all column header derived
	               from the headerlines

	Description:
	    Creates the column-headers by calling a corresponding method
	    of the Columnheader class with the header lines as input.
	"""
	allheads = []
	for index in range(len(headerlines)):
	    oneline = headerlines[index]
	    onehead = ColHead(oneline)
	    allheads.append(onehead)

	return allheads

    def makecols(self, allheads, rowlines):
	"""
	Input:
	    allheads - the list with column headers
	    rowlines - the list with content lines

	Return:
	    len(rowlines) - the number of rows in the table

	Description:
	    Creates the columns by creating instances of the TableColumn class
	    The inputs are the column headers created before and the
	    corresponding column data as extracted from the content lines.
	"""
	self.columns = []
	for hindex in range(len(allheads)):
	    data = []
	    for onerow in rowlines:
		data.append(string.split(onerow)[hindex])
	    onecol = TabCol(allheads[hindex], data)
	    self.columns.append(onecol)
	    del(data)

	return len(rowlines)


    def makeorder(self):
	"""
	Input:
	    -

	Return:
	   0 - a dummy value

	Description:
	    The method fills the sortcolumn with the default
	    order, which is the normal index of the
	    row. This assures that you get inputorder
	    directly after creating the object even if
	    you call the sorted access.
            Moreover the selectcolumn is initiated and filled
            with '0'.
	"""
	self.sortcol = []
	self.selectcol = []
	for index in range(self.nrows):
	    self.sortcol.append(index)
	    self.selectcol.append(0)

	return 0


    def deselect_all(self):
	"""
	Input:
	    -

	Return:
	    -

	Description:
	    Deselects all entries, that means the value in the
	    selection-row is set to '0'. This is an important
	    function in case that a cataloge is exploited
	    several times using different selections
	    of entries.
	"""
	for index in range(self.nrows):
	    self.selectcol[index] = 0
	
    def setselection(self, rownum):
	"""
	Input:
	    rownum - the row number to set to selected

	Return:
	    0/1 in case of ok/error

	Description:
            One row is set to selected by making the according
            entry in 'self.selectcol' to '1'. In case
            that the requested row does not exist the method
            returns '1'.

	"""
        if rownum > self.nrows:
            return 1
        else:
            self.selectcol[rownum] = 1
#	    print 'Selected row: ', rownum

        return 0

	

    def setorder(self, colname, direction):
	"""
	Input:
	   colname   - the name of the column which gives
	               the values along which is sorted

	   direction - an indication on the sorting order
	               '0' means ascending, everything else
		       means descending order
	Return:
	    rval - '0' if everything is ok, '1' if the
	           column could not be found

	Description:
	    Identifies the column according to which the
	    catalog should be ordered. Then the list
	    'sortcol' is filled with the index of each
	    row at the corresponding ordered position.
	    That means the first entry in 'sortcol'
	    is the index of the first sorted entry
	    in the catalog, the second entry is the index
	    of the second ordered entry in the catalog and
	    so on.
	    In the end the ordered ro indices are stored
	    in the column 'sortrow'. This allows the
	    access to sorted values without reordering
	    the whole content of the table.
	"""
	tmplist = []
	reflist = []
	colnum = self.searchcol(colname)

	if colnum != -1:
	    for index in range(self.nrows):
		tmplist.append(float(self.getval(colnum, index)))
		reflist.append(float(self.getval(colnum, index)))
	    if direction == 0:
		tmplist.sort()
	    else:
		tmplist.sort()
		tmplist.reverse()
	    for index in range(self.nrows):
		self.sortcol[index] = reflist.index(tmplist[index])
		reflist[self.sortcol[index]] = None
	    rval = 0
	else:
	    rval = 1

	return rval


    def getcol(self, colnum):
	"""
	Input:
	    colnum - the column number

	Return:
	    self.columns[colnum].entry - the column entries

	Description:
	    Delivers the data of a columnn.Simply dumps out
	    the content of the requested column.
	"""

	return self.columns[colnum].entry


    def getrow(self, rownum):
	"""
	Input:
	    rownum - the number of the requested row

	Return:
	    data - the data of the requested row
	        
	Description:
	    Delivers the data of a row. Extracts the data from
	    all columns for the requested row and gives it back
	    as a list.
	"""
	data = []
	for onecol in self.columns:
	    data.append(onecol.getentry(rownum))

	return data


    def setval(self, colnum, rownum, value):
	"""
	Input:
	    colnum - the column number
	    rownum - row number
            value  - the value to be set

 	Return:
            0/1 in case of succes/error

	Description:
            Sets the value in column number 'colnum', row number
            'rownum' to 'value'. In case that the 'rownum' is larger
            than the number of rows in that column, '1' is returned.
            If everything is OK '0' is returned.
	"""
	success = self.columns[colnum].setentry(rownum, value)

	return success

    def getval(self, colnum, rownum):
	"""
	Input:
	    colnum - the column number
	    rownum - row number

 	Return:
	    data[rownum] - the data at the col/row combination

	Description:
	    Delivers the data value in the requested column and
	    at the requested row position.
	    This method delivers unsorted values!!
	"""
	data = self.getcol(colnum)

	return data[rownum]

    def getsortedval(self, colnum, rownum):
	"""
	Input:
	    colnum - the column number
	    rownum - row number

 	Return:
	    data[rownum] - the data at the col/row combination

	Description:
	    Delivers the data value in the requested column and
	    at the requested SORTED row position.
	    This method delivers SORTED values!!
	"""
	data = self.getcol(colnum)

	return data[self.sortcol[rownum]]


    def getnrows(self):
	"""
	Input:
	    -
	
	Return:
	    self.nrows - the number of rows

	Description:
	    The method delivers the number of rows in the
	    catalog.
	"""

	return self.nrows

#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
    def getncols(self):
	"""
	Input:
	    -
	
	Return:
	    self.ncols - the number of columns

	Description:
	    The method delivers the number of columns in the
	    catalog.
	"""

	return self.ncols


    def printcol(self, colnum):
	"""
	Input:
	    colnum - the column number

	Return:
	    -

	Description:
	    Prints the content of a column to the screen.
	    This is done in 'column' format, to say each
	    entry starts with a new line.
	"""
	self.columns[colnum].printcol()


    def printselected(self):
	"""
	Input:
            -
	Return:
	    -

	Description:
            Prints the Sextractopr header plus the selected
            rows to the screen.
	"""
        for line in self.headerlines:
            print string.strip(line)
            
        for ii in range(self.nrows):
            if self.selectcol[ii] == 1:
                self.printrow(ii)

    def printselecttofile(self, filename):
	"""
	Input:
            filename - the name of the outputfile
	Return:
	    -

	Description:
            Opens the file 'filename' and write the cataloge
            header + the selected rows to that file.
	"""
	oufile      = open(filename, 'w')
        for line in self.headerlines:
            oufile.write(string.strip(line) + '\n')
            
        for ii in range(self.nrows):
            if self.selectcol[ii] == 1:
#		print 'Printing row: ', ii
                data = self.getrow(ii)
                onerow = ""
                for item in data:
                    onerow = onerow + " " + item
                oufile.write(onerow + '\n')
        oufile.close()

    def printrow(self, rownum):
	"""
	Input:
	    rownum - the row number

	Return:
	    -

	Description:
	    Prints the content of a row to the screen.
	    This is done in 'row' format, to say all
	    entries are printed in one line.
	"""
	data = self.getrow(rownum)
	onerow = ""
	for item in data:
	    onerow = onerow + " " + item

	print onerow

    def searchcol(self, colname):
	"""
	Input:
	    colname - the name of the column

	Return:
	    colnum - the column number

	Description:
	    Searches for a columns with the given name
	    and returns it number if it was found, and
	    -1 otherwise.
	"""
	colnum = -1
	for index in range(len(self.columns)):
	    if self.columns[index].getname() == colname:
		colnum = index

	return colnum


    def setaxecols(self, mag_wavelength=None):
	"""
	Input:
	    -
	Return:
	    notfound - the number of standard columns not 
	               found

	Description:
	    Searches for the column numbers of the
	    mandatory axe-columns. Stores the column numbers
	    in corresponding variables of the class instances.
	    Returns the number of columns that were not found.
	"""
	notfound = 0
	self.n_num = self.searchcol("NUMBER")
	if self.n_num == -1:
	    notfound = notfound + 1
	self.n_xim = self.searchcol("X_IMAGE")
	if self.n_xim == -1:
	    notfound = notfound + 1
	self.n_yim = self.searchcol("Y_IMAGE")
	if self.n_yim == -1:
	    notfound = notfound + 1
	self.n_aim = self.searchcol("A_IMAGE")
	if self.n_aim == -1:
	    notfound = notfound + 1
	self.n_bim = self.searchcol("B_IMAGE")
	if self.n_bim == -1:
	   self. notfound = notfound + 1
	self.n_tim = self.searchcol("THETA_IMAGE")
	if self.n_tim == -1:
	    notfound = notfound + 1
	self.n_xwo = self.searchcol("X_WORLD")
	if self.n_xwo == -1:
	    notfound = notfound + 1
	self.n_ywo = self.searchcol("Y_WORLD")
	if self.n_ywo == -1:
	    notfound = notfound + 1
	self.n_awo = self.searchcol("A_WORLD")
	if self.n_awo == -1:
	    notfound = notfound + 1
	self.n_bwo = self.searchcol("B_WORLD")
	if self.n_bwo == -1:
	    notfound = notfound + 1
	self.n_two = self.searchcol("THETA_WORLD")
	if self.n_two == -1:
	    notfound = notfound + 1
	# check for the MAG_AUTO-column 
	self.n_mau = self.searchcol("MAG_AUTO")
	if self.n_mau == -1:
	    # if MAG_AUTO does not exist, search for 
	    # magnitude columns in general
	    mag_cols = self.search_mcols()

	    # if magnitude columns exist,
	    # search the one closest to the
	    # desired wavelength
	    if len(mag_cols) > 0:

		if mag_wavelength != None:
		    mag_index = self.find_magcol(mag_cols, mag_wavelength)
		else:
		    mag_index=0
		# set the column number and the wavelength
		self.n_mau   = mag_cols[mag_index][0]
		self.magwave = mag_cols[mag_index][1]
	    else:
		# enhance the error counter
		notfound = notfound + 1
	else:
	    self.magwave = 0


	return notfound
    def find_magcol(self, mag_cols, mag_wave):
	"""
	Input:
	    mag_cols - the list with infos on magnitude columns
	    mag_wave - the target wavelength

	Return:
	    min_ind - the index of the closes column within mag-cols

	Description:
	    The method analyses all magnitude columns and finds the one
	    which is closest to a wavelength given in the input.
	    The index of the closest wavelength in the input
	    list is returned.
	"""
	import math
	
	# define a incredible large difference
	min_dist = 1.0e+30

	# define a non-result
	min_ind  = -1

	# go over al magnitude columns
	for index in range(len(mag_cols)):
	    # check wehether a new minimum distance is achieved
	    if math.fabs(mag_cols[index][1]-mag_wave) < min_dist:
		# transport the minimum and the index
		min_ind  = index
		min_dist = math.fabs(mag_cols[index][1]-mag_wave)

	# return the index
	return min_ind

    def search_mcols(self):
	"""
	Input:
	    -

	Return:
	    mag_cols - a list with tuples

	Description:
	    The method collects all magnitude columns
	    with an encoded wavelength in the column name.
	    For each such column the column index and the 
	    wavelength is stored in a list, and the list
	    of all columns is returned.
	"""

	# initialize the list with the result
	mag_cols = []
	
	# go over all columns
	for index in range(self.getncols()):

	    # get the column name
	    colname = self.columns[index].getname()

	    # try to decode the wavelength
	    wave = self.get_wavelength(colname)

	    # if a wavelength is encoded
	    if wave:
		# compose and append the info
		# to the resulting list
		mag_cols.append([index, wave])

	# return the result
	return mag_cols

    def get_wavelength(self, colname):
	"""
	Input:
	    colname - the column name

	Return:
	    wave - the wavelength encoded in the
	            column name, or 0

	Description:
	    The method tries to extract the wavelength
	    encoded into a column name. The encoding
	    format is "MAG_<C><WAVE>*" with <C> a
	    single character, <WAVE> an integer number
	    and anything (*) afterwards.
	    in case that there is not wavelength encoded,
	    the value 0 id given back.
	"""
	# set the value for 'nothing found'
	wave = 0
	
	# check for the start string
	if colname.find('MAG_') == 0:

	    # copy the rest to a substring
	    rest_name = colname.split('MAG_')[1][1:]
	
	    # prepare to analyse the whole substring
	    for index in range(len(rest_name)):
		
		# make a progressively longer
		# substring, starting from the beginning
		cand_name = rest_name[0:index+1]

		# try to convert the substirng to
		# and integer, set a new wavelength
		# if it is possible
		try:
		    wave = int(cand_name)
		# as soon as the substirng can NOT
		# be transferred to an int
		# return the current, best wavelength
		except ValueError:
		    return wave

	# return the best result
	return wave


    def getaxedata(self, nrow):
	"""
	Input:
	    nrow - the row number

	Return:
	    axeinfo - a dictionary with the aXespecific entries
	              of a row.
	Description:
	    Extracs the axe-specific data of a row and stores
	    the values in a dictionary. That dictionary
	    is returned.
	"""
	axeinfo = {}
	axeinfo['NUMBER']      = int(self.getval(self.n_num, nrow))
	axeinfo['X_IMAGE']     = float(self.getval(self.n_xim, nrow))
	axeinfo['Y_IMAGE']     = float(self.getval(self.n_yim, nrow))
	axeinfo['X_WORLD']     = float(self.getval(self.n_xwo, nrow))
	axeinfo['Y_WORLD']     = float(self.getval(self.n_ywo, nrow))
	axeinfo['A_IMAGE']     = float(self.getval(self.n_aim, nrow))
	axeinfo['B_IMAGE']     = float(self.getval(self.n_bim, nrow))
	axeinfo['A_WORLD']     = float(self.getval(self.n_awo, nrow))
	axeinfo['B_WORLD']     = float(self.getval(self.n_bwo, nrow))
	axeinfo['THETA_IMAGE'] = float(self.getval(self.n_tim, nrow))
	axeinfo['THETA_WORLD'] = float(self.getval(self.n_two, nrow))
#	axeinfo['MAG_AUTO']    = float(self.getval(self.n_mau, nrow))

	return axeinfo

    def getaxesortdata(self, nrow):
	"""
	Input:
	    nrow - the row number

	Return:
	    axeinfo - a dictionary with the aXespecific entries
	              of a row.
	Description:
	    Extracs the axe-specific data of a SORTED row and stores
	    the values in a dictionary. That dictionary
	    is returned.
	"""
	axeinfo = {}
	axeinfo['NUMBER']      = int(self.getsortedval(self.n_num, nrow))
	axeinfo['X_IMAGE']     = float(self.getsortedval(self.n_xim, nrow))
	axeinfo['Y_IMAGE']     = float(self.getsortedval(self.n_yim, nrow))
	axeinfo['X_WORLD']     = float(self.getsortedval(self.n_xwo, nrow))
	axeinfo['Y_WORLD']     = float(self.getsortedval(self.n_ywo, nrow))
	axeinfo['A_IMAGE']     = float(self.getsortedval(self.n_aim, nrow))
	axeinfo['B_IMAGE']     = float(self.getsortedval(self.n_bim, nrow))
	axeinfo['A_WORLD']     = float(self.getsortedval(self.n_awo, nrow))
	axeinfo['B_WORLD']     = float(self.getsortedval(self.n_bwo, nrow))
	axeinfo['THETA_IMAGE'] = float(self.getsortedval(self.n_tim, nrow))
	axeinfo['THETA_WORLD'] = float(self.getsortedval(self.n_two, nrow))
	axeinfo['MAG_AUTO']    = float(self.getsortedval(self.n_mau, nrow))

	return axeinfo
