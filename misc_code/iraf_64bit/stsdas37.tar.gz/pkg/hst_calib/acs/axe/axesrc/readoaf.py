import string

#------------------------------------------------------------------------------
#
# Start of the file 'read_OAF.py'
#
class OneBeam:
    def __init__(self,id):
        self.id = id
        self.refpix  = [0.0,0.0]
        self.corners = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
        self.curve   = [0,0.0,0.0]
        self.width   = 0.0
        self.orient  = 0.0
        self.ignore  = 0
	self.alldata = {}

#-----------------------------------------------------------------------------
#
    def fillData(self,beam_data):
	self.alldata = beam_data
        if beam_data.has_key('refpix'):
            self.refpix = beam_data['refpix']
        else:
            return 1
        if beam_data.has_key('corners'):
            self.corners = beam_data['corners']
        else:
            return 1
        if beam_data.has_key('curve'):
            self.curve = beam_data['curve']
        else:
            return 1
        if beam_data.has_key('width'):
            self.width = beam_data['width']
        else:
            return 1
        if beam_data.has_key('orient'):
            self.orient = beam_data['orient']
        else:
            return 1
        if beam_data.has_key('ignore'):
            self.ignore = beam_data['ignore']
        else:
            return 1
        return 0

#------------------------------------------------------------------------------
#
    def printData(self):
        print self.refpix
        print self.corners
        print self.curve
        print self.width
        print self.orient
        print self.ignore

#------------------------------------------------------------------------------
#
    def getAllData(self):
        return self.alldata

#------------------------------------------------------------------------------
#
    def getRefpix(self):
        return self.refpix

#------------------------------------------------------------------------------
#
    def getCorners(self):
        return self.corners

#------------------------------------------------------------------------------
#
    def getWidth(self):
        return self.width

#------------------------------------------------------------------------------
#
    def getOrient(self):
        return self.orient

#------------------------------------------------------------------------------
#
    def getCurve(self):
        return self.curve

#-----------------------------------------------------------------------------
#
    def getIgnore(self):
        return self.ignore
        
class AnAperture:
    def __init__(self,nr):
        self.id = nr
	self.beamids = []
        self.beams = {}

#----------------------------------------------------------------------------
    def add_beam(self,beam):
        self.beams[beam.id] = beam
	self.beamids.append(beam.id)

#----------------------------------------------------------------------------
#
    def get_beam(self,id):
        if self.beams.has_key(id):
            return self.beams[id]
        else:
            return None

#----------------------------------------------------------------------------
#
    def print_beamids(self):
	for item in self.beamids:
	    angle = self.beams[item].orient+45.0
	    print 'Aperture: ', self.id, 'Beam: ', self.beams[item].id, angle

#----------------------------------------------------------------------------
#
def make_beam(beam_buffer):
    beam_data = {}
    for line in beam_buffer:
        if string.find(line, 'BEAM') > -1:
            one_beam = OneBeam(string.strip(string.split(line)[1]))
        elif string.find(line, 'REFPIXEL') > -1:
            beam_data['refpix'] = [float(string.split(line)[1]),float(string.split(line)[2])]
        elif string.find(line, 'CORNERS') > -1:
            beam_data['corners'] = [float(string.split(line)[1]),float(string.split(line)[2]),\
                                    float(string.split(line)[3]),float(string.split(line)[4]),\
                                    float(string.split(line)[5]),float(string.split(line)[6]),\
                                    float(string.split(line)[7]),float(string.split(line)[8])]
        elif string.find(line, 'CURVE') > -1:
            beam_data['curve'] = [float(string.split(line)[1]),float(string.split(line)[2]),\
                                  float(string.split(line)[3])]
        elif string.find(line, 'WIDTH') > -1:
            beam_data['width'] = float(string.split(line)[1])
        elif string.find(line, 'ORIENT') > -1:
            beam_data['orient'] = float(string.split(line)[1])
        elif string.find(line, 'IGNORE') > -1:
            beam_data['ignore'] = float(string.split(line)[1])
    success = one_beam.fillData(beam_data)
    
    return one_beam

#-------------------------------------------------------------------------
#
def make_aper(aper_buffer):
    beam_buffer = []
    for line in aper_buffer:
        if string.find(line, 'APERTURE') > -1:
            one_AP = AnAperture(int(string.strip(string.split(line)[1])))
        elif string.find(line, 'BEAM END') < 0:
            beam_buffer.append(line)
        else:
            one_BEAM = make_beam(beam_buffer)
            one_AP.add_beam(one_BEAM)
            del(beam_buffer)
            beam_buffer = []           
    return one_AP

#-------------------------------------------------------------------------
def read_OAF(oaf_name):
    all_AP = {}
    aper_buffer = []
    for line in open(oaf_name, 'r'):
	if string.find(line,';') > -1:
	    line2 = string.strip(string.split(line,';')[0])
	else:
	    line2 = string.strip(line)
        if string.find(line2, 'APERTURE END') < 0:
            aper_buffer.append(string.strip(line2))
        else:
            one_AP = make_aper(aper_buffer)
            all_AP[one_AP.id] = one_AP
            del(aper_buffer)
            aper_buffer = []
    return all_AP
#
# End of the file 'read_OAF.py'
#
#------------------------------------------------------------------------------
