import iraf
import os
from os import path

no = iraf.no
yes = iraf.yes

#import axesrc
from axe import axesrc

# Point to default parameter file for task
_parfile = 'axe$axecore.par'
_taskname = 'axecore'

######
# Set up Python IRAF interface here
######
def axecore_iraf(datafile,
		 confterm,
		 back,
		 extrfwhm,
		 drzfwhm,
		 backfwhm,
		 orient,
		 auto_orient,
		 exclude,
		 lambda_mark,
		 cont_model,
		 model_scale,
		 inter_type,
		 lamdbda_psf,
		 np,
		 interp,
		 niter_med,
		 niter_fit,
		 kappa,
                 smooth_length,
                 smooth_fwhm,
		 spectr,
		 weights,
		 sampling):
    if datafile==''  :    datafile = None
    if confterm==''  :    confterm = None
    if extrfwhm==''  :    extrfwhm=0.0
    if extrfwhm==None:    extrfwhm=0.0
    if drzfwhm ==''  :    drzfwhm=0.0
    if drzfwhm ==None:    drzfwhm=0.0
    if backfwhm==''  :    backfwhm=0.0
    if backfwhm==None:    backfwhm=0.0
    if np      ==''  :    np=0
    if np     == None:    np=0
    if interp  ==''  :    interp=0
    if niter_fit == None: niter_fit=0
    if niter_med == None: niter_med=0
    if kappa == None:     kappa=0.0
    if smooth_length==None: smooth_length=0
    if smooth_length=='': smooth_length=0
    if smooth_fwhm == None: smoot_fwhm=0.0
    if smooth_fwhm == '': smoot_fwhm=0.0

    # pre-sets for the release version:
    fconfterm = ''
    ip_corr   = 'NO'
    nl_corr   = 'NO'
    max_ext   = 0.0
    
    # check for minimal input
    if datafile == None or confterm == None:
	# print the help
	iraf.help(_taskname)
    else:
	# run the main code
	axesrc.run_axecore(datafile,
			   confterm,
			   fconfterm,
			   back,
			   extrfwhm,
			   drzfwhm,
			   backfwhm,
			   lambda_mark,
			   auto_orient,
			   orient,
			   exclude,
			   cont_model,
			   model_scale,
			   inter_type,
			   lamdbda_psf,
			   np,
			   interp,
			   niter_med,
			   niter_fit,
			   kappa,
                           smooth_length,
                           smooth_fwhm,
			   spectr,
			   weights,
			   sampling,
                           ip_corr,
                           nl_corr,
                           max_ext)
 

parfile = iraf.osfn(_parfile)
multid = iraf.IrafTaskFactory(taskname=_taskname, value=parfile,
	pkgname=PkgName, pkgbinary=PkgBinary, function=axecore_iraf)
