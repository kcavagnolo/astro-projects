import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$gol2af.par'
_execfile = 'axebin$aXe_GOL2AF'
_taskname = 'gol2af'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def gol2af_iraf(grism,config,mfwhm=None,back=no,orient=yes,auto_orient=yes,
		exclude=no,lambda_mark=800.0,dmag=None,out_af=None,in_gol=None):

    # Transform IRAF empty parameters to Python None when expected it.
    if mfwhm == '': mfwhm = None
    if out_af  == '': out_af  = None
    if in_gol == '': in_gol = None
    
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '           
    if back == yes: opt_str = opt_str + '-bck'
    if mfwhm: opt_str = opt_str + ' -mfwhm='+str(mfwhm)
    if exclude == yes: opt_str = opt_str + ' -exclude_faint'
    if out_af: opt_str = opt_str + ' -out_AF='+out_af
    if in_gol: opt_str = opt_str + ' -in_GOL='+in_gol
    
    if auto_orient == no: 
        opt_str = opt_str + ' -auto_orient=0'        
    else:   
        opt_str = opt_str + ' -auto_orient=1'
    
    if orient == no:
	opt_str = opt_str + ' -orient=0'
    else:
	opt_str = opt_str + ' -orient=1'
	
    if dmag: opt_str = opt_str + ' -dmag='+str(dmag)
    if lambda_mark: opt_str = opt_str + ' -lambda_mark='+str(lambda_mark)

    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_grism_name+' '+_config_name + opt_str
    
    # check for minimal input
    if len(grism) > 0 and len(config) > 0:
	# run command
	#print cmd_str
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'GOL2AF: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=gol2af_iraf)
