import iraf
import os
from os import path

no = iraf.no
yes = iraf.yes

#import axesrc
from axe import axesrc

# Point to default parameter file for task
_parfile = 'axe$axedrizzle.par'
_taskname = 'axedrizzle'

######
# Set up Python IRAF interface here
######
def axedrizzle_iraf(inlist,
		    confterm,
		    infwhm,
		    outfwhm,
		    back,
		    makespc,
		    opt_extr):
    if inlist=='': inlist = None
    if confterm=='': confterm = None
    if infwhm=='': infwhm=0.0
    if outfwhm=='': outfwhm='0.0'

    # check for minimal input
    if inlist == None or confterm == None:
	# print the help
	iraf.help(_taskname)
    else:
	# run the main code
        axesrc.run_axedrizzle(inlist,
			      confterm,
			      infwhm,
			      outfwhm,
			      back,
			      makespc,
			      opt_extr)
 
parfile = iraf.osfn(_parfile)
multid = iraf.IrafTaskFactory(taskname=_taskname, value=parfile,
	pkgname=PkgName, pkgbinary=PkgBinary, function=axedrizzle_iraf)
