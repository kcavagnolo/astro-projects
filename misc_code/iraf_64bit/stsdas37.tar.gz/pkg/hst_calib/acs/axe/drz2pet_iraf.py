import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$drz2pet.par'
_execfile = 'axebin$aXe_DRZ2PET'
_taskname = 'drz2pet'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def drz2pet_iraf(inlist,config,opt_extr,back,in_af,out_pet): 

    # Transform IRAF empty parameters to Python None when expected.
    if in_af == '': in_af = None
    if out_pet == '': out_pet = None
    
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '           
    if in_af: opt_str = opt_str + ' -in_AF='+ in_af
    if out_pet: opt_str = opt_str + ' -out_PET='+ out_pet
    if back == yes: opt_str = opt_str + ' -bck'
    if opt_extr == yes: opt_str = opt_str + ' -opt_extr'
    
    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _inlist_name = iraf.osfn(inlist)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_inlist_name+' '+_config_name + opt_str

    # check for minimal input
    if len(inlist) > 0 and len(config) > 0:
	# run command
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'DRZ2PET: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=drz2pet_iraf)
