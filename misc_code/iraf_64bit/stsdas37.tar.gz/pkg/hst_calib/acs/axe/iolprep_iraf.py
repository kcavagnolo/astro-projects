import iraf
import os, string
from os import path

no = iraf.no
yes = iraf.yes

#import axesrc
from axe import axesrc

# Point to default parameter file for task
_parfile = 'axe$iolprep.par'
_taskname = 'iolprep'

######
# Set up Python IRAF interface here
######
def iolprep_iraf(mdrizzle_image,
		 input_cat,
		 dim_info):
    if string.strip(mdrizzle_image) =='': mdrizzle_image = None
    if string.strip(input_cat) =='': input_cat = None
    if string.strip(dim_info) =='': dim_info='0,0,0,0'
    
    # check for minimal input
    if mdrizzle_image == None or input_cat == None:
	# print the help
	iraf.help(_taskname)
    else:
	# run the main command
	iol_maker = axesrc.IOL_Maker(string.strip(mdrizzle_image),
				     string.strip(input_cat),
				     string.strip(dim_info))
	iol_maker.run()

parfile = iraf.osfn(_parfile)
multid = iraf.IrafTaskFactory(taskname=_taskname, value=parfile,
			      pkgname=PkgName, pkgbinary=PkgBinary,
			      function=iolprep_iraf)
