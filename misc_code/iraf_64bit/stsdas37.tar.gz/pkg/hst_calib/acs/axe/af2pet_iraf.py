import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$af2pet.par'
_execfile = 'axebin$aXe_AF2PET'
_taskname = 'af2pet'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def af2pet_iraf(grism,config,back=no,out_pet=None): 

    # Transform IRAF empty parameters to Python None when expected.
    if out_pet == '': out_pet = None
    
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '           
    if back == yes: opt_str = opt_str + '-bck'
    if out_pet: opt_str = opt_str + ' -out_PET '+ out_pet
    
    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_grism_name+' '+_config_name + opt_str

    # check whether there is enough input to start
    if len(grism) > 0 and len(config) > 0:

	# run command
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'AF2PET: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=af2pet_iraf)
