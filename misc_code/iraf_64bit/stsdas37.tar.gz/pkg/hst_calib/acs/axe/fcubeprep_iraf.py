import iraf
import os, string
from os import path

no = iraf.no
yes = iraf.yes

#import axesrc
from axe import axesrc

# Point to default parameter file for task
_parfile = 'axe$fcubeprep.par'
_taskname = 'fcubeprep'

######
# Set up Python IRAF interface here
######
def fcubeprep_iraf(grism_image,
		   segm_image,
		   filter_info,
		   AB_zero,
		   dim_info,
		   interpol):
    if string.strip(grism_image)=='':
	grism_image = None
    if string.strip(segm_image)=='':
	segm_image = None
    if string.strip(filter_info)=='':
	filter_info = None
    if AB_zero == iraf.yes:
	AB_input = 1
    else:
	AB_input = 0
    if string.strip(dim_info)=='':
	dim_info='0,0,0,0'
    
    # check for minimal input
    if grism_image == None or segm_image == None or filter_info == None:
	# print the help
	iraf.help(_taskname)
    else:
	# run the main command
	fcmaker = axesrc.FluxCube_Maker(string.strip(grism_image), 
					string.strip(segm_image), AB_input,
					string.strip(filter_info),
					string.strip(dim_info), interpol)
	fcmaker.run()
	

parfile = iraf.osfn(_parfile)
multid = iraf.IrafTaskFactory(taskname=_taskname, value=parfile,
			      pkgname=PkgName, pkgbinary=PkgBinary,
			      function=fcubeprep_iraf)
