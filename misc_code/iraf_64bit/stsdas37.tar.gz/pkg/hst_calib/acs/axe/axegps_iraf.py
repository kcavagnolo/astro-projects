import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$axegps.par'
_execfile = 'axebin$aXe_GPS'
_taskname = 'axegps'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def axegps_iraf(grism,config,beam_ref,xval,yval): 
        
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '           
    opt_str = opt_str + ' ' + beam_ref
    opt_str = opt_str + ' ' + str(xval)
    opt_str = opt_str + ' ' + str(yval)
    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_grism_name+' '+_config_name + opt_str

    # check for minimal input
    if len(grism) > 0 and len(config) > 0:
	
	# run command
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'AXEGPS: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)
	

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=axegps_iraf)
