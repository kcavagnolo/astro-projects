import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$petcont.par'
_execfile = 'axebin$aXe_PETCONT'
_taskname = 'petcont'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def petcont_iraf(grism,config,cont_model="gauss", model_scale=3.0,
                 spec_models=None, object_models=None, inter_type='linear',
                 lambda_psf=400.0, cont_map=no,in_af=None): 
    
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '
    if cont_map == yes: opt_str = opt_str + ' -cont_map'
    if in_af: opt_str = opt_str + ' -in_AF='+in_af
    if cont_model == "gauss":
	opt_str = opt_str + ' -cont_model=1'
    elif cont_model == "direct":
	opt_str = opt_str + ' -cont_model=2'
    elif cont_model == "fluxcube":
	opt_str = opt_str + ' -cont_model=3'
    elif cont_model == "geometric":
	opt_str = opt_str + ' -cont_model=4'
    if model_scale:
        opt_str = opt_str + ' -model_scale='+str(model_scale)
    if spec_models != None and len(spec_models) > 0:
        opt_str = opt_str + ' -specmodels=' + spec_models
    if object_models != None and len(object_models) > 0:
        opt_str = opt_str + ' -objectmodels=' + object_models
    if inter_type == "linear":
	opt_str = opt_str + ' -inter_type=1'
    elif inter_type == "polynomial":
	opt_str = opt_str + ' -inter_type=2'
    elif inter_type == "spline":
	opt_str = opt_str + ' -inter_type=3'
    if lambda_psf: opt_str = opt_str + ' -lambda_psf='+str(lambda_psf)

    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_grism_name+' '+_config_name + opt_str

    # check for minimal input
    if len(grism) > 0 and len(config) > 0:

	# run command
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'PETCONT: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=petcont_iraf)
