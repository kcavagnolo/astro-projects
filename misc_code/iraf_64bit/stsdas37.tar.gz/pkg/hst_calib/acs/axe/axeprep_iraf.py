import iraf
import os
from os import path

no = iraf.no
yes = iraf.yes

#import axesrc
from axe import axesrc

# Point to default parameter file for task
_parfile = 'axe$axeprep.par'
_taskname = 'axeprep'

######
# Set up Python IRAF interface here
######
def axeprep_iraf(inlist,
		 configs,
		 backgr,
		 backims,
		 mfwhm,
		 norm,
		 histogram):
    if inlist=='': inlist = None
    if configs=='': configs = None
    if backims=='': backims = None
    if mfwhm=='': mfwhm=0.0

    # check for minimal input
    if inlist == None or configs == None:
	# print the help
	iraf.help(_taskname)
    else:
	# run the command
	axesrc.run_axeprep(datafile=inlist,
			   confterm=configs,
			   backgr=backgr,    
			   backterm=backims,
			   mfwhm=mfwhm,
			   norm=norm,
			   histogram=histogram)
 

parfile = iraf.osfn(_parfile)
multid = iraf.IrafTaskFactory(taskname=_taskname, value=parfile,
	pkgname=PkgName, pkgbinary=PkgBinary, function=axeprep_iraf)
