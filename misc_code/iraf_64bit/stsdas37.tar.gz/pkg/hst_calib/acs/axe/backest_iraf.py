import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$backest.par'
_execfile = 'axebin$aXe_BE'
_taskname = 'backest'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def backest_iraf(grism,config,np=None,interp=None, niter_med=0,
		 niter_fit=0, kappa=0.0, smooth_length=0,
                 smooth_fwhm=0.0, old_bck=no, mask=no,
                 af_file=None,out_bck=None): 

    # Transform IRAF empty parameters to Python None when expected.
    if np == '': np = None
    if interp == '': interp = None
    if out_bck == '': out_bck = None
    if af_file == '': af_file = None

    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '
    if mask == yes: opt_str = opt_str + ' -msk'
    if old_bck == yes: opt_str = opt_str + ' -nor_flag'
    if np != None:
	opt_str = opt_str + ' -np='+ str(np)
    if interp != None:
	opt_str = opt_str + ' -interp='+str(interp)
    if niter_med != None:
	opt_str = opt_str + ' -niter_med='+str(niter_med)
    if niter_fit != None:
	opt_str = opt_str + ' -niter_fit='+str(niter_fit)
    if kappa != None:
	opt_str = opt_str + ' -kappa='+str(kappa)
    if smooth_length != None:
	opt_str = opt_str + ' -smooth_length='+str(smooth_length)
    if smooth_fwhm != None:
	opt_str = opt_str + ' -fwhm='+str(smooth_fwhm)
    if out_bck != None:
        opt_str = opt_str + ' -out_BCK='+iraf.osfn(out_bck)
    if af_file != None:
        opt_str = opt_str + ' -AF_file='+iraf.osfn(af_file)
    
    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_grism_name+' '+_config_name + opt_str

    # check for minimal input
    if len(grism) > 0 and len(config) > 0:

	# run command
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'BACKEST: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=backest_iraf)
