import os
import iraf

no = iraf.no
yes = iraf.yes

# Point to default parameter file for task
_parfile = 'axe$sex2gol.par'
_execfile = 'axebin$aXe_SEX2GOL'
_taskname = 'sex2gol'

######
# Small exception in case that the C-code gives error
######
class AXeError(Exception):
    def __init__(self, value):
	self.value = value
    def __str__(self):
        return self.value

######
# Set up Python IRAF interface here
######
def sex2gol_iraf(grism,config,in_sex,use_direct=yes,direct=None,
		 dir_hdu=None,spec_hdu=None,out_sex=None):
    
    # Convert blanks to 'None'
    if dir_hdu == '':
	dir_hdu = None
    if spec_hdu == '':
	spec_hdu = None
    if out_sex == '':
	out_sex = None
    
    # Translate input IRAF parameters into command-line syntax
    opt_str = ' '           
    if dir_hdu:
	opt_str = opt_str + ' -dir_hdu='+str(dir_hdu)
    if spec_hdu:
	opt_str = opt_str + ' -spec_hdu='+str(spec_hdu)
    
    if in_sex:
	opt_str = opt_str + ' -in_SEX='+in_sex
    if out_sex:
	opt_str = opt_str + ' -out_SEX='+ out_sex
    if use_direct == no:
	opt_str = opt_str + ' -no_direct_image'

    # Translate IRAF pathname for executable to full path
    _fname = iraf.osfn(_execfile)

    # Expand grism and config input values to full paths (if necessary)
    if use_direct == yes:
	_direct_name = iraf.osfn(direct)
    else:
	_direct_name = ''
    _grism_name = iraf.osfn(grism)
    _config_name = iraf.osfn(config)
    
    # build full command
    cmd_str = _fname+' '+_direct_name+' '+_grism_name+' '+_config_name + opt_str

    # check for minimal input
    if len(grism) > 0 and len(config) > 0:
	# run command
	#print cmd_str
	status = iraf.clOscmd(cmd_str)
	if status != 1:
	    estring = 'SEX2GOL: An error occured!'
	    raise AXeError, estring
    else:
	# print the help
	iraf.help(_taskname)

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
a = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=sex2gol_iraf)
