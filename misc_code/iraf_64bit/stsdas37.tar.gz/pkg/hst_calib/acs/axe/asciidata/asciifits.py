"""
Fits related classes 

@author: Martin Kuemmel, Jonas Haase
@organization: Space Telescope - European Coordinating Facility (ST-ECF)
@license: Gnu Public Licence
@contact: mkuemmel@eso.org
@since: 2005/09/13

$LastChangedBy: jhaase $
$LastChangedDate: 2006-10-13 18:38:13Z $
$HeadURL: http://astropy.scipy.org/svn/astrolib/trunk/asciidata/Lib/asciifits.py $
"""
__version__ = "Version 1.0 $LastChangedRevision: 113 $"

import string
import os
import pyfits

class AsciiFits(object):
    """
    Class for all fits-related things
    """
    def __init__(self, asciiData):
        """
        Initializes the class
 
        @param asciiData: an AsciiData object
        @type asciiData: AsciiData
        """        
        # transform the AsciiData object to a
        # pyfits table hdu object
        self.tabhdu    =  self._to_tabhdu(asciiData)

    def _to_tabhdu(self, asciiData):
        """
        Create a pyfits table HDU from an AsciiData object

        @param asciiData: an AsciiData object
        @type asciiData: AsciiData
 
        @return: the table HDU instance
        @rtype: tabHDU
        """
        
        # create the columns
        fits_cols = self._create_fits_cols(asciiData)

        # create the table HDU instance
        tabhdu = pyfits.new_table(fits_cols)
        
        # transfer the header of the AsciiData instance
        # to the fits header
        self._append_header(tabhdu, asciiData)

        # return the table HDU
        return tabhdu

    def _append_header(self, tabhdu, asciiData):
        """
        Store the AsciiData header in the fits HDU
 
        @param asciiData: an AsciiData object
        @type asciiData: AsciiData
        @param: tabhdu: the table HDU instance
        @type: tabhdu: tabHDU
        """
        
        # extract the header of the AsciiData instance
        asciiHeader = asciiData.header
        
        # extract the header of the table HDU
        theader = tabhdu.header
        
        # go through all lines in the header 
        for line in asciiHeader.hdata:

            # check whether there is indeed some content
            if len(string.strip(line)) > 0:

                # add the header in a history line
                theader.add_history(line)
        
    def _create_fits_cols(self, asciiData):
        """
        Create pyfits columns from AsciiColumns

        @param asciiData: an AsciiData object
        @type asciiData: AsciiData
 
        @return: list of pyfits columns
        @rtype: [pyfits.Column]
        """
        
        # initialize the column list
        fits_cols = []
        
        # go over all AsciiColumns
        for ii in range(asciiData.ncols):

            # determine the column format
            format = self._get_fcolformat(asciiData[ii])
            
            # create and append a fits column to the list
            fits_cols.append(pyfits.Column(name=asciiData[ii].colname,
                             format = format,
                             array=asciiData[ii].tonumarray()))
 
        # return the column list 
        return fits_cols
    
    
    def _get_fcolformat(self, asciiColumn):
        """
        Determine the fits column format

        @param asciiColumn: an AsciiColumn object
        @type asciiColumn: AsciiColumn
 
        @return: fits column format
        @rtype: string
        """
 
        # determine the column type
        ctype = asciiColumn.get_type()
        
        # check whether the column format is float
        if ctype == type(1.0):
            format = 'E'
        # check whether the column format is int
        elif ctype == type(1):
            format = 'J'
        # check whether the column format is string
        elif ctype == type('a'):
            maxlen = self._get_maxlen(asciiColumn)
            format = str(maxlen) + 'A'
        else:
            raise 'Column type: ' + str(ctype) + 'not known in fits!'

        # return the format
        return format
    
    def _get_maxlen(self, asciiColumn):
        """
        Determine the maximum string length

        @param asciiColumn: an AsciiColumn object
        @type asciiColumn: AsciiColumn
 
        @return: maximum string length
        @rtype: int
        """

        # initialize the maximum length
        maxlen = 0
        
        # go over all elements
        for ii in range(asciiColumn.get_nrows()):
            
            if asciiColumn[ii] == None:
                continue
                
            # check and perhaps replace tthe
            # maximum length
            if len(string.strip(asciiColumn[ii])) > maxlen:
                maxlen = len(string.strip(asciiColumn[ii]))

        # return the maximum lengt
        return maxlen
        
    def flush(self, fits_name='asciiData.fits'):
        """
        Write the object to a fits file
        """
 
        # check whether a file with this name
        # does just exist
        if os.path.isfile(fits_name):
            # delete the old file 
            os.unlink(fits_name)

        # write the fits file
        self.tabhdu.writeto(fits_name)
