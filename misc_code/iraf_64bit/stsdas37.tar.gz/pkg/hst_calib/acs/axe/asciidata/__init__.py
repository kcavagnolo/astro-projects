"""
$LastChangedBy: jhaase $ 
$LastChangedDate: 2006-10-13 18:16:09 +0000 (Fri, 13 Oct 2006) $
$HeadURL: http://astropy.scipy.org/svn/astrolib/trunk/asciidata/Lib/__init__.py $
"""
__version__ = "Version 1.0 $LastChangedRevision: 112 $"

from asciifunction import *
