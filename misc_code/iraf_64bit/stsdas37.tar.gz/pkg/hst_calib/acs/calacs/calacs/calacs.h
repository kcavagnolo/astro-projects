/* calacs -- integrated calacs reduction

	Warren Hack, 1998 May 12: Initial version

*/

typedef struct {
	/* name of association table exposure comes from */
	char asn_table[ACS_LINE];
	char crj_root[ACS_LINE];

	/* input, outroot, and temporary file names */
	char rawfile[ACS_LINE];	/* uncalibrated science data */
	char outroot[ACS_CBUF];	/* file name _raw for output product */
	char crjfile[ACS_LINE];	/* CR rejected, flat fielded science */
	char fltfile[ACS_LINE];	/* flat fielded science */
	char blv_tmp[ACS_LINE];	/* blevcorr, then CR flagged */
	char crj_tmp[ACS_LINE];	/* CR rejected, summed */
	char dthfile[ACS_LINE];	/* dither combined science data */	
    char mtype[SZ_STRKWVAL+1];      /* Role of exposure in association */

	char rootname[ACS_CBUF];	/* root name for set of obs */


	/* info about input science file */
	int detector;			/* integer code for detector */
	int nchips;			/* number of IMSETs in file */
	int nimages;   		/* number of images in this set */

	/* Info on the binning and gain of the science file.	*/
	int scibin[2];			/* binning factors */
	int scigain;			/* ccdgain values */
	int samebin;

	/* calibration switches */
	int sci_basic_ccd;	/* do acsccd? (dqicorr or blevcorr) */
	int sci_basic_2d;	/* do acs2d for science file? */
	int sci_crcorr;		/* do cosmic-ray rejection for science file? */
	int sci_rptcorr;	/* combine repeatobs science data? */
	int sci_dthcorr;	/* dither combine science data?    */

} ACSInfo;

