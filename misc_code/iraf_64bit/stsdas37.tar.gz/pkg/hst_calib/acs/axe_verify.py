import os,string
import iraf

no = iraf.no
yes = iraf.yes

_execfiles = ['aXe_AF2PET','aXe_BE', 'aXe_DRZ2PET', 'aXe_DRZPREP',
              'aXe_FILET', 'aXe_GOL2AF', 'aXe_GPS', 'aXe_NICBACK',
              'aXe_PET2SPC', 'aXe_PETCONT','aXe_PETFF',
              'aXe_SEX2GOL', 'aXe_STAMPS']

_bin_dir = 'stsdasbin$'

_package_motd = """
  The aXe software package 1.6 was developed by the ACS group 
  of the ST-ECF. Further information and documentation is
  available at the aXe pages:
  http://www.stecf.org/instruments/ACSgrism/axe/
  Any questions regarding this software can  be directed to:
  acsdesk@eso.org
"""

_abort_msg = """
 The aXe software package can NOT be loaded at this time!
 
 At least one of the executables for the aXe software package was
 not found within STSDAS.  Please contact the ST-ECF for a copy
 of the binaries in order to use this package. For details see: 
    http://www.stecf.org/instruments/ACSgrism/axe/

"""

# From PyDrizzle.fileutil...
def findFile(input):

    """ Search a directory for full filename with optional path. """
    
    _fdir,_fname = os.path.split(input)

    if _fdir == '':
        _fdir = os.curdir
        
    flist = os.listdir(_fdir)

    found = no
    for name in flist:
        if not string.find(name,_fname):
            found = yes
            continue
    return found

#
# Check to see that all the executables are present
#
_present = yes
for bin in _execfiles:
    _fname = iraf.osfn(_bin_dir+bin)
    if findFile(_fname) == no:
        _present = no

# Now, decide whether to define the package or not
if _present == yes:
    # All binaries are present, so...
    # ... acknowledge those responsible for the software
    # and where users can get support, then...
    if os.getenv('AXE_IMAGE_PATH') == None:
        os.putenv('AXE_IMAGE_PATH', '.')
    if os.getenv('AXE_CONFIG_PATH') == None:
        os.putenv('AXE_CONFIG_PATH', '.')
    if os.getenv('AXE_OUTPUT_PATH') == None:
        os.putenv('AXE_OUTPUT_PATH', '.')
    if os.getenv('AXE_DRIZZLE_PATH') == None:
        os.putenv('AXE_DRIZZLE_PATH', '.')

    print _package_motd
    
    # ... define the IRAF package.
    iraf.task(axeDOTpkg = 'axe$axe.cl',PkgName=PkgName, PkgBinary=PkgBinary)
else:
    # Tell user something was missing
    # and don't define anything...
    print _abort_msg   
