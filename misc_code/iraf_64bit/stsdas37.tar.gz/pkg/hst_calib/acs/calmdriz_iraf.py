import os
import iraf

no = iraf.no
yes = iraf.yes

import acs
from acs import runcaldriz

# Point to default parameter file for task
_parfile = 'hst_calib$acs/runcaldriz.par'
_taskname = 'runcaldriz'

######
# Set up Python IRAF interface here
######
def calmdriz_iraf(input,runcal=no,rundriz=yes,version=None):
    _cdriz =  runcaldriz.runCalacsDriz(inFile = input, runcal = runcal,rundriz=rundriz)    

# Initialize IRAF Task definition now...
parfile = iraf.osfn(_parfile)
cdriz = iraf.IrafTaskFactory(taskname=_taskname,value=parfile,
	    pkgname=PkgName, pkgbinary=PkgBinary, function=calmdriz_iraf)
