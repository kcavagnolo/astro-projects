define	NCOL		7

define	ID_MJD	1
define	ID_X	2
define	ID_Y	3
define	ID_Z	4
define	ID_VX	5
define	ID_VY	6
define	ID_VZ	7
