
#define clgeti clgeti_
#define clgstr clgstr_
#define clglsr clglsr_
#define clpstr clpstr_
#define clgetd clgetd_
#define clputd clputd_
#define clputi clputi_

#define strpak strpak_
#define strupk strupk_

#define tbcdef tbcdef_
#define tbpsta tbpsta_
#define tbtopn tbtopn_
#define tbpsta tbpsta_
#define tbtclo tbtclo_
#define tbrgtd tbrgtd_
#define tbrptd tbrptd_
#define tbcfnd tbcfnd_
