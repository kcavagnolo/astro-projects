
typedef struct {
	char *(*resize)();
	long recsize;
	long numrecs;
	long maxrecs;
	long growamt;
	char *data;
} Array, *ArrayPtr ;

typedef struct {
	char *(*resize)();
	long recsize;
	long numrecs;
	long maxrecs;
	long growamt;
	char *data;
	long firstfree;
	long numused;
} Pool, *PoolPtr ;

typedef struct {
	long nextfree;
} FreeListNode, *FreeListNodePtr;

extern PoolPtr nodes;
extern PoolPtr derivs;

ArrayPtr NewArray();		
PoolPtr NewPool();		
char *SizeArray();		
char *SizePool();		
char *GetRecordPtr();		
long AddRecords();		
long SubRecords();		
long PushStack();		
long GetFreeRecord();		
long CopyRecord();		
