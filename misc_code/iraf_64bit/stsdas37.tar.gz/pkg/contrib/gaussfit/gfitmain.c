/*
	GaussFit - A System for Least Squares and Robust Estimation

	Source Code Copyright (C) 1987 by William H. Jefferys,
	Michael J. Fitzpatrick and Barbara E. McArthur
	All Rights Reserved.
*/

/*
**	MAIN - main routine for Gauss.
**	    
**
**
**	Programming begun 09/11/1986  by Mike Fitzpatrick
**
**	MODIFICATION HISTORY:
**
*/

#include "defines.h"
#include <stdio.h>
#include <ctype.h>
#include "array.h"
#include "datum.h"
#include "simpledefs.h"
#include "prototypes.p"
#include "alloc.h"


extern int cur_fd;         /* information used by compiler */
extern int line_number;

main(argc,argv) /* main routine for other computers */
	/* arguments are model and environment file names */
	int argc;
	char *argv[];
{
	char ofname[25], ifname[25];
	int errstat = 0;

	prolog();
	if(argc == 2) { /* only model file was supplied */
		getfilename("\nEnter the environment filename: ",ofname); /* get environment file name */
		strcpy(ifname,argv[1]);
	} 
	else if(argc == 3) { /* all parameters were supplied */
		strcpy(ifname,argv[1]);
		strcpy(ofname,argv[2]);
	} 
	else { /* no parameters were supplied */
		getfilename("\nEnter the model filename: ",ifname); /* get model filename */
		getfilename("\nEnter the environment filename: ",ofname); /* get environment filename */
	}

	gaussmain(ifname,ofname); /* execute program */

}

getfilename(prompt,s) /* get a filename */
char *prompt;
char *s;
{
	char str[96];
	do /* repeat until a legal name is supplied */
	{
		printf(prompt); /* print the prompt */
		fgets(str, 81, stdin);
		sscanf(str, "%s",s); /* get the response */
		printf ("%s\n",s); /* print the response */
	} 
	while (s[0] == 0); /* condition is that non-null string has been entered */
}
