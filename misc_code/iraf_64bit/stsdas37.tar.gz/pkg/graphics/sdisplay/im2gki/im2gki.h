# Define the possible scaling functions.  Note that the assigments must
# match the dictionary order.
define  FUNCTION_DICTIONARY     "|linear|log|none"
define  I2G_SCALE_LINEAR        1
define  I2G_SCALE_LOG           2
define  I2G_SCALE_NONE          3
