# newcont_global - Include file for global variables in t_newcont.
#
#---------------------------------------------------------------------------

# Declarations.
pointer gp             # Graphics descriptor.

# Define the common block.

common /contour_common/ gp
