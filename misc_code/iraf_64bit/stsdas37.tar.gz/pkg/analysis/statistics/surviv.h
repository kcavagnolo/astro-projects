# SURVIV.H -- Definitions for the 
# Astronomical Survival Analysis statistical package

define	MAX_ASDAT	200	# Maximum number of data points allowed
define	MAX_ASVAR	10	# Maximum number of variables allowed
