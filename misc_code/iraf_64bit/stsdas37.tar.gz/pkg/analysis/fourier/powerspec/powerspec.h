define	AUTOCORR	1	# option = autocorrelation
define	POWERSPEC	2	# option = power spectrum

define	LOG_ZERO	-1000.	# value returned for log10(0.)
