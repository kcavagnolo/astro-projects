# LaTeX2HTML 0.6.4 (Tues Aug 30 1994)
# Associate image original text (scrambled) with physical files.

$key = q/{}psfigfigure=farrisa1.eps,width=5.0in{}/;
$cached_env_img{$key} ='<IMG ALIGN=BOTTOM SRC="_26023_tex2html_wrap47.gif">'; 
$key = q/{tabbing}=bfSTIShspace2.6in=bfNICMOS>PrimaryHeaderDataUnit>PrimaryHeaderDataUnit>hspace0.5ingeneralkeywords>hspace0.5ingeneralkeywords>hspace0.5innodata>hspace0.5innodata>firstScienceHDU>firstScienceHDU>firstErrorHDU>firstErrorHDU>firstDataQualityHDU>firstDataQualityHDU>secondScienceHDU>firstSamplesHDU>secondErrorHDU>firstIntegrationTimesHDU>secondDataQualityHDU>secondScienceHDU>etc.>secondErrorHDU>>secondDataQualityHDU>>secondSamplesHDU>>secondIntegrationTimesHDU>>etc.{tabbing}/;
$cached_env_img{$key} ='<IMG ALIGN=BOTTOM SRC="_26023_tabbing10.gif">'; 

1;

