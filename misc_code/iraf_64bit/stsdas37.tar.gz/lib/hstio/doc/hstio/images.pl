# LaTeX2HTML 0.6.4 (Tues Aug 30 1994)
# Associate image original text (scrambled) with physical files.

$key = q/{tabbing}nullhspace0.5in=hspace1.5in=kill>FITSType>PossibleRequestedType>------------>------------------------------>Logical>Bool,Int>Int>Int,Double>Float>Float,Double>Double>Double>String>String{tabbing}/;
$cached_env_img{$key} ='<IMG ALIGN=BOTTOM SRC="_26108_tabbing21.gif">'; 

1;

