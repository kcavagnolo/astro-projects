# define the output parameters
define	BLKS_RD		$1[1]
define	BLKS_WRT	$1[2]
define	RECS_RD		$1[3]
define	RECS_WRT	$1[4]
define	LEN_OUTPARAM	4
