define	MAXCOLS		52	# maximum number of columns per page
define  SZ_FMT		17	# size of string containing print format
define	MAX_RANGES (SZ_LINE/2)	# max number of ranges of row numbers
define	SHORT_STRING	11	# size of short text strings
define	SZ_ROW_HDR	 5	# size of header for row number:  "# row"
