# thistogram.h
define	NPAR	6	# there are six parameters altogether
define	NBINS	1	# got[NBINS] = true means we have a value for nbins
define	VLOW	2
define	VHIGH	3
define	DX	4
define	CLOW	5
define	CHIGH	6
