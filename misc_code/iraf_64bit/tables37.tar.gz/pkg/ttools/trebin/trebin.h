# Codes for interpolating functions.
define	I_NEAREST	1	# nearest neighbor
define	I_LINEAR	2	# linear interpolation
define	I_POLY3		3	# four-point polynomial interpolation
define	I_SPLINE	4	# cubic spline interpolation
