define TUPAR_EXIT	1	# exit, saving changes to table
define TUPAR_QUIT	2	# quit without saving changes
define TUPAR_QUIT_NC	3	# quit, and don't ask for confirmation
