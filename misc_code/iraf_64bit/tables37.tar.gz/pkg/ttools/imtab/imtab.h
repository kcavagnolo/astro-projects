define	IMTAB_NO_WCS	0	# pixel coordinates will not be written out
define	IMTAB_LOGICAL	1	# wcs = logical
define	IMTAB_PHYSICAL	2	# wcs = physical
define	IMTAB_WORLD	3	# wcs = world
