define	SYNTAX		1
define	BOUNDS		2
define	PUTNULL		11
