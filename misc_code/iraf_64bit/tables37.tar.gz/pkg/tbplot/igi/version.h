# Include file for igi version number

## 3/15/93
## 7/13/93 add version date macro

define	IGI_VERSION	"3.6.1"
define	IGI_VDATE	"18 November 1993"
