# PLF.H -- IKI/PLF internal definitions.

define	PLF_EXTN	"pl"		# image header filename extension
define	MAX_LENEXTN	3		# max length imagefile extension
