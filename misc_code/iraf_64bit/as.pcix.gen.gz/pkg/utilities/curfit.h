# NAMES -- Map generic names to external names.

define	ic_fitr		ic_fit
define	icg_fitr	icg_fit
define	ic_freer	ic_free
define	ic_errorsr	ic_errors

define	rcvcoeff	cvcoeff
define	rcverrors	cverrors
define	rcveval		cveval
define	rcvfit		cvfit
define	rcvfree		cvfree
define	rcvinit		cvinit
define	rcvpower	cvpower
define	rcvrefit	cvrefit
define	rcvrject	cvrject
define	rcvsolve	cvsolve
define	rcvstati	cvstati
define	rcvvector	cvvector
