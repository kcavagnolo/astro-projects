# Answers for emphatic yes and no.

define	XT_ANSWERS	"|no|yes|NO|YES|"
define	ALWAYSNO	2
define	ALWAYSYES	3
