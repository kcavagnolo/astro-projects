# Grow parameter structure

define	GRW_LEN		2		# Length of parameter structure

define	GRW_NGROW	Memi[$1]	# Number of grow passes
define	GRW_AGROW	Memr[$1+1]	# Grow area factor
