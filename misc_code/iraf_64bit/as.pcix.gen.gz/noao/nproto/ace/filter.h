# Filter operand names.
define	FILT_NAMES	"|id|number|x|y|wx|wy|npix|flux|peak|"
define	FILT_OBJID	1
define	FILT_NUM	2
define	FILT_X		3
define	FILT_Y		4
define	FILT_WX		5
define	FILT_WY		6
define	FILT_NPIX	7
define	FILT_FLUX	8
define	FILT_PEAK	9

# Filter functions.
define	FILT_FUNCS	"|dummy|"
