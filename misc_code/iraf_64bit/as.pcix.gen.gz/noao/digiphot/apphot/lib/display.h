# APPHOT display parameters

# display parameters (# 501 - 600)

define	MKSKY		501
define	MKCENTER	502
define	MKAPERT		503
define	MKPOLYGON	504
define	MKPSFBOX	505
define	RADPLOTS	506
define	MKDETECTIONS	507

# display parameters

define	KY_MKSKY		"mksky"
define	KY_MKCENTER		"mkcenter"
define	KY_MKAPERT		"mkapert"
define	KY_MKPOLYGON		"mkpolygon"
define	KY_MKPSFBOX		"mkbox"
define	KY_RADPLOTS		"radplots"
define	KY_MKDETECTIONS		"mkdetections"
