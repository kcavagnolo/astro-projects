# coordinates of center of picture.
define DICO_XCENTER	.505
define DICO_YCENTER	.500

# The number of dicomed pixels it takes to make 18 centimeters on a 
# standard dicomed plot.
define DICO_18CM	2436.0

# coordinates of greyscale box
define IMGBL_X	.245
define IMGBL_Y	.867
define IMGTR_X	.765
define IMGTR_Y	.902
