#! /usr/bin/perl -w

use Cwd;
use FindBin qw($Bin);

open(A,"alltex");
while(<A>){
    chomp;
    next if (/^\#/);
    next if (/^$/);
    @line = split;
    open(B,$line[0]);
    open(C,">$line[0].dat");
    while(<B>){
	chomp;
	next if (/^\#/);
	next if (/^$/);
	next if (/^\\/);
	$line2 = $_;
	$line2 =~ s/\s+//g;
	$line2 =~ s/\&/\t/g;
	$line2 =~ s/\\\\//g;
	print C "$line2\n";
    }
    close B;
}
close A;
exit 0;
