#ifndef ADBIN_VERSION_HH
#define ADBIN_VERSION_HH

const char *c_adbin_version = "0.2.0";

#endif
